package com.medicare.ConfigClient.Controller;

import com.medicare.ConfigClient.Config.BuildProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/config")
@CrossOrigin(origins = "*")
@RefreshScope
public class ConfigController {

    @Autowired
    private BuildProperties buildProperties;

    @GetMapping("/build-info")
    public Map<String, String> getBuildInfo() {
        Map<String, String> response = new HashMap<>();
        response.put("id", buildProperties.getId());
        response.put("version", buildProperties.getVersion());
        response.put("name", buildProperties.getName());
        return response;
    }
}
