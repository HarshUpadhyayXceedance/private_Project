package com.medicare.authprofile.Security;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

@Service        //Service to manage JWT token blacklist using Redis .
@RequiredArgsConstructor
@Slf4j
public class TokenBlacklistService {

    private static final String BLACKLIST_PREFIX = "auth:blacklist:";

    private final RedisTemplate<String, String> redisTemplate;
    private final JwtUtil jwtUtil;

    //Add token to blacklist. @param token JWT token to blacklist
    public void blacklistToken(String token) {
        try {
            String jti = jwtUtil.extractJti(token);
            long expirationTime = jwtUtil.getExpirationTime(token);

            if (expirationTime > 0) {
                // Store in Redis with TTL equal to remaining token lifetime
                redisTemplate.opsForValue().set(
                        BLACKLIST_PREFIX + jti,
                        "blacklisted",
                        expirationTime,
                        TimeUnit.MILLISECONDS
                );
                log.info("Token blacklisted successfully: {}", jti);
            }
        } catch (Exception e) {
            log.error("Failed to blacklist token: {}", e.getMessage());
        }
    }

    /**
     * Check if token is blacklisted
     * @param token JWT token to check
     * @return true if token is blacklisted
     */
    public boolean isTokenBlacklisted(String token) {
        try {
            String jti = jwtUtil.extractJti(token);
            Boolean exists = redisTemplate.hasKey(BLACKLIST_PREFIX + jti);
            return Boolean.TRUE.equals(exists);
        } catch (Exception e) {
            log.error("Failed to check token blacklist status: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Remove token from blacklist (rarely used)
     * @param token JWT token to remove from blacklist
     */
    public void removeFromBlacklist(String token) {
        try {
            String jti = jwtUtil.extractJti(token);
            redisTemplate.delete(BLACKLIST_PREFIX + jti);
            log.info("Token removed from blacklist: {}", jti);
        } catch (Exception e) {
            log.error("Failed to remove token from blacklist: {}", e.getMessage());
        }
    }

    /**
     * Blacklist all tokens for a specific user (e.g., on password change)
     * @param duration How long to maintain the blacklist
     */
    public void blacklistAllUserTokens(String userId, Duration duration) {
        try {
            String key = BLACKLIST_PREFIX + "user:" + userId;
            redisTemplate.opsForValue().set(
                    key,
                    String.valueOf(System.currentTimeMillis()),
                    duration
            );
            log.info("All tokens blacklisted for user: {}", userId);
        } catch (Exception e) {
            log.error("Failed to blacklist all user tokens: {}", e.getMessage());
        }
    }

    /**
     * Check if all user tokens are blacklisted
     * @param userId User ID @param tokenIssuedAt Token issued at timestamp
     * @return true if user's tokens should be blacklisted
     */
    public boolean areUserTokensBlacklisted(String userId, long tokenIssuedAt) {
        try {
            String key = BLACKLIST_PREFIX + "user:" + userId;
            String blacklistTime = redisTemplate.opsForValue().get(key);

            if (blacklistTime != null) {
                long blacklistTimestamp = Long.parseLong(blacklistTime);
                return tokenIssuedAt < blacklistTimestamp;
            }
            return false;
        } catch (Exception e) {
            log.error("Failed to check user token blacklist: {}", e.getMessage());
            return false;
        }
    }
}