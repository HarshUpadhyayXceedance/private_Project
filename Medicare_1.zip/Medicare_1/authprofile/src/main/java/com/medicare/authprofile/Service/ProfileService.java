package com.medicare.authprofile.Service;

import com.medicare.authprofile.Dto.CreateProfileRequest;
import com.medicare.authprofile.Dto.ProfileResponse;
import com.medicare.authprofile.Dto.ProfileStatusResponse;
import com.medicare.authprofile.Dto.UpdateProfileRequest;
import com.medicare.authprofile.Entity.User;
import com.medicare.authprofile.Entity.UserProfile;
import com.medicare.authprofile.enums.ProfileStatus;
import com.medicare.authprofile.enums.Role;
import com.medicare.authprofile.enums.UserStatus;
import com.medicare.authprofile.Exception.ProfileException;
import com.medicare.authprofile.Repository.UserProfileRepository;
import com.medicare.authprofile.Repository.UserRepository;
import com.medicare.authprofile.Security.InputSanitizer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProfileService {

    private final UserProfileRepository userProfileRepository;
    private final UserRepository userRepository;
    private final InputSanitizer inputSanitizer;

    @Transactional
    @CacheEvict(value = "profiles", key = "#userId")
    public ProfileResponse createProfile(String userId, CreateProfileRequest request) {
        log.info("Creating profile for userId: {}", userId);

        if (userProfileRepository.existsByUserId(userId)) {
            throw new ProfileException("Profile already exists for this user");
        }

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ProfileException("User not found"));

        // Sanitize inputs
        String name = inputSanitizer.validateAndSanitize(request.getName(), "name");
        String phone = inputSanitizer.sanitizePhone(request.getPhone());
        String address = inputSanitizer.sanitizeMultilineText(request.getAddress());
        String profilePicture = request.getProfilePicture() != null ?
                inputSanitizer.sanitizeUrl(request.getProfilePicture()) : null;

        // Validate phone number format
        if (!phone.matches("^[0-9]{10}$")) {
            throw new ProfileException("Phone number must be exactly 10 digits");
        }

        ProfileStatus profileStatus = user.getRole() == Role.PATIENT
                ? ProfileStatus.APPROVED
                : ProfileStatus.PENDING_APPROVAL;

        UserProfile profile = UserProfile.builder()
                .name(name)
                .gender(request.getGender())
                .dob(request.getDob())
                .phone(phone)
                .address(address)
                .profilePicture(profilePicture)
                .profileStatus(profileStatus)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        profile.setUser(user);

        UserProfile savedProfile = userProfileRepository.save(profile);
        userProfileRepository.flush();

        log.info("Profile created successfully for userId: {} with status: {}",
                userId, profileStatus);

        return mapToProfileResponse(savedProfile, user, "Profile created successfully");
    }

    @Transactional(readOnly = true)
    @Cacheable(value = "profiles", key = "#userId")
    public ProfileResponse getProfileByUserId(String userId) {
        log.info("Fetching profile for userId: {}", userId);

        UserProfile profile = userProfileRepository.findByUserId(userId)
                .orElseThrow(() -> new ProfileException("Profile not found"));

        User user = profile.getUser();
        return mapToProfileResponse(profile, user, null);
    }

    @Transactional(readOnly = true)
    public List<ProfileResponse> getAllProfiles() {
        log.info("Fetching all profiles");

        return userProfileRepository.findAll().stream()
                .map(profile -> mapToProfileResponse(profile, profile.getUser(), null))
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ProfileResponse> getProfilesByRole(Role role) {
        log.info("Fetching profiles by role: {}", role);

        return userProfileRepository.findByRole(role).stream()
                .map(profile -> mapToProfileResponse(profile, profile.getUser(), null))
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ProfileResponse> getProfilesByStatus(ProfileStatus status) {
        log.info("Fetching profiles by status: {}", status);

        return userProfileRepository.findByProfileStatus(status).stream()
                .map(profile -> mapToProfileResponse(profile, profile.getUser(), null))
                .collect(Collectors.toList());
    }

    @Transactional
    @CacheEvict(value = "profiles", key = "#userId")
    public ProfileResponse updateProfile(String userId, UpdateProfileRequest request) {
        log.info("Updating profile for userId: {}", userId);

        UserProfile profile = userProfileRepository.findByUserId(userId)
                .orElseThrow(() -> new ProfileException("Profile not found"));

        // Update only non-null fields with sanitization
        if (request.getName() != null) {
            profile.setName(inputSanitizer.validateAndSanitize(request.getName(), "name"));
        }
        if (request.getGender() != null) {
            profile.setGender(request.getGender());
        }
        if (request.getDob() != null) {
            profile.setDob(request.getDob());
        }
        if (request.getPhone() != null) {
            String phone = inputSanitizer.sanitizePhone(request.getPhone());
            if (!phone.matches("^[0-9]{10}$")) {
                throw new ProfileException("Phone number must be exactly 10 digits");
            }
            profile.setPhone(phone);
        }
        if (request.getAddress() != null) {
            profile.setAddress(inputSanitizer.sanitizeMultilineText(request.getAddress()));
        }
        if (request.getProfilePicture() != null) {
            profile.setProfilePicture(inputSanitizer.sanitizeUrl(request.getProfilePicture()));
        }

        UserProfile updatedProfile = userProfileRepository.save(profile);
        log.info("Profile updated successfully for userId: {}", userId);

        return mapToProfileResponse(updatedProfile, updatedProfile.getUser(),
                "Profile updated successfully");
    }

    @Transactional
    @CacheEvict(value = {"profiles", "users"}, key = "#userId")
    public ProfileStatusResponse approveProfile(String userId) {
        log.info("Approving profile for userId: {}", userId);

        UserProfile profile = userProfileRepository.findByUserId(userId)
                .orElseThrow(() -> new ProfileException("Profile not found"));

        if (profile.getProfileStatus() != ProfileStatus.PENDING_APPROVAL) {
            throw new ProfileException("Profile is not pending approval");
        }

        // Update profile status
        profile.setProfileStatus(ProfileStatus.APPROVED);
        userProfileRepository.save(profile);

        // Update user status to ACTIVE
        User user = profile.getUser();
        user.setStatus(UserStatus.ACTIVE);
        userRepository.save(user);

        log.info("Profile approved and user status updated to ACTIVE for userId: {}", userId);

        return ProfileStatusResponse.builder()
                .userId(userId)
                .profileStatus(ProfileStatus.APPROVED.name())
                .role(user.getRole().name())
                .message("Profile approved successfully")
                .build();
    }

    @Transactional
    @CacheEvict(value = "profiles", key = "#userId")
    public ProfileStatusResponse rejectProfile(String userId, String reason) {
        log.info("Rejecting profile for userId: {}", userId);

        UserProfile profile = userProfileRepository.findByUserId(userId)
                .orElseThrow(() -> new ProfileException("Profile not found"));

        if (profile.getProfileStatus() != ProfileStatus.PENDING_APPROVAL) {
            throw new ProfileException("Profile is not pending approval");
        }

        profile.setProfileStatus(ProfileStatus.REJECTED);
        userProfileRepository.save(profile);

        log.info("Profile rejected for userId: {} with reason: {}", userId, reason);

        return ProfileStatusResponse.builder()
                .userId(userId)
                .profileStatus(ProfileStatus.REJECTED.name())
                .role(profile.getUser().getRole().name())
                .message("Profile rejected: " + (reason != null ? reason : "No reason provided"))
                .build();
    }

    @Transactional(readOnly = true)
    @Cacheable(value = "profiles", key = "'status-' + #userId")
    public ProfileStatusResponse getProfileStatus(String userId) {
        log.info("Getting profile status for userId: {}", userId);

        UserProfile profile = userProfileRepository.findByUserId(userId)
                .orElseThrow(() -> new ProfileException("Profile not found"));

        return ProfileStatusResponse.builder()
                .userId(userId)
                .profileStatus(profile.getProfileStatus().name())
                .role(profile.getUser().getRole().name())
                .message("Profile status retrieved successfully")
                .build();
    }

    // Helper method to map entity to response
    private ProfileResponse mapToProfileResponse(UserProfile profile, User user, String message) {
        DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;

        return ProfileResponse.builder()
                .userId(profile.getUserId())
                .email(user.getEmail())
                .username(user.getUsername())
                .name(profile.getName())
                .gender(profile.getGender().name())
                .dob(profile.getDob())
                .phone(profile.getPhone())
                .address(profile.getAddress())
                .profilePicture(profile.getProfilePicture())
                .role(user.getRole().name())
                .status(user.getStatus().name())
                .profileStatus(profile.getProfileStatus().name())
                .createdAt(profile.getCreatedAt().format(formatter))
                .updatedAt(profile.getUpdatedAt().format(formatter))
                .message(message)
                .build();
    }
}