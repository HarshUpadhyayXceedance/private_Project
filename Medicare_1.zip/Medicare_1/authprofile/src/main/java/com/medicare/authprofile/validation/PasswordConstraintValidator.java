package com.medicare.authprofile.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class PasswordConstraintValidator implements ConstraintValidator<ValidPassword, String> {

    private final PasswordValidator passwordValidator;

    @Override
    public void initialize(ValidPassword constraintAnnotation) {
        ConstraintValidator.super.initialize(constraintAnnotation);
    }

    @Override
    public boolean isValid(String password, ConstraintValidatorContext context) {
        if (password == null) {
            return false;
        }

        PasswordValidator.ValidationResult result = passwordValidator.validate(password);

        if (!result.isValid()) {
            // Disable default message
            context.disableDefaultConstraintViolation();

            // Add custom messages for each validation error
            for (String error : result.errors()) {
                context.buildConstraintViolationWithTemplate(error)
                        .addConstraintViolation();
            }
            return false;
        }

        return true;
    }
}