package com.medicare.authprofile.Controller;


import com.medicare.authprofile.Dto.AuthResponse;
import com.medicare.authprofile.Dto.LoginRequest;
import com.medicare.authprofile.Dto.RegisterRequest;
import com.medicare.authprofile.Entity.User;
import com.medicare.authprofile.enums.UserStatus;
import com.medicare.authprofile.Service.AuthService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "*")
@Tag(name = "Authentication", description = "User authentication and authorization endpoints")
public class AuthController {

    private final AuthService authService;

    @PostMapping("/register")
    @Operation(summary = "Register new user", description = "Register a new user with email, username, password and role")
    public ResponseEntity<AuthResponse> register(@Valid @RequestBody RegisterRequest request) {
        log.info("POST /auth/register - Registration request for email: {}", request.getEmail());
        AuthResponse response = authService.register(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @PostMapping("/login")
    @Operation(summary = "User login", description = "Authenticate user and return JWT tokens")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody LoginRequest request) {
        log.info("POST /auth/login - Login request for: {}", request.getEmailOrUsername());
        AuthResponse response = authService.login(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/logout")
    @PreAuthorize("hasAnyRole('ADMIN', 'EMPLOYEE', 'PATIENT')")
    @Operation(summary = "User logout", description = "Logout user and blacklist current token")
    public ResponseEntity<Map<String, String>> logout(@RequestHeader("Authorization") String authHeader) {
        log.info("POST /auth/logout - Logout request");

        String token = authHeader.substring(7); // Remove "Bearer " prefix
        authService.logout(token);

        Map<String, String> response = new HashMap<>();
        response.put("message", "Logged out successfully");

        return ResponseEntity.ok(response);
    }

    @GetMapping("/user/{userId}")
    @PreAuthorize("hasAnyRole('ADMIN', 'EMPLOYEE', 'PATIENT')")
    @Operation(summary = "Get user by ID", description = "Retrieve user information by user ID")
    public ResponseEntity<Map<String, Object>> getUserById(@PathVariable String userId) {
        log.info("GET /auth/user/{} - Get user by ID", userId);
        User user = authService.getUserById(userId);

        Map<String, Object> response = new HashMap<>();
        response.put("userId", user.getUserId());
        response.put("email", user.getEmail());
        response.put("username", user.getUsername());
        response.put("role", user.getRole().name());
        response.put("status", user.getStatus().name());
        response.put("createdAt", user.getCreatedAt());

        return ResponseEntity.ok(response);
    }

    @PatchMapping("/admin/user/{userId}/status")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Update user status", description = "Admin endpoint to update user status (ACTIVE, PENDING, BLOCKED, SUSPENDED)")
    public ResponseEntity<Map<String, String>> updateUserStatus(
            @PathVariable String userId,
            @RequestParam String status
    ) {
        log.info("PATCH /auth/admin/user/{}/status - Update status to: {}", userId, status);

        UserStatus userStatus = UserStatus.valueOf(status.toUpperCase());
        authService.updateUserStatus(userId, userStatus);

        Map<String, String> response = new HashMap<>();
        response.put("message", "User status updated successfully");
        response.put("userId", userId);
        response.put("status", status);

        return ResponseEntity.ok(response);
    }

    @PostMapping("/validate-token")
    @Operation(summary = "Validate JWT token", description = "Validate if JWT token is valid and not blacklisted")
    public ResponseEntity<Map<String, Object>> validateToken(@RequestHeader("Authorization") String authHeader) {
        log.info("POST /auth/validate-token - Validating token");

        String token = authHeader.substring(7); // Remove "Bearer " prefix
        boolean isValid = authService.validateToken(token);

        Map<String, Object> response = new HashMap<>();
        response.put("valid", isValid);

        if (isValid) {
            response.put("userId", authService.extractUserIdFromToken(token));
            response.put("role", authService.extractRoleFromToken(token));
        }

        return ResponseEntity.ok(response);
    }

    @PostMapping("/refresh")
    @Operation(summary = "Refresh access token", description = "Get new access token using refresh token")
    public ResponseEntity<Map<String, String>> refreshToken(
            @RequestHeader("Authorization") String authHeader
    ) {
        log.info("POST /auth/refresh - Refresh token request");

        // Implementation for token refresh
        // This is a placeholder - implement based on your refresh token logic

        Map<String, String> response = new HashMap<>();
        response.put("message", "Token refresh endpoint - Implementation pending");

        return ResponseEntity.ok(response);
    }

    @GetMapping("/health")
    @Operation(summary = "Health check", description = "Check if authentication service is running")
    public ResponseEntity<Map<String, String>> health() {
        Map<String, String> response = new HashMap<>();
        response.put("status", "UP");
        response.put("service", "Auth-Profile Service");
        response.put("version", "1.0.0");
        return ResponseEntity.ok(response);
    }
}