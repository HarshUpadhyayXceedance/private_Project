package com.medicare.authprofile.Dto;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProfileStatusResponse {
    private String userId;
    private String profileStatus;
    private String role;
    private String message;
}
