package com.medicare.authprofile.validation;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

//Validator for password strength and policy compliance
@Component
@RequiredArgsConstructor
public class PasswordValidator {

    @Value("${security.password.min-length:12}")
    private int minLength;

    @Value("${security.password.require-uppercase:true}")
    private boolean requireUppercase;

    @Value("${security.password.require-lowercase:true}")
    private boolean requireLowercase;

    @Value("${security.password.require-digit:true}")
    private boolean requireDigit;

    @Value("${security.password.require-special-char:true}")
    private boolean requireSpecialChar;

    private static final Pattern UPPERCASE_PATTERN = Pattern.compile("[A-Z]");
    private static final Pattern LOWERCASE_PATTERN = Pattern.compile("[a-z]");
    private static final Pattern DIGIT_PATTERN = Pattern.compile("[0-9]");
    private static final Pattern SPECIAL_CHAR_PATTERN = Pattern.compile("[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>/?]");

    // Common weak passwords
    private static final List<String> COMMON_PASSWORDS = List.of(
            "password", "123456", "12345678", "qwerty", "abc123",
            "monkey", "1234567", "letmein", "trustno1", "dragon",
            "baseball", "111111", "iloveyou", "master", "sunshine",
            "ashley", "bailey", "passw0rd", "shadow", "123123",
            "654321", "superman", "qazwsx", "michael", "football"
    );

    /**
     * Validate password against all policies
     * @param password Password to validate
     * @return ValidationResult with success status and error messages
     */
    public ValidationResult validate(String password) {
        List<String> errors = new ArrayList<>();

        if (password == null || password.isEmpty()) {
            errors.add("Password cannot be empty");
            return new ValidationResult(false, errors);
        }

        // Check minimum length
        if (password.length() < minLength) {
            errors.add(String.format("Password must be at least %d characters long", minLength));
        }

        // Check for uppercase
        if (requireUppercase && !UPPERCASE_PATTERN.matcher(password).find()) {
            errors.add("Password must contain at least one uppercase letter");
        }

        // Check for lowercase
        if (requireLowercase && !LOWERCASE_PATTERN.matcher(password).find()) {
            errors.add("Password must contain at least one lowercase letter");
        }

        // Check for digit
        if (requireDigit && !DIGIT_PATTERN.matcher(password).find()) {
            errors.add("Password must contain at least one digit");
        }

        // Check for special character
        if (requireSpecialChar && !SPECIAL_CHAR_PATTERN.matcher(password).find()) {
            errors.add("Password must contain at least one special character (!@#$%^&*()_+-=[]{}...");
        }

        // Check against common passwords
        if (COMMON_PASSWORDS.contains(password.toLowerCase())) {
            errors.add("Password is too common. Please choose a stronger password");
        }

        // Check for sequential characters
        if (hasSequentialCharacters(password)) {
            errors.add("Password contains sequential characters (e.g., 123, abc). Please avoid predictable patterns");
        }

        // Check for repeated characters
        if (hasRepeatedCharacters(password)) {
            errors.add("Password contains too many repeated characters. Please use more variety");
        }

        return new ValidationResult(errors.isEmpty(), errors);
    }

    private boolean hasSequentialCharacters(String password) {
        String lower = password.toLowerCase();
        for (int i = 0; i < lower.length() - 2; i++) {
            char c1 = lower.charAt(i);
            char c2 = lower.charAt(i + 1);
            char c3 = lower.charAt(i + 2);

            // Check for sequential numbers or letters
            if ((c1 + 1 == c2 && c2 + 1 == c3) || (c1 - 1 == c2 && c2 - 1 == c3)) {
                return true;
            }
        }
        return false;
    }

    private boolean hasRepeatedCharacters(String password) {
        int maxRepeat = 0;
        int currentRepeat = 1;

        for (int i = 1; i < password.length(); i++) {
            if (password.charAt(i) == password.charAt(i - 1)) {
                currentRepeat++;
                maxRepeat = Math.max(maxRepeat, currentRepeat);
            } else {
                currentRepeat = 1;
            }
        }

        return maxRepeat >= 3; // More than 2 consecutive same characters
    }

    /**
     * Calculate password strength score (0-100)
     */
    public int calculateStrength(String password) {
        if (password == null || password.isEmpty()) {
            return 0;
        }

        int score = 0;

        // Length score (max 25 points)
        score += Math.min(25, password.length() * 2);

        // Variety score (max 40 points)
        if (UPPERCASE_PATTERN.matcher(password).find()) score += 10;
        if (LOWERCASE_PATTERN.matcher(password).find()) score += 10;
        if (DIGIT_PATTERN.matcher(password).find()) score += 10;
        if (SPECIAL_CHAR_PATTERN.matcher(password).find()) score += 10;

        // Complexity score (max 35 points)
        long uniqueChars = password.chars().distinct().count();
        score += Math.min(20, (int) (uniqueChars * 1.5));

        if (!hasSequentialCharacters(password)) score += 10;
        if (!hasRepeatedCharacters(password)) score += 5;

        return Math.min(100, score);
    }

    /**
     * Get strength category
     */
    public String getStrengthCategory(int score) {
        if (score >= 80) return "STRONG";
        if (score >= 60) return "GOOD";
        if (score >= 40) return "FAIR";
        if (score >= 20) return "WEAK";
        return "VERY_WEAK";
    }

    /**
     * Result of password validation
     */
    public record ValidationResult(boolean isValid, List<String> errors) {
        public String getErrorMessage() {
            return String.join("; ", errors);
        }
    }
}