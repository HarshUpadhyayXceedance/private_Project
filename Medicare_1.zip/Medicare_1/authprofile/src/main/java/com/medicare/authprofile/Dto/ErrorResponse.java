package com.medicare.authprofile.Dto;


import lombok.*;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ErrorResponse {
    private int status;
    private String error;
    private String message;
    private String timestamp;
    private String path;
    private String correlationId;
    private Map<String, String> details;
}
