package com.medicare.authprofile.enums;

public enum UserStatus {
    PENDING,    // Waiting for approval (Doctors)
    ACTIVE,     // Active user (Patients auto-active, Doctors after approval)
    BLOCKED,
    SUSPENDED// Blocked by admin
}