package com.medicare.authprofile.Service;


import com.medicare.authprofile.Dto.AuthResponse;
import com.medicare.authprofile.Dto.LoginRequest;
import com.medicare.authprofile.Dto.ProfileData;
import com.medicare.authprofile.Dto.RegisterRequest;
import com.medicare.authprofile.Entity.User;
import com.medicare.authprofile.Entity.UserProfile;
import com.medicare.authprofile.enums.Role;
import com.medicare.authprofile.enums.UserStatus;
import com.medicare.authprofile.Exception.AuthException;
import com.medicare.authprofile.Repository.UserProfileRepository;
import com.medicare.authprofile.Repository.UserRepository;
import com.medicare.authprofile.Security.JwtUtil;
import com.medicare.authprofile.Security.InputSanitizer;
import com.medicare.authprofile.Security.TokenBlacklistService;
import com.medicare.authprofile.validation.PasswordValidator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthService {

    private final UserRepository userRepository;
    private final UserProfileRepository userProfileRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final InputSanitizer inputSanitizer;
    private final PasswordValidator passwordValidator;
    private final TokenBlacklistService tokenBlacklistService;
    private final RedisTemplate<String, String> redisTemplate;

    private static final String LOGIN_ATTEMPT_PREFIX = "login:attempt:";
    private static final int MAX_LOGIN_ATTEMPTS = 5;
    private static final long LOCKOUT_DURATION_MINUTES = 30;

    @Transactional
    public AuthResponse register(RegisterRequest request) {
        log.info("Registration attempt for email: {}", request.getEmail());

        // Sanitize inputs
        String email = inputSanitizer.sanitizeEmail(request.getEmail());
        String username = inputSanitizer.sanitizeUsername(request.getUsername());

        // Validate password strength
        PasswordValidator.ValidationResult passwordValidation =
                passwordValidator.validate(request.getPassword());

        if (!passwordValidation.isValid()) {
            throw new AuthException("Password validation failed: " + passwordValidation.getErrorMessage());
        }

        // Check if email already exists
        if (userRepository.existsByEmail(email)) {
            log.warn("Registration failed: Email already registered - {}", email);
            throw new AuthException("Email already registered");
        }

        // Check if username already exists
        if (userRepository.existsByUsername(username)) {
            log.warn("Registration failed: Username already taken - {}", username);
            throw new AuthException("Username already taken");
        }

        // Validate role
        if (request.getRole() == null) {
            throw new AuthException("Role must be specified");
        }

        // Determine initial status based on role
        UserStatus initialStatus = (request.getRole() == Role.PATIENT)
                ? UserStatus.ACTIVE
                : UserStatus.PENDING;

        // Create user
        User user = User.builder()
                .email(email)
                .username(username)
                .password(passwordEncoder.encode(request.getPassword()))
                .role(request.getRole())
                .status(initialStatus)
                .build();

        User savedUser = userRepository.save(user);
        log.info("User registered successfully: {} with role: {}",
                savedUser.getUserId(), savedUser.getRole());

        // Generate JWT tokens
        String accessToken = jwtUtil.generateAccessToken(
                savedUser.getUserId(),
                savedUser.getRole(),
                savedUser.getStatus()
        );

        String refreshToken = jwtUtil.generateRefreshToken(savedUser.getUserId());

        // Log security event
        logSecurityEvent("USER_REGISTERED", savedUser.getUserId(), "New user registration");

        return AuthResponse.builder()
                .userId(savedUser.getUserId())
                .role(savedUser.getRole().name())
                .status(savedUser.getStatus().name())
                .token(accessToken)
                .refreshToken(refreshToken)
                .message("Registration successful. Please complete your profile.")
                .build();
    }

    @Transactional(readOnly = true)
    public AuthResponse login(LoginRequest request) {
        String identifier = inputSanitizer.validateAndSanitize(
                request.getEmailOrUsername(),
                "emailOrUsername"
        );

        log.info("Login attempt for: {}", identifier);

        // Check if account is locked due to failed attempts
        if (isAccountLocked(identifier)) {
            log.warn("Login blocked: Account temporarily locked - {}", identifier);
            throw new AuthException(
                    "Account temporarily locked due to multiple failed login attempts. " +
                            "Please try again after " + LOCKOUT_DURATION_MINUTES + " minutes."
            );
        }

        // Find user
        User user = userRepository.findByEmailOrUsername(identifier, identifier)
                .orElseThrow(() -> {
                    incrementLoginAttempts(identifier);
                    log.warn("Login failed: Invalid credentials for - {}", identifier);
                    return new AuthException("Invalid credentials");
                });

        // Verify password
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            incrementLoginAttempts(identifier);
            log.warn("Login failed: Incorrect password for user - {}", user.getUserId());
            throw new AuthException("Invalid credentials");
        }

        // Check user status
        if (user.getStatus() == UserStatus.BLOCKED) {
            log.warn("Login blocked: User account blocked - {}", user.getUserId());
            throw new AuthException("Account is blocked. Please contact administrator");
        }

        if (user.getStatus() == UserStatus.SUSPENDED) {
            log.warn("Login blocked: User account suspended - {}", user.getUserId());
            throw new AuthException("Account is suspended. Please contact support");
        }

        // Reset failed login attempts on successful login
        resetLoginAttempts(identifier);

        log.info("Login successful for user: {} with role: {}",
                user.getUserId(), user.getRole());

        // Generate JWT tokens
        String accessToken = jwtUtil.generateAccessToken(
                user.getUserId(),
                user.getRole(),
                user.getStatus()
        );

        String refreshToken = jwtUtil.generateRefreshToken(user.getUserId());

        // Check if profile exists and include in response
        ProfileData profileData = null;
        UserProfile profile = userProfileRepository.findByUserId(user.getUserId()).orElse(null);
        if (profile != null) {
            profileData = ProfileData.builder()
                    .name(profile.getName())
                    .gender(profile.getGender().name())
                    .dob(profile.getDob())
                    .phone(profile.getPhone())
                    .address(profile.getAddress())
                    .profilePicture(profile.getProfilePicture())
                    .profileStatus(profile.getProfileStatus().name())
                    .build();
        }

        // Log security event
        logSecurityEvent("USER_LOGIN", user.getUserId(), "Successful login");

        return AuthResponse.builder()
                .userId(user.getUserId())
                .role(user.getRole().name())
                .status(user.getStatus().name())
                .token(accessToken)
                .refreshToken(refreshToken)
                .profileData(profileData)
                .message("Login successful")
                .build();
    }

    @Transactional
    @CacheEvict(value = "users", key = "#userId")
    public void updateUserStatus(String userId, UserStatus status) {
        log.info("Updating status for user: {} to {}", userId, status);

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new AuthException("User not found"));

        user.setStatus(status);
        userRepository.save(user);

        // If user is blocked or suspended, blacklist all their tokens
        if (status == UserStatus.BLOCKED || status == UserStatus.SUSPENDED) {
            tokenBlacklistService.blacklistAllUserTokens(userId, Duration.ofDays(30));
            logSecurityEvent("USER_STATUS_CHANGED", userId,
                    "User status changed to " + status + ", all tokens blacklisted");
        }

        log.info("User status updated successfully");
    }

    @Transactional(readOnly = true)
    @Cacheable(value = "users", key = "#userId")
    public User getUserById(String userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new AuthException("User not found"));
    }

    @Transactional(readOnly = true)
    public boolean isUserActive(String userId) {
        return userRepository.findById(userId)
                .map(user -> user.getStatus() == UserStatus.ACTIVE)
                .orElse(false);
    }

    public boolean validateToken(String token) {
        return jwtUtil.validateToken(token) &&
                !tokenBlacklistService.isTokenBlacklisted(token);
    }

    public String extractUserIdFromToken(String token) {
        return jwtUtil.extractUserId(token);
    }

    public String extractRoleFromToken(String token) {
        return jwtUtil.extractRole(token);
    }

    public void logout(String token) {
        tokenBlacklistService.blacklistToken(token);
        String userId = jwtUtil.extractUserId(token);
        logSecurityEvent("USER_LOGOUT", userId, "User logged out");
        log.info("User {} logged out successfully", userId);
    }

    // Rate limiting and account lockout methods
    private void incrementLoginAttempts(String identifier) {
        String key = LOGIN_ATTEMPT_PREFIX + identifier;
        String attempts = redisTemplate.opsForValue().get(key);

        int count = attempts == null ? 1 : Integer.parseInt(attempts) + 1;

        if (count >= MAX_LOGIN_ATTEMPTS) {
            redisTemplate.opsForValue().set(
                    key,
                    String.valueOf(count),
                    LOCKOUT_DURATION_MINUTES,
                    TimeUnit.MINUTES
            );
            logSecurityEvent("ACCOUNT_LOCKED", identifier,
                    "Account locked after " + MAX_LOGIN_ATTEMPTS + " failed attempts");
        } else {
            redisTemplate.opsForValue().set(
                    key,
                    String.valueOf(count),
                    15,
                    TimeUnit.MINUTES
            );
        }
    }

    private void resetLoginAttempts(String identifier) {
        String key = LOGIN_ATTEMPT_PREFIX + identifier;
        redisTemplate.delete(key);
    }

    private boolean isAccountLocked(String identifier) {
        String key = LOGIN_ATTEMPT_PREFIX + identifier;
        String attempts = redisTemplate.opsForValue().get(key);

        if (attempts != null) {
            int count = Integer.parseInt(attempts);
            return count >= MAX_LOGIN_ATTEMPTS;
        }
        return false;
    }

    private void logSecurityEvent(String eventType, String userId, String description) {
        // In production, send to security monitoring system (SIEM)
        log.info("SECURITY_EVENT: type={}, userId={}, description={}",
                eventType, userId, description);
    }
}