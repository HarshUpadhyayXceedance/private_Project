package com.medicare.authprofile.Dto;

import lombok.*;
import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProfileResponse {
    private String userId;
    private String email;
    private String username;
    private String name;
    private String gender;
    private LocalDate dob;
    private String phone;
    private String address;
    private String profilePicture;
    private String role;
    private String status;
    private String profileStatus;
    private String createdAt;
    private String updatedAt;
    private String message;
}
