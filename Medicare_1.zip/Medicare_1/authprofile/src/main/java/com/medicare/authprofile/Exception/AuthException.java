package com.medicare.authprofile.Exception;

public class AuthException extends RuntimeException {
    public AuthException(String message) {
        super(message);
    }
}

