package com.medicare.authprofile.Security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Collections;
import java.util.UUID;

@Component
@RequiredArgsConstructor
@Slf4j
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtUtil jwtUtil;
    private final TokenBlacklistService tokenBlacklistService;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {

        // Generate correlation ID for request tracking
        String correlationId = request.getHeader("X-Correlation-ID");
        if (correlationId == null || correlationId.isEmpty()) {
            correlationId = UUID.randomUUID().toString();
        }
        MDC.put("correlationId", correlationId);
        response.setHeader("X-Correlation-ID", correlationId);

        final String authHeader = request.getHeader("Authorization");
        final String jwt;
        final String userId;

        // Check if Authorization header exists and starts with "Bearer "
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);
            MDC.clear();
            return;
        }

        try {
            // Extract JWT token
            jwt = authHeader.substring(7);

            // Validate token format and signature
            if (!jwtUtil.validateToken(jwt)) {
                log.warn("Invalid JWT token received from IP: {}", request.getRemoteAddr());
                sendUnauthorizedResponse(response, "Invalid or expired token");
                MDC.clear();
                return;
            }

            // Check if token is blacklisted
            if (tokenBlacklistService.isTokenBlacklisted(jwt)) {
                log.warn("Blacklisted token attempt from IP: {}", request.getRemoteAddr());
                sendUnauthorizedResponse(response, "Token has been revoked");
                MDC.clear();
                return;
            }

            // Extract user information from token
            userId = jwtUtil.extractUserId(jwt);
            String role = jwtUtil.extractRole(jwt);
            String status = jwtUtil.extractStatus(jwt);

            // Check if user is active
            if (!"ACTIVE".equals(status) && !"PENDING".equals(status)) {
                log.warn("Inactive user {} attempted access", userId);
                sendUnauthorizedResponse(response, "Account is not active");
                MDC.clear();
                return;
            }

            // Set authentication in security context
            if (userId != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(
                        userId,
                        null,
                        Collections.singletonList(new SimpleGrantedAuthority("ROLE_" + role))
                );

                authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                SecurityContextHolder.getContext().setAuthentication(authToken);

                // Add user info to MDC for logging
                MDC.put("userId", userId);
                MDC.put("role", role);

                log.debug("Authenticated user: {} with role: {}", userId, role);
            }

        } catch (Exception e) {
            log.error("Cannot set user authentication: {}", e.getMessage());
            sendUnauthorizedResponse(response, "Authentication failed");
            MDC.clear();
            return;
        }

        filterChain.doFilter(request, response);
        MDC.clear();
    }

    private void sendUnauthorizedResponse(HttpServletResponse response, String message) throws IOException {
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setContentType("application/json");
        response.getWriter().write(String.format(
                "{\"error\":\"UNAUTHORIZED\",\"message\":\"%s\"}",
                message
        ));
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getRequestURI();

        // Skip filter for public endpoints
        return path.startsWith("/api/auth-profile/auth/register") ||
                path.startsWith("/api/auth-profile/auth/login") ||
                path.startsWith("/api/auth-profile/auth/health") ||
                path.startsWith("/api/auth-profile/actuator/health") ||
                path.startsWith("/api/auth-profile/v3/api-docs") ||
                path.startsWith("/api/auth-profile/swagger-ui");
    }
}