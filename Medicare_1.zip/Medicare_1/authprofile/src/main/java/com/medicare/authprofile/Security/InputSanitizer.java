package com.medicare.authprofile.Security;

import org.apache.commons.text.StringEscapeUtils;
import org.springframework.stereotype.Component;

import java.util.regex.Pattern;

// Utility class for sanitizing user inputs to prevent XSS and injection attacks
@Component
public class InputSanitizer {

    // Pattern to detect potential SQL injection
    private static final Pattern SQL_INJECTION_PATTERN = Pattern.compile(
            ".*(union|select|insert|update|delete|drop|create|alter|exec|script|javascript|onerror|onload).*",
            Pattern.CASE_INSENSITIVE
    );

    // Pattern to detect potential XSS
    private static final Pattern XSS_PATTERN = Pattern.compile(
            ".*(<script|<iframe|<object|<embed|<applet|javascript:|onerror=|onload=|eval\\().*",
            Pattern.CASE_INSENSITIVE
    );

    //Sanitize string input for HTML output (prevents XSS)
    public String sanitizeHtml(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }
        return StringEscapeUtils.escapeHtml4(input);
    }

    //Sanitize string for use in SQL-like contexts. Note: Use PreparedStatements instead when possible
    public String sanitizeSql(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }

        // Remove potentially dangerous characters
        return input.replaceAll("[';\"\\\\]", "");
    }

    //Remove all HTML tags from input
    public String stripHtml(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }
        return input.replaceAll("<[^>]*>", "");
    }

    // Sanitize username - allow only alphanumeric, underscore, hyphen, dot
    public String sanitizeUsername(String username) {
        if (username == null || username.isEmpty()) {
            return username;
        }
        return username.replaceAll("[^a-zA-Z0-9._-]", "");
    }

    //Sanitize email - basic validation and sanitization
    public String sanitizeEmail(String email) {
        if (email == null || email.isEmpty()) {
            return email;
        }
        return email.trim().toLowerCase().replaceAll("[^a-zA-Z0-9@._-]", "");
    }

    // Sanitize phone number - allow only digits and basic formatting
    public String sanitizePhone(String phone) {
        if (phone == null || phone.isEmpty()) {
            return phone;
        }
        return phone.replaceAll("[^0-9+()-]", "");
    }

    // Sanitize general text input
    public String sanitizeText(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }

        // Trim whitespace
        input = input.trim();

        // Remove null bytes
        input = input.replace("\0", "");

        // Escape HTML
        input = sanitizeHtml(input);

        return input;
    }

    // Check if input contains potential SQL injection
    public boolean containsSqlInjection(String input) {
        if (input == null || input.isEmpty()) {
            return false;
        }
        return SQL_INJECTION_PATTERN.matcher(input).matches();
    }

    // Check if input contains potential XSS
    public boolean containsXss(String input) {
        if (input == null || input.isEmpty()) {
            return false;
        }
        return XSS_PATTERN.matcher(input).matches();
    }

    // Validate and sanitize input - throws exception if malicious content detected
    public String validateAndSanitize(String input, String fieldName) {
        if (input == null) {
            return null;
        }

        if (containsSqlInjection(input)) {
            throw new SecurityException(
                    String.format("Potential SQL injection detected in %s", fieldName)
            );
        }

        if (containsXss(input)) {
            throw new SecurityException(
                    String.format("Potential XSS attack detected in %s", fieldName)
            );
        }

        return sanitizeText(input);
    }

    // Sanitize multiline text (addresses, descriptions)
    public String sanitizeMultilineText(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }

        // Validate for malicious content
        if (containsXss(input) || containsSqlInjection(input)) {
            throw new SecurityException("Malicious content detected in input");
        }

        // Trim each line and remove excessive newlines
        String[] lines = input.split("\\r?\\n");
        StringBuilder sanitized = new StringBuilder();

        for (String line : lines) {
            String trimmedLine = line.trim();
            if (!trimmedLine.isEmpty()) {
                sanitized.append(sanitizeHtml(trimmedLine)).append("\n");
            }
        }

        return sanitized.toString().trim();
    }

    // Sanitize URL
    public String sanitizeUrl(String url) {
        if (url == null || url.isEmpty()) {
            return url;
        }

        // Only allow http and https protocols
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            throw new SecurityException("Invalid URL protocol. Only HTTP and HTTPS are allowed");
        }

        // Check for javascript or data URLs
        if (url.toLowerCase().contains("javascript:") || url.toLowerCase().contains("data:")) {
            throw new SecurityException("Dangerous URL detected");
        }

        return url;
    }
}