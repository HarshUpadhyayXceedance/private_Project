package com.medicare.appointment_service.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@FeignClient(name = "DOCTOR-MANAGEMENT-SERVICE")
public interface DoctorServiceClient {

    @GetMapping("/api/doctor-management/doctors/{doctorId}")
    ResponseEntity<Map<String, Object>> getDoctorById(@PathVariable Long doctorId);

    @GetMapping("/api/doctor-management/doctors/{doctorId}/slots/available")
    ResponseEntity<List<Map<String, Object>>> getAvailableSlots(
            @PathVariable Long doctorId,
            @RequestParam LocalDate date
    );

    @GetMapping("/api/doctor-management/doctors/{doctorId}/slots/{slotId}")
    ResponseEntity<Map<String, Object>> getSlotById(
            @PathVariable Long doctorId,
            @PathVariable Long slotId
    );

    @PutMapping("/api/doctor-management/doctors/{doctorId}/slots/{slotId}/book")
    ResponseEntity<Map<String, Object>> bookSlot(
            @PathVariable Long doctorId,
            @PathVariable Long slotId,
            @RequestBody Map<String, Object> bookingData
    );

    @PutMapping("/api/doctor-management/doctors/{doctorId}/slots/{slotId}/unblock")
    ResponseEntity<Map<String, Object>> releaseSlot(
            @PathVariable Long doctorId,
            @PathVariable Long slotId
    );

    @GetMapping("/api/doctor-management/doctors/{doctorId}/leaves")
    ResponseEntity<List<Map<String, Object>>> getDoctorLeaves(
            @PathVariable Long doctorId,
            @RequestParam(required = false) LocalDate date
    );
}




