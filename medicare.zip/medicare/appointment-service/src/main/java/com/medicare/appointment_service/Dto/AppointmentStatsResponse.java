package com.medicare.appointment_service.Dto;


import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AppointmentStatsResponse {
    private Long totalAppointments;
    private Long scheduledAppointments;
    private Long confirmedAppointments;
    private Long completedAppointments;
    private Long cancelledAppointments;
    private Long noShowAppointments;
    private Double completionRate;
    private Double cancellationRate;
    private Double noShowRate;
}