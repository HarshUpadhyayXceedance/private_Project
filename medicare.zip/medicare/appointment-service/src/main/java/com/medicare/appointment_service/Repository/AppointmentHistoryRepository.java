package com.medicare.appointment_service.Repository;


import com.medicare.appointment_service.Entity.AppointmentHistory;
import com.medicare.appointment_service.Enums.AppointmentAction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AppointmentHistoryRepository extends JpaRepository<AppointmentHistory, Long> {

    // Find by appointment
    List<AppointmentHistory> findByAppointmentIdOrderByTimestampDesc(Long appointmentId);

    // Find by action
    List<AppointmentHistory> findByActionOrderByTimestampDesc(AppointmentAction action);

    // Find by performed by
    List<AppointmentHistory> findByPerformedByOrderByTimestampDesc(String performedBy);

    // Find by date range
    List<AppointmentHistory> findByTimestampBetweenOrderByTimestampDesc(
            LocalDateTime startDate, LocalDateTime endDate);

    // Count actions by appointment
    Long countByAppointmentIdAndAction(Long appointmentId, AppointmentAction action);
}
