package com.medicare.appointment_service.Dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CancellationEligibilityResponse {
    private Boolean canCancel;
    private String reason;
    private Boolean isFullRefund;
    private Boolean isPartialRefund;
    private Integer refundPercentage;
    private Long hoursUntilAppointment;
}