package com.medicare.appointment_service.Dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RescheduleEligibilityResponse {
    private Boolean canReschedule;
    private String reason;
    private Integer remainingReschedules;
    private Long hoursUntilAppointment;
}