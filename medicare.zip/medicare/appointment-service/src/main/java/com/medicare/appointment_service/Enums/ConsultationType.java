package com.medicare.appointment_service.Enums;

public enum ConsultationType {
    IN_CLINIC,
    ONLINE,
    HOME_VISIT,
    EMERGENCY
}
