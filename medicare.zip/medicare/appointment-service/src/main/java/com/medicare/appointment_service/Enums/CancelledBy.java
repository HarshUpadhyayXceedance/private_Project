package com.medicare.appointment_service.Enums;

public enum CancelledBy {
    PATIENT,
    DOCTOR,
    ADMIN,
    SYSTEM  // Auto-cancelled by system
}
