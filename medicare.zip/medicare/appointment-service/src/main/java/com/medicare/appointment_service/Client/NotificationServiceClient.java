package com.medicare.appointment_service.Client;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@FeignClient(name = "NOTIFICATION-SERVICE", url = "http://localhost:8087/api/notification")
public interface NotificationServiceClient {

    @PostMapping("/notifications/appointment-booked")
    ResponseEntity<Map<String, Object>> sendAppointmentBookedNotification(
            @RequestBody Map<String, Object> notificationData
    );

    @PostMapping("/notifications/appointment-confirmed")
    ResponseEntity<Map<String, Object>> sendAppointmentConfirmedNotification(
            @RequestBody Map<String, Object> notificationData
    );

    @PostMapping("/notifications/appointment-cancelled")
    ResponseEntity<Map<String, Object>> sendAppointmentCancelledNotification(
            @RequestBody Map<String, Object> notificationData
    );

    @PostMapping("/notifications/appointment-rescheduled")
    ResponseEntity<Map<String, Object>> sendAppointmentRescheduledNotification(
            @RequestBody Map<String, Object> notificationData
    );

    @PostMapping("/notifications/appointment-reminder")
    ResponseEntity<Map<String, Object>> sendAppointmentReminder(
            @RequestBody Map<String, Object> notificationData
    );

    @PostMapping("/notifications/appointment-completed")
    ResponseEntity<Map<String, Object>> sendAppointmentCompletedNotification(
            @RequestBody Map<String, Object> notificationData
    );
}