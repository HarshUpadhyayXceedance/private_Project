package com.medicare.appointment_service.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@FeignClient(name = "PATIENT-MANAGEMENT-SERVICE")
public interface PatientServiceClient {

    @GetMapping("/api/patient-management/patients/{patientId}")
    ResponseEntity<Map<String, Object>> getPatientById(@PathVariable Long patientId);

    @GetMapping("/api/patient-management/patients/user/{userId}")
    ResponseEntity<Map<String, Object>> getPatientByUserId(@PathVariable String userId);
}