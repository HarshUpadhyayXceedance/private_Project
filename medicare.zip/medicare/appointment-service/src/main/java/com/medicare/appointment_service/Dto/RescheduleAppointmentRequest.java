package com.medicare.appointment_service.Dto;

import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RescheduleAppointmentRequest {

    @NotNull(message = "New slot ID is required")
    private Long newSlotId;

    @NotNull(message = "New appointment date is required")
    @Future(message = "New appointment date must be in the future")
    private LocalDate newAppointmentDate;

    @NotNull(message = "New appointment time is required")
    private LocalTime newAppointmentTime;

    @Size(max = 500, message = "Reason cannot exceed 500 characters")
    private String reason;
}