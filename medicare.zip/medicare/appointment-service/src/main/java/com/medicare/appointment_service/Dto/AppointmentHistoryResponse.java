package com.medicare.appointment_service.Dto;

import com.medicare.appointment_service.Enums.AppointmentAction;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AppointmentHistoryResponse {
    private Long id;
    private Long appointmentId;
    private AppointmentAction action;
    private String performedBy;
    private String performedByName;
    private LocalDate previousDate;
    private LocalTime previousTime;
    private LocalDate newDate;
    private LocalTime newTime;
    private String reason;
    private String notes;
    private LocalDateTime timestamp;
}
