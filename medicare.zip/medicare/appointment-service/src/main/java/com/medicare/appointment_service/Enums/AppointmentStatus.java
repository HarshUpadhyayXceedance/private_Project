package com.medicare.appointment_service.Enums;

public enum AppointmentStatus {
    SCHEDULED,      // Appointment booked
    CONFIRMED,      // Doctor confirmed
    IN_PROGRESS,    // Consultation started
    COMPLETED,      // Consultation finished
    CANCELLED,      // Cancelled by patient/doctor
    NO_SHOW,        // Patient didn't show up
    RESCHEDULED     // Appointment rescheduled
}













