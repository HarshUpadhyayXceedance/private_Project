package com.medicare.appointment_service.Enums;

public enum AppointmentAction {
    BOOKED,
    CONFIRMED,
    RESCHEDULED,
    CANCELLED,
    COMPLETED,
    NO_SHOW,
    CHECKED_IN,
    STARTED
}
