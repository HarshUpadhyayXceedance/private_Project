package com.medicare.appointment_service.Dto;
import com.medicare.appointment_service.Enums.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AppointmentResponse {
    private Long id;
    private String appointmentNumber;
    private Long patientId;
    private String patientName;
    private Long doctorId;
    private String doctorName;
    private String doctorSpecialization;
    private LocalDate appointmentDate;
    private LocalTime appointmentTime;
    private LocalTime appointmentEndTime;
    private ConsultationType consultationType;
    private AppointmentStatus status;
    private String reasonForVisit;
    private String symptoms;
    private String notes;
    private BigDecimal consultationFee;
    private PaymentStatus paymentStatus;
    private LocalDateTime bookingDate;
    private LocalDateTime confirmedAt;
    private LocalDateTime completedAt;
    private LocalDateTime cancelledAt;
    private String cancellationReason;
    private CancelledBy cancelledBy;
    private Integer rescheduledCount;
    private Boolean isEmergency;
    private Boolean checkedIn;
    private LocalDateTime checkInTime;
    private Long invoiceId;
    private String invoiceNumber;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private String message;
}






