package com.medicare.appointment_service.Dto;

import lombok.*;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DoctorStatsResponse {
    private Long doctorId;
    private String doctorName;
    private String specialization;
    private Long todayAppointments;
    private Long upcomingAppointments;
    private Long completedAppointments;
    private Long cancelledAppointments;
    private BigDecimal totalRevenue;
    private Double averageRating;
}
