package com.medicare.appointment_service.Service;

import com.medicare.appointment_service.Client.DoctorServiceClient;
import com.medicare.appointment_service.Client.NotificationServiceClient;
import com.medicare.appointment_service.Client.PatientServiceClient;
import com.medicare.appointment_service.Dto.*;
import com.medicare.appointment_service.Entity.Appointment;
import com.medicare.appointment_service.Entity.AppointmentHistory;
import com.medicare.appointment_service.Enums.*;
import com.medicare.appointment_service.Exception.AppointmentException;
import com.medicare.appointment_service.Repository.AppointmentHistoryRepository;
import com.medicare.appointment_service.Repository.AppointmentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class AppointmentService {

    private final AppointmentRepository appointmentRepository;
    private final AppointmentHistoryRepository historyRepository;
    private final DoctorServiceClient doctorClient;
    private final PatientServiceClient patientClient;
    private final NotificationServiceClient notificationClient;

    // ============================================
    // BOOK APPOINTMENT
    // ============================================
    @Transactional
    public AppointmentResponse bookAppointment(BookAppointmentRequest request, String userId) {
        log.info("Booking appointment for patient: {}, doctor: {}", request.getPatientId(), request.getDoctorId());

        // 1. Validate patient exists
        Map<String, Object> patientData = validatePatient(request.getPatientId());

        // 2. Validate doctor exists and get details
        Map<String, Object> doctorData = validateDoctor(request.getDoctorId());

        // 3. Validate slot is available
        Map<String, Object> slotData = validateSlot(request.getDoctorId(), request.getSlotId());

        // 4. Check if slot is on the requested date
        validateSlotDate(slotData, request.getAppointmentDate());

        // 5. Check doctor is not on leave
        validateDoctorNotOnLeave(request.getDoctorId(), request.getAppointmentDate());

        // 6. Check patient has no overlapping appointments
        validateNoOverlappingAppointments(request.getPatientId(), request.getAppointmentDate(),
                request.getAppointmentTime());

        // 7. Get consultation fee
        BigDecimal consultationFee = getConsultationFee(doctorData, request.getConsultationType());

        // 8. Calculate end time (assuming 30 min consultation)
        LocalTime endTime = request.getAppointmentTime().plusMinutes(30);

        // 9. Create appointment
        Appointment appointment = Appointment.builder()
                .appointmentNumber(generateAppointmentNumber())
                .patientId(request.getPatientId())
                .doctorId(request.getDoctorId())
                .slotId(request.getSlotId())
                .appointmentDate(request.getAppointmentDate())
                .appointmentTime(request.getAppointmentTime())
                .appointmentEndTime(endTime)
                .consultationType(request.getConsultationType())
                .reasonForVisit(request.getReasonForVisit())
                .symptoms(request.getSymptoms())
                .notes(request.getNotes())
                .consultationFee(consultationFee)
                .status(AppointmentStatus.SCHEDULED)
                .paymentStatus(PaymentStatus.PENDING)
                .isEmergency(request.getIsEmergency())
                .rescheduledCount(0)
                .checkedIn(false)
                .bookingDate(LocalDateTime.now())
                .build();

        appointment = appointmentRepository.save(appointment);

        // 10. Book slot in Doctor Service
        bookSlotInDoctorService(request.getDoctorId(), request.getSlotId(), appointment.getId());

        // 11. Record history
        recordHistory(appointment.getId(), AppointmentAction.BOOKED, userId, null);

        // 12. Send notification (async - ignore errors)
        sendBookingNotification(appointment, patientData, doctorData);

        log.info("Appointment booked successfully: {}", appointment.getAppointmentNumber());

        return mapToResponse(appointment, patientData, doctorData);
    }

    // ============================================
    // GET APPOINTMENT BY ID
    // ============================================
    public AppointmentResponse getAppointmentById(Long appointmentId) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new AppointmentException("Appointment not found with id: " + appointmentId));

        Map<String, Object> patientData = getPatientData(appointment.getPatientId());
        Map<String, Object> doctorData = getDoctorData(appointment.getDoctorId());

        return mapToResponse(appointment, patientData, doctorData);
    }

    // ============================================
    // GET APPOINTMENT BY NUMBER
    // ============================================
    public AppointmentResponse getAppointmentByNumber(String appointmentNumber) {
        Appointment appointment = appointmentRepository.findByAppointmentNumber(appointmentNumber)
                .orElseThrow(() -> new AppointmentException("Appointment not found with number: " + appointmentNumber));

        Map<String, Object> patientData = getPatientData(appointment.getPatientId());
        Map<String, Object> doctorData = getDoctorData(appointment.getDoctorId());

        return mapToResponse(appointment, patientData, doctorData);
    }

    // ============================================
    // GET PATIENT APPOINTMENTS
    // ============================================
    public Page<AppointmentResponse> getPatientAppointments(Long patientId, Pageable pageable) {
        Page<Appointment> appointments = appointmentRepository
                .findByPatientIdOrderByAppointmentDateDescAppointmentTimeDesc(patientId, pageable);

        return appointments.map(appointment -> {
            Map<String, Object> doctorData = getDoctorData(appointment.getDoctorId());
            return mapToResponse(appointment, null, doctorData);
        });
    }

    // ============================================
    // GET DOCTOR APPOINTMENTS
    // ============================================
    public Page<AppointmentResponse> getDoctorAppointments(Long doctorId, Pageable pageable) {
        Page<Appointment> appointments = appointmentRepository
                .findByDoctorIdOrderByAppointmentDateDescAppointmentTimeDesc(doctorId, pageable);

        return appointments.map(appointment -> {
            Map<String, Object> patientData = getPatientData(appointment.getPatientId());
            return mapToResponse(appointment, patientData, null);
        });
    }

    // ============================================
    // GET DOCTOR TODAY'S APPOINTMENTS
    // ============================================
    public List<AppointmentResponse> getDoctorTodayAppointments(Long doctorId) {
        LocalDate today = LocalDate.now();
        List<AppointmentStatus> activeStatuses = Arrays.asList(
                AppointmentStatus.SCHEDULED,
                AppointmentStatus.CONFIRMED,
                AppointmentStatus.IN_PROGRESS
        );

        List<Appointment> appointments = appointmentRepository
                .findByDoctorIdAndAppointmentDateAndStatusIn(doctorId, today, activeStatuses);

        return appointments.stream()
                .map(appointment -> {
                    Map<String, Object> patientData = getPatientData(appointment.getPatientId());
                    return mapToResponse(appointment, patientData, null);
                })
                .collect(Collectors.toList());
    }


    // HELPER: Generate Appointment Number
    private String generateAppointmentNumber() {
        String year = String.valueOf(Year.now().getValue());
        String prefix = "APT-" + year + "-";

        Integer lastSequence = appointmentRepository.getLastAppointmentSequence(prefix);
        int nextSequence = (lastSequence != null) ? lastSequence + 1 : 1;

        return prefix + String.format("%06d", nextSequence);
    }

    // HELPER: Validate Patient
    private Map<String, Object> validatePatient(Long patientId) {
        try {
            var response = patientClient.getPatientById(patientId);
            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                return response.getBody();
            }
            throw new AppointmentException("Patient not found with id: " + patientId);
        } catch (Exception e) {
            log.error("Error validating patient: {}", e.getMessage());
            throw new AppointmentException("Failed to validate patient: " + e.getMessage());
        }
    }

    // HELPER: Validate Doctor
    private Map<String, Object> validateDoctor(Long doctorId) {
        try {
            var response = doctorClient.getDoctorById(doctorId);
            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                return response.getBody();
            }
            throw new AppointmentException("Doctor not found with id: " + doctorId);
        } catch (Exception e) {
            log.error("Error validating doctor: {}", e.getMessage());
            throw new AppointmentException("Failed to validate doctor: " + e.getMessage());
        }
    }

    // HELPER: Validate Slot
    private Map<String, Object> validateSlot(Long doctorId, Long slotId) {
        try {
            var response = doctorClient.getSlotById(doctorId, slotId);
            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                Map<String, Object> slotData = response.getBody();
                String status = (String) slotData.get("slotStatus");

                if (!"AVAILABLE".equals(status)) {
                    throw new AppointmentException("Slot is not available. Current status: " + status);
                }

                return slotData;
            }
            throw new AppointmentException("Slot not found");
        } catch (Exception e) {
            log.error("Error validating slot: {}", e.getMessage());
            throw new AppointmentException("Failed to validate slot: " + e.getMessage());
        }
    }

    // HELPER: Validate Slot Date
    private void validateSlotDate(Map<String, Object> slotData, LocalDate requestedDate) {
        String slotDateStr = (String) slotData.get("slotDate");
        LocalDate slotDate = LocalDate.parse(slotDateStr);

        if (!slotDate.equals(requestedDate)) {
            throw new AppointmentException("Slot date does not match requested appointment date");
        }
    }

    // HELPER: Validate Doctor Not On Leave
    private void validateDoctorNotOnLeave(Long doctorId, LocalDate date) {
        try {
            var response = doctorClient.getDoctorLeaves(doctorId, date);
            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                List<Map<String, Object>> leaves = response.getBody();
                if (!leaves.isEmpty()) {
                    throw new AppointmentException("Doctor is on leave on this date");
                }
            }
        } catch (AppointmentException e) {
            throw e;
        } catch (Exception e) {
            log.warn("Could not check doctor leaves: {}", e.getMessage());
            // Continue if leave service is unavailable
        }
    }

    // HELPER: Validate No Overlapping Appointments
    private void validateNoOverlappingAppointments(Long patientId, LocalDate date, LocalTime time) {
        LocalDateTime startTime = LocalDateTime.of(date, time);
        LocalDateTime endTime = startTime.plusMinutes(30);

        Long count = appointmentRepository.countOverlappingAppointments(patientId, date, startTime, endTime);

        if (count > 0) {
            throw new AppointmentException("Patient already has an appointment at this time");
        }
    }

    // HELPER: Get Consultation Fee
    private BigDecimal getConsultationFee(Map<String, Object> doctorData, ConsultationType type) {
        String feeField = switch (type) {
            case IN_CLINIC -> "consultationFee";
            case ONLINE -> "onlineConsultationFee";
            case EMERGENCY -> "emergencyConsultationFee";
            case HOME_VISIT -> "consultationFee"; // Use default for home visit
        };

        Object feeObj = doctorData.get(feeField);
        if (feeObj != null) {
            return new BigDecimal(feeObj.toString());
        }

        // Fallback to default consultation fee
        Object defaultFee = doctorData.get("consultationFee");
        return defaultFee != null ? new BigDecimal(defaultFee.toString()) : BigDecimal.valueOf(500);
    }


    // HELPER: Book Slot in Doctor Service
    private void bookSlotInDoctorService(Long doctorId, Long slotId, Long appointmentId) {
        try {
            Map<String, Object> bookingData = new HashMap<>();
            bookingData.put("appointmentId", appointmentId);
            bookingData.put("bookedAt", LocalDateTime.now());

            var response = doctorClient.bookSlot(doctorId, slotId, bookingData);
            if (!response.getStatusCode().is2xxSuccessful()) {
                throw new AppointmentException("Failed to book slot in doctor service");
            }
        } catch (Exception e) {
            log.error("Error booking slot: {}", e.getMessage());
            throw new AppointmentException("Failed to book slot: " + e.getMessage());
        }
    }


    // CANCEL APPOINTMENT
    @Transactional
    public AppointmentResponse cancelAppointment(Long appointmentId, CancelAppointmentRequest request,
                                                 String userId, String role) {
        log.info("Cancelling appointment: {}", appointmentId);

        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new AppointmentException("Appointment not found"));

        // Validate can be cancelled
        if (!appointment.canBeCancelled()) {
            throw new AppointmentException("Appointment cannot be cancelled. Current status: " + appointment.getStatus());
        }

        // Determine who is cancelling
        CancelledBy cancelledBy = determineCancelledBy(role);

        // Cancel appointment
        appointment.markAsCancelled(cancelledBy, request.getReason());
        appointment = appointmentRepository.save(appointment);

        // Release slot in Doctor Service
        releaseSlotInDoctorService(appointment.getDoctorId(), appointment.getSlotId());

        // Record history
        recordHistory(appointmentId, AppointmentAction.CANCELLED, userId, request.getReason());

        // Send notification
        sendCancellationNotification(appointment);

        log.info("Appointment cancelled successfully: {}", appointmentId);

        Map<String, Object> patientData = getPatientData(appointment.getPatientId());
        Map<String, Object> doctorData = getDoctorData(appointment.getDoctorId());

        return mapToResponse(appointment, patientData, doctorData);
    }

    // CONFIRM APPOINTMENT
    @Transactional
    public AppointmentResponse confirmAppointment(Long appointmentId, String userId) {
        log.info("Confirming appointment: {}", appointmentId);

        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new AppointmentException("Appointment not found"));

        if (appointment.getStatus() != AppointmentStatus.SCHEDULED) {
            throw new AppointmentException("Only scheduled appointments can be confirmed");
        }

        appointment.markAsConfirmed();
        appointment = appointmentRepository.save(appointment);

        recordHistory(appointmentId, AppointmentAction.CONFIRMED, userId, null);
        sendConfirmationNotification(appointment);

        log.info("Appointment confirmed: {}", appointmentId);

        Map<String, Object> patientData = getPatientData(appointment.getPatientId());
        Map<String, Object> doctorData = getDoctorData(appointment.getDoctorId());

        return mapToResponse(appointment, patientData, doctorData);
    }


    // CHECK-IN APPOINTMENT
    @Transactional
    public AppointmentResponse checkInAppointment(Long appointmentId, String userId) {
        log.info("Checking in appointment: {}", appointmentId);

        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new AppointmentException("Appointment not found"));

        if (!appointment.canCheckIn()) {
            throw new AppointmentException("Appointment cannot be checked in. Current status: " + appointment.getStatus());
        }

        // Validate appointment is today
        if (!appointment.getAppointmentDate().equals(LocalDate.now())) {
            throw new AppointmentException("Check-in is only allowed on appointment date");
        }

        appointment.checkIn();
        appointment = appointmentRepository.save(appointment);

        recordHistory(appointmentId, AppointmentAction.CHECKED_IN, userId, null);

        log.info("Appointment checked in: {}", appointmentId);

        Map<String, Object> patientData = getPatientData(appointment.getPatientId());
        Map<String, Object> doctorData = getDoctorData(appointment.getDoctorId());

        return mapToResponse(appointment, patientData, doctorData);
    }


    // START CONSULTATION
    @Transactional
    public AppointmentResponse startConsultation(Long appointmentId, String userId) {
        log.info("Starting consultation: {}", appointmentId);

        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new AppointmentException("Appointment not found"));

        if (appointment.getStatus() != AppointmentStatus.SCHEDULED &&
                appointment.getStatus() != AppointmentStatus.CONFIRMED) {
            throw new AppointmentException("Cannot start consultation. Current status: " + appointment.getStatus());
        }

        appointment.markAsInProgress();
        appointment = appointmentRepository.save(appointment);

        recordHistory(appointmentId, AppointmentAction.STARTED, userId, null);

        log.info("Consultation started: {}", appointmentId);

        Map<String, Object> patientData = getPatientData(appointment.getPatientId());
        Map<String, Object> doctorData = getDoctorData(appointment.getDoctorId());

        return mapToResponse(appointment, patientData, doctorData);
    }

    // COMPLETE APPOINTMENT
    @Transactional
    public AppointmentResponse completeAppointment(Long appointmentId, String userId) {
        log.info("Completing appointment: {}", appointmentId);

        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new AppointmentException("Appointment not found"));

        if (!appointment.canBeCompleted()) {
            throw new AppointmentException("Only in-progress appointments can be completed");
        }

        appointment.markAsCompleted();
        appointment = appointmentRepository.save(appointment);

        recordHistory(appointmentId, AppointmentAction.COMPLETED, userId, null);
        sendCompletionNotification(appointment);

        log.info("Appointment completed: {}", appointmentId);

        Map<String, Object> patientData = getPatientData(appointment.getPatientId());
        Map<String, Object> doctorData = getDoctorData(appointment.getDoctorId());

        return mapToResponse(appointment, patientData, doctorData);
    }

    // MARK AS NO SHOW
    @Transactional
    public AppointmentResponse markAsNoShow(Long appointmentId, MarkNoShowRequest request, String userId) {
        log.info("Marking appointment as no-show: {}", appointmentId);

        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new AppointmentException("Appointment not found"));

        if (appointment.getStatus() != AppointmentStatus.SCHEDULED &&
                appointment.getStatus() != AppointmentStatus.CONFIRMED) {
            throw new AppointmentException("Cannot mark as no-show. Current status: " + appointment.getStatus());
        }

        appointment.markAsNoShow();
        appointment = appointmentRepository.save(appointment);

        // Release slot
        releaseSlotInDoctorService(appointment.getDoctorId(), appointment.getSlotId());

        recordHistory(appointmentId, AppointmentAction.NO_SHOW, userId, request.getReason());

        log.info("Appointment marked as no-show: {}", appointmentId);

        Map<String, Object> patientData = getPatientData(appointment.getPatientId());
        Map<String, Object> doctorData = getDoctorData(appointment.getDoctorId());

        return mapToResponse(appointment, patientData, doctorData);
    }

    // CHECK CANCELLATION ELIGIBILITY
    public CancellationEligibilityResponse checkCancellationEligibility(Long appointmentId) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new AppointmentException("Appointment not found"));

        if (!appointment.canBeCancelled()) {
            return CancellationEligibilityResponse.builder()
                    .canCancel(false)
                    .reason("Appointment cannot be cancelled. Current status: " + appointment.getStatus())
                    .build();
        }

        LocalDateTime appointmentDateTime = LocalDateTime.of(
                appointment.getAppointmentDate(),
                appointment.getAppointmentTime()
        );

        Duration duration = Duration.between(LocalDateTime.now(), appointmentDateTime);
        long hoursUntil = duration.toHours();

        boolean isFullRefund = hoursUntil >= 24;
        boolean isPartialRefund = hoursUntil >= 12 && hoursUntil < 24;
        int refundPercentage = isFullRefund ? 100 : (isPartialRefund ? 50 : 0);

        return CancellationEligibilityResponse.builder()
                .canCancel(true)
                .reason("Cancellation allowed")
                .isFullRefund(isFullRefund)
                .isPartialRefund(isPartialRefund)
                .refundPercentage(refundPercentage)
                .hoursUntilAppointment(hoursUntil)
                .build();
    }

    // CHECK RESCHEDULE ELIGIBILITY
    public RescheduleEligibilityResponse checkRescheduleEligibility(Long appointmentId) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new AppointmentException("Appointment not found"));

        if (!appointment.canBeRescheduled()) {
            String reason = appointment.getRescheduledCount() >= 2
                    ? "Maximum reschedule limit reached (2 times)"
                    : "Appointment cannot be rescheduled. Current status: " + appointment.getStatus();

            return RescheduleEligibilityResponse.builder()
                    .canReschedule(false)
                    .reason(reason)
                    .remainingReschedules(Math.max(0, 2 - appointment.getRescheduledCount()))
                    .build();
        }

        LocalDateTime appointmentDateTime = LocalDateTime.of(
                appointment.getAppointmentDate(),
                appointment.getAppointmentTime()
        );

        Duration duration = Duration.between(LocalDateTime.now(), appointmentDateTime);
        long hoursUntil = duration.toHours();

        boolean canReschedule = hoursUntil >= 6;
        String reason = canReschedule
                ? "Reschedule allowed"
                : "Must reschedule at least 6 hours before appointment";

        return RescheduleEligibilityResponse.builder()
                .canReschedule(canReschedule)
                .reason(reason)
                .remainingReschedules(2 - appointment.getRescheduledCount())
                .hoursUntilAppointment(hoursUntil)
                .build();
    }


    // GET APPOINTMENT HISTORY
    public List<AppointmentHistoryResponse> getAppointmentHistory(Long appointmentId) {
        List<AppointmentHistory> history = historyRepository
                .findByAppointmentIdOrderByTimestampDesc(appointmentId);

        return history.stream()
                .map(this::mapToHistoryResponse)
                .collect(Collectors.toList());
    }


    // HELPER: Release Slot in Doctor Service
    private void releaseSlotInDoctorService(Long doctorId, Long slotId) {
        try {
            var response = doctorClient.releaseSlot(doctorId, slotId);
            if (!response.getStatusCode().is2xxSuccessful()) {
                log.error("Failed to release slot in doctor service");
            }
        } catch (Exception e) {
            log.error("Error releasing slot: {}", e.getMessage());
        }
    }

    // HELPER: Determine Cancelled By
    private CancelledBy determineCancelledBy(String role) {
        return switch (role.toUpperCase()) {
            case "PATIENT" -> CancelledBy.PATIENT;
            case "DOCTOR" -> CancelledBy.DOCTOR;
            case "ADMIN" -> CancelledBy.ADMIN;
            default -> CancelledBy.SYSTEM;
        };
    }


    // HELPER: Record History
    private void recordHistory(Long appointmentId, AppointmentAction action, String userId, String reason) {
        AppointmentHistory history = AppointmentHistory.builder()
                .appointmentId(appointmentId)
                .action(action)
                .performedBy(userId)
                .reason(reason)
                .timestamp(LocalDateTime.now())
                .build();

        historyRepository.save(history);
    }

    // HELPER: Record Reschedule History
    private void recordRescheduleHistory(Long appointmentId, String userId,
                                         LocalDate oldDate, LocalTime oldTime,
                                         LocalDate newDate, LocalTime newTime, String reason) {
        AppointmentHistory history = AppointmentHistory.builder()
                .appointmentId(appointmentId)
                .action(AppointmentAction.RESCHEDULED)
                .performedBy(userId)
                .previousDate(oldDate)
                .previousTime(oldTime)
                .newDate(newDate)
                .newTime(newTime)
                .reason(reason)
                .timestamp(LocalDateTime.now())
                .build();

        historyRepository.save(history);
    }

    //Reschedule Appointment
    @Transactional
    public AppointmentResponse rescheduleAppointment(Long appointmentId, RescheduleAppointmentRequest request,
                                                     String userId) {
        log.info("Rescheduling appointment: {}", appointmentId);

        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new AppointmentException("Appointment not found"));

        // Validate reschedule eligibility
        if (!appointment.canBeRescheduled()) {
            if (appointment.getRescheduledCount() >= 2) {
                throw new AppointmentException("Maximum reschedule limit reached (2 times)");
            }
            throw new AppointmentException("Appointment cannot be rescheduled. Current status: " + appointment.getStatus());
        }

        // Validate new slot availability
        Map<String, Object> newSlotData = validateSlot(appointment.getDoctorId(), request.getNewSlotId());
        validateSlotDate(newSlotData, request.getNewAppointmentDate());

        // Check overlapping appointments for patient
        validateNoOverlappingAppointments(appointment.getPatientId(), request.getNewAppointmentDate(),
                request.getNewAppointmentTime());

        // Store old appointment details for history and slot release
        LocalDate oldDate = appointment.getAppointmentDate();
        LocalTime oldTime = appointment.getAppointmentTime();
        Long oldSlotId = appointment.getSlotId();

        // Release old slot in Doctor Service
        releaseSlotInDoctorService(appointment.getDoctorId(), oldSlotId);

        // Book new slot in Doctor Service
        bookSlotInDoctorService(appointment.getDoctorId(), request.getNewSlotId(), appointmentId);

        // Update appointment details
        appointment.setSlotId(request.getNewSlotId());
        appointment.setAppointmentDate(request.getNewAppointmentDate());
        appointment.setAppointmentTime(request.getNewAppointmentTime());
        appointment.setAppointmentEndTime(request.getNewAppointmentTime().plusMinutes(30));
        appointment.incrementRescheduleCount();
        appointment.setStatus(AppointmentStatus.SCHEDULED);

        appointment = appointmentRepository.save(appointment);

        // Record reschedule history with old/new details
        recordRescheduleHistory(
                appointmentId,
                userId,
                oldDate,
                oldTime,
                request.getNewAppointmentDate(),
                request.getNewAppointmentTime(),
                request.getReason()
        );

        // Send notifications to patient and doctor
        sendRescheduleNotification(appointment, oldDate, oldTime);

        log.info("Appointment rescheduled successfully: {}", appointmentId);

        // Enrich response data
        Map<String, Object> patientData = getPatientData(appointment.getPatientId());
        Map<String, Object> doctorData = getDoctorData(appointment.getDoctorId());

        return mapToResponse(appointment, patientData, doctorData);
    }



    // HELPER: Get Patient Data
    private Map<String, Object> getPatientData(Long patientId) {
        try {
            var response = patientClient.getPatientById(patientId);
            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                return response.getBody();
            }
        } catch (Exception e) {
            log.warn("Could not fetch patient data: {}", e.getMessage());
        }
        return new HashMap<>();
    }


    // HELPER: Get Doctor Data
    private Map<String, Object> getDoctorData(Long doctorId) {
        try {
            var response = doctorClient.getDoctorById(doctorId);
            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                return response.getBody();
            }
        } catch (Exception e) {
            log.warn("Could not fetch doctor data: {}", e.getMessage());
        }
        return new HashMap<>();
    }


    // HELPER: Send Booking Notification
    private void sendBookingNotification(Appointment appointment,
                                         Map<String, Object> patientData,
                                         Map<String, Object> doctorData) {
        try {
            Map<String, Object> notificationData = new HashMap<>();
            notificationData.put("appointmentId", appointment.getId());
            notificationData.put("appointmentNumber", appointment.getAppointmentNumber());
            notificationData.put("patientEmail", patientData.get("email"));
            notificationData.put("patientPhone", patientData.get("phone"));
            notificationData.put("patientName", patientData.get("name"));
            notificationData.put("doctorName", doctorData.get("name"));
            notificationData.put("doctorSpecialization", doctorData.get("specialization"));
            notificationData.put("appointmentDate", appointment.getAppointmentDate().toString());
            notificationData.put("appointmentTime", appointment.getAppointmentTime().toString());
            notificationData.put("consultationType", appointment.getConsultationType().toString());

            notificationClient.sendAppointmentBookedNotification(notificationData);
        } catch (Exception e) {
            log.warn("Failed to send booking notification: {}", e.getMessage());
        }
    }

    // HELPER: Send Confirmation Notification
    private void sendConfirmationNotification(Appointment appointment) {
        try {
            Map<String, Object> patientData = getPatientData(appointment.getPatientId());
            Map<String, Object> doctorData = getDoctorData(appointment.getDoctorId());

            Map<String, Object> notificationData = new HashMap<>();
            notificationData.put("appointmentId", appointment.getId());
            notificationData.put("appointmentNumber", appointment.getAppointmentNumber());
            notificationData.put("patientEmail", patientData.get("email"));
            notificationData.put("patientPhone", patientData.get("phone"));
            notificationData.put("patientName", patientData.get("name"));
            notificationData.put("doctorName", doctorData.get("name"));
            notificationData.put("appointmentDate", appointment.getAppointmentDate().toString());
            notificationData.put("appointmentTime", appointment.getAppointmentTime().toString());

            notificationClient.sendAppointmentConfirmedNotification(notificationData);
        } catch (Exception e) {
            log.warn("Failed to send confirmation notification: {}", e.getMessage());
        }
    }

    // HELPER: Send Cancellation Notification
    private void sendCancellationNotification(Appointment appointment) {
        try {
            Map<String, Object> patientData = getPatientData(appointment.getPatientId());
            Map<String, Object> doctorData = getDoctorData(appointment.getDoctorId());

            Map<String, Object> notificationData = new HashMap<>();
            notificationData.put("appointmentId", appointment.getId());
            notificationData.put("appointmentNumber", appointment.getAppointmentNumber());
            notificationData.put("patientEmail", patientData.get("email"));
            notificationData.put("patientPhone", patientData.get("phone"));
            notificationData.put("patientName", patientData.get("name"));
            notificationData.put("doctorName", doctorData.get("name"));
            notificationData.put("appointmentDate", appointment.getAppointmentDate().toString());
            notificationData.put("appointmentTime", appointment.getAppointmentTime().toString());
            notificationData.put("cancellationReason", appointment.getCancellationReason());
            notificationData.put("cancelledBy", appointment.getCancelledBy().toString());

            notificationClient.sendAppointmentCancelledNotification(notificationData);
        } catch (Exception e) {
            log.warn("Failed to send cancellation notification: {}", e.getMessage());
        }
    }

    // HELPER: Send Reschedule Notification
    private void sendRescheduleNotification(Appointment appointment, LocalDate oldDate, LocalTime oldTime) {
        try {
            Map<String, Object> patientData = getPatientData(appointment.getPatientId());
            Map<String, Object> doctorData = getDoctorData(appointment.getDoctorId());

            Map<String, Object> notificationData = new HashMap<>();
            notificationData.put("appointmentId", appointment.getId());
            notificationData.put("appointmentNumber", appointment.getAppointmentNumber());
            notificationData.put("patientEmail", patientData.get("email"));
            notificationData.put("patientPhone", patientData.get("phone"));
            notificationData.put("patientName", patientData.get("name"));
            notificationData.put("doctorName", doctorData.get("name"));
            notificationData.put("oldDate", oldDate.toString());
            notificationData.put("oldTime", oldTime.toString());
            notificationData.put("newDate", appointment.getAppointmentDate().toString());
            notificationData.put("newTime", appointment.getAppointmentTime().toString());

            notificationClient.sendAppointmentRescheduledNotification(notificationData);
        } catch (Exception e) {
            log.warn("Failed to send reschedule notification: {}", e.getMessage());
        }
    }

    // HELPER: Send Completion Notification
    private void sendCompletionNotification(Appointment appointment) {
        try {
            Map<String, Object> patientData = getPatientData(appointment.getPatientId());
            Map<String, Object> doctorData = getDoctorData(appointment.getDoctorId());

            Map<String, Object> notificationData = new HashMap<>();
            notificationData.put("appointmentId", appointment.getId());
            notificationData.put("appointmentNumber", appointment.getAppointmentNumber());
            notificationData.put("patientEmail", patientData.get("email"));
            notificationData.put("patientPhone", patientData.get("phone"));
            notificationData.put("patientName", patientData.get("name"));
            notificationData.put("doctorName", doctorData.get("name"));
            notificationData.put("appointmentDate", appointment.getAppointmentDate().toString());

            notificationClient.sendAppointmentCompletedNotification(notificationData);
        } catch (Exception e) {
            log.warn("Failed to send completion notification: {}", e.getMessage());
        }
    }

    // HELPER: Map to Response
    private AppointmentResponse mapToResponse(Appointment appointment,
                                              Map<String, Object> patientData,
                                              Map<String, Object> doctorData) {
        return AppointmentResponse.builder()
                .id(appointment.getId())
                .appointmentNumber(appointment.getAppointmentNumber())
                .patientId(appointment.getPatientId())
                .patientName(patientData != null ? (String) patientData.get("name") : null)
                .doctorId(appointment.getDoctorId())
                .doctorName(doctorData != null ? (String) doctorData.get("name") : null)
                .doctorSpecialization(doctorData != null ? (String) doctorData.get("specialization") : null)
                .appointmentDate(appointment.getAppointmentDate())
                .appointmentTime(appointment.getAppointmentTime())
                .appointmentEndTime(appointment.getAppointmentEndTime())
                .consultationType(appointment.getConsultationType())
                .status(appointment.getStatus())
                .reasonForVisit(appointment.getReasonForVisit())
                .symptoms(appointment.getSymptoms())
                .notes(appointment.getNotes())
                .consultationFee(appointment.getConsultationFee())
                .paymentStatus(appointment.getPaymentStatus())
                .bookingDate(appointment.getBookingDate())
                .confirmedAt(appointment.getConfirmedAt())
                .completedAt(appointment.getCompletedAt())
                .cancelledAt(appointment.getCancelledAt())
                .cancellationReason(appointment.getCancellationReason())
                .cancelledBy(appointment.getCancelledBy())
                .rescheduledCount(appointment.getRescheduledCount())
                .isEmergency(appointment.getIsEmergency())
                .checkedIn(appointment.getCheckedIn())
                .checkInTime(appointment.getCheckInTime())
                .invoiceId(appointment.getInvoiceId())
                .invoiceNumber(appointment.getInvoiceNumber())
                .createdAt(appointment.getCreatedAt())
                .updatedAt(appointment.getUpdatedAt())
                .message("Appointment retrieved successfully")
                .build();
    }

    // HELPER: Map to History Response
    private AppointmentHistoryResponse mapToHistoryResponse(AppointmentHistory history) {
        return AppointmentHistoryResponse.builder()
                .id(history.getId())
                .appointmentId(history.getAppointmentId())
                .action(history.getAction())
                .performedBy(history.getPerformedBy())
                .performedByName(history.getPerformedBy()) // TODO: Fetch actual name
                .previousDate(history.getPreviousDate())
                .previousTime(history.getPreviousTime())
                .newDate(history.getNewDate())
                .newTime(history.getNewTime())
                .reason(history.getReason())
                .notes(history.getNotes())
                .timestamp(history.getTimestamp())
                .build();
    }
}