package com.medicare.appointment_service.Entity;

import com.medicare.appointment_service.Enums.AppointmentAction;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Entity
@Table(name = "appointment_history", indexes = {
        @Index(name = "idx_appointment_id", columnList = "appointmentId"),
        @Index(name = "idx_performed_by", columnList = "performedBy"),
        @Index(name = "idx_timestamp", columnList = "timestamp")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AppointmentHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long appointmentId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private AppointmentAction action;

    @Column(nullable = false)
    private String performedBy; // userId who performed the action

    private LocalDate previousDate;

    private LocalTime previousTime;

    private LocalDate newDate;

    private LocalTime newTime;

    @Column(columnDefinition = "TEXT")
    private String reason;

    @Column(columnDefinition = "TEXT")
    private String notes;

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private LocalDateTime timestamp;
}
