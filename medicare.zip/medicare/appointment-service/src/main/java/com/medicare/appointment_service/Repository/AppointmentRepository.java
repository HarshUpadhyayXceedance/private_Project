package com.medicare.appointment_service.Repository;

import com.medicare.appointment_service.Entity.Appointment;
import com.medicare.appointment_service.Enums.AppointmentStatus;
import com.medicare.appointment_service.Enums.ConsultationType;
import com.medicare.appointment_service.Enums.PaymentStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Long> {

    // Find by appointment number
    Optional<Appointment> findByAppointmentNumber(String appointmentNumber);

    // Find by patient
    Page<Appointment> findByPatientIdOrderByAppointmentDateDescAppointmentTimeDesc(
            Long patientId, Pageable pageable);

    List<Appointment> findByPatientIdAndStatusIn(
            Long patientId, List<AppointmentStatus> statuses);

    // Find by doctor
    Page<Appointment> findByDoctorIdOrderByAppointmentDateDescAppointmentTimeDesc(
            Long doctorId, Pageable pageable);

    List<Appointment> findByDoctorIdAndStatusIn(
            Long doctorId, List<AppointmentStatus> statuses);

    List<Appointment> findByDoctorIdAndAppointmentDate(Long doctorId, LocalDate date);

    List<Appointment> findByDoctorIdAndAppointmentDateAndStatusIn(
            Long doctorId, LocalDate date, List<AppointmentStatus> statuses);

    // Find by status
    Page<Appointment> findByStatus(AppointmentStatus status, Pageable pageable);

    List<Appointment> findByStatusAndAppointmentDateBefore(
            AppointmentStatus status, LocalDate date);

    // Find by date range
    @Query("SELECT a FROM Appointment a WHERE a.patientId = :patientId " +
            "AND a.appointmentDate BETWEEN :startDate AND :endDate " +
            "ORDER BY a.appointmentDate DESC, a.appointmentTime DESC")
    Page<Appointment> findPatientAppointmentsByDateRange(
            @Param("patientId") Long patientId,
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate,
            Pageable pageable);

    @Query("SELECT a FROM Appointment a WHERE a.doctorId = :doctorId " +
            "AND a.appointmentDate BETWEEN :startDate AND :endDate " +
            "ORDER BY a.appointmentDate DESC, a.appointmentTime DESC")
    Page<Appointment> findDoctorAppointmentsByDateRange(
            @Param("doctorId") Long doctorId,
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate,
            Pageable pageable);

    // Check overlapping appointments
    @Query("SELECT COUNT(a) FROM Appointment a WHERE a.patientId = :patientId " +
            "AND a.appointmentDate = :date " +
            "AND a.status IN ('SCHEDULED', 'CONFIRMED', 'IN_PROGRESS') " +
            "AND ((a.appointmentTime <= :startTime AND a.appointmentEndTime > :startTime) " +
            "OR (a.appointmentTime < :endTime AND a.appointmentEndTime >= :endTime) " +
            "OR (a.appointmentTime >= :startTime AND a.appointmentEndTime <= :endTime))")
    Long countOverlappingAppointments(
            @Param("patientId") Long patientId,
            @Param("date") LocalDate date,
            @Param("startTime") LocalDateTime startTime,
            @Param("endTime") LocalDateTime endTime);

    // Statistics queries
    @Query("SELECT COUNT(a) FROM Appointment a WHERE a.doctorId = :doctorId AND a.status = :status")
    Long countByDoctorIdAndStatus(@Param("doctorId") Long doctorId, @Param("status") AppointmentStatus status);

    @Query("SELECT COUNT(a) FROM Appointment a WHERE a.patientId = :patientId AND a.status = :status")
    Long countByPatientIdAndStatus(@Param("patientId") Long patientId, @Param("status") AppointmentStatus status);

    @Query("SELECT COUNT(a) FROM Appointment a WHERE a.doctorId = :doctorId " +
            "AND a.appointmentDate = :date AND a.status IN :statuses")
    Long countByDoctorIdAndDateAndStatusIn(
            @Param("doctorId") Long doctorId,
            @Param("date") LocalDate date,
            @Param("statuses") List<AppointmentStatus> statuses);

    // Revenue calculation
    @Query("SELECT SUM(a.consultationFee) FROM Appointment a WHERE a.doctorId = :doctorId " +
            "AND a.status = 'COMPLETED' AND a.paymentStatus = 'PAID'")
    Double calculateDoctorRevenue(@Param("doctorId") Long doctorId);

    // Search appointments
    @Query("SELECT a FROM Appointment a WHERE " +
            "(LOWER(a.appointmentNumber) LIKE LOWER(CONCAT('%', :query, '%')) " +
            "OR LOWER(a.reasonForVisit) LIKE LOWER(CONCAT('%', :query, '%')) " +
            "OR LOWER(a.symptoms) LIKE LOWER(CONCAT('%', :query, '%'))) " +
            "ORDER BY a.appointmentDate DESC, a.appointmentTime DESC")
    Page<Appointment> searchAppointments(@Param("query") String query, Pageable pageable);

    // Find appointments needing reminders
    @Query("SELECT a FROM Appointment a WHERE a.status IN ('SCHEDULED', 'CONFIRMED') " +
            "AND a.appointmentDate = :date " +
            "AND a.appointmentTime BETWEEN :startTime AND :endTime")
    List<Appointment> findAppointmentsForReminder(
            @Param("date") LocalDate date,
            @Param("startTime") LocalDateTime startTime,
            @Param("endTime") LocalDateTime endTime);

    // Find unpaid appointments
    List<Appointment> findByPaymentStatusAndBookingDateBefore(
            PaymentStatus paymentStatus, LocalDateTime dateTime);

    // Find by consultation type
    Page<Appointment> findByConsultationType(ConsultationType type, Pageable pageable);

    // Count today's appointments
    @Query("SELECT COUNT(a) FROM Appointment a WHERE a.doctorId = :doctorId " +
            "AND a.appointmentDate = CURRENT_DATE")
    Long countTodayAppointments(@Param("doctorId") Long doctorId);

    // Get next appointment number sequence
    @Query("SELECT MAX(CAST(SUBSTRING(a.appointmentNumber, 10) AS integer)) FROM Appointment a " +
            "WHERE a.appointmentNumber LIKE :prefix")
    Integer getLastAppointmentSequence(@Param("prefix") String prefix);

}

