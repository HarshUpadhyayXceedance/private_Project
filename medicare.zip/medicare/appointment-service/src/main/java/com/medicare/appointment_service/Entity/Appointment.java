package com.medicare.appointment_service.Entity;

import com.medicare.appointment_service.Enums.*;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Entity
@Table(name = "appointments", indexes = {
        @Index(name = "idx_appointment_number", columnList = "appointmentNumber"),
        @Index(name = "idx_patient_id", columnList = "patientId"),
        @Index(name = "idx_doctor_id", columnList = "doctorId"),
        @Index(name = "idx_appointment_date", columnList = "appointmentDate"),
        @Index(name = "idx_status", columnList = "status"),
        @Index(name = "idx_doctor_date", columnList = "doctorId,appointmentDate"),
        @Index(name = "idx_patient_date", columnList = "patientId,appointmentDate")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false, length = 50)
    private String appointmentNumber; // APT-2025-000001

    @Column(nullable = false)
    private Long patientId;

    @Column(nullable = false)
    private Long doctorId;

    @Column(nullable = false)
    private Long slotId;

    @Column(nullable = false)
    private LocalDate appointmentDate;

    @Column(nullable = false)
    private LocalTime appointmentTime;

    @Column(nullable = false)
    private LocalTime appointmentEndTime;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private ConsultationType consultationType;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private AppointmentStatus status;

    @Column(columnDefinition = "TEXT")
    private String reasonForVisit;

    @Column(columnDefinition = "TEXT")
    private String symptoms;

    @Column(columnDefinition = "TEXT")
    private String notes;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal consultationFee;

    @Enumerated(EnumType.STRING)
    @Column(length = 20)
    private PaymentStatus paymentStatus;

    private LocalDateTime bookingDate;

    private LocalDateTime confirmedAt;

    private LocalDateTime completedAt;

    private LocalDateTime cancelledAt;

    @Column(columnDefinition = "TEXT")
    private String cancellationReason;

    @Enumerated(EnumType.STRING)
    @Column(length = 20)
    private CancelledBy cancelledBy;

    @Column(nullable = false)
    private Integer rescheduledCount = 0;

    @Column(nullable = false)
    private Boolean isEmergency = false;

    @Column(nullable = false)
    private Boolean checkedIn = false;

    private LocalDateTime checkInTime;

    // Invoice details (from Billing Service)
    private Long invoiceId;

    private String invoiceNumber;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        if (bookingDate == null) {
            bookingDate = LocalDateTime.now();
        }
        if (status == null) {
            status = AppointmentStatus.SCHEDULED;
        }
        if (paymentStatus == null) {
            paymentStatus = PaymentStatus.PENDING;
        }
        if (rescheduledCount == null) {
            rescheduledCount = 0;
        }
        if (isEmergency == null) {
            isEmergency = false;
        }
        if (checkedIn == null) {
            checkedIn = false;
        }
    }

    // Helper methods
    public boolean canBeCancelled() {
        return status == AppointmentStatus.SCHEDULED ||
                status == AppointmentStatus.CONFIRMED;
    }

    public boolean canBeRescheduled() {
        return (status == AppointmentStatus.SCHEDULED ||
                status == AppointmentStatus.CONFIRMED) &&
                rescheduledCount < 2;
    }

    public boolean canBeCompleted() {
        return status == AppointmentStatus.IN_PROGRESS;
    }

    public boolean canCheckIn() {
        return status == AppointmentStatus.SCHEDULED ||
                status == AppointmentStatus.CONFIRMED;
    }

    public void markAsConfirmed() {
        this.status = AppointmentStatus.CONFIRMED;
        this.confirmedAt = LocalDateTime.now();
    }

    public void markAsInProgress() {
        this.status = AppointmentStatus.IN_PROGRESS;
    }

    public void markAsCompleted() {
        this.status = AppointmentStatus.COMPLETED;
        this.completedAt = LocalDateTime.now();
    }

    public void markAsCancelled(CancelledBy cancelledBy, String reason) {
        this.status = AppointmentStatus.CANCELLED;
        this.cancelledBy = cancelledBy;
        this.cancellationReason = reason;
        this.cancelledAt = LocalDateTime.now();
    }

    public void markAsNoShow() {
        this.status = AppointmentStatus.NO_SHOW;
    }

    public void checkIn() {
        this.checkedIn = true;
        this.checkInTime = LocalDateTime.now();
    }

    public void incrementRescheduleCount() {
        this.rescheduledCount++;
    }
}
