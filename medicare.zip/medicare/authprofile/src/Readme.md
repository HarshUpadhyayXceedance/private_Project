# 🏥 Combined Auth-Profile Service - Complete Project Summary

---

## 🗂️ Complete Directory Structure

```
auth-profile-service/
├── pom.xml
├── README.md
├── PROJECT_SUMMARY.md
│
├── src/
│   ├── main/
│   │   ├── java/com/healthcare/authprofile/
│   │   │   │
│   │   │   ├── AuthProfileServiceApplication.java
│   │   │   │
│   │   │   ├── entity/
│   │   │   │   ├── User.java
│   │   │   │   └── UserProfile.java
│   │   │   │
│   │   │   ├── enums/
│   │   │   │   ├── Role.java
│   │   │   │   ├── UserStatus.java
│   │   │   │   ├── Gender.java
│   │   │   │   └── ProfileStatus.java
│   │   │   │
│   │   │   ├── dto/
│   │   │   │   ├── RegisterRequest.java
│   │   │   │   ├── LoginRequest.java
│   │   │   │   ├── AuthResponse.java
│   │   │   │   ├── ProfileData.java
│   │   │   │   ├── CreateProfileRequest.java
│   │   │   │   ├── UpdateProfileRequest.java
│   │   │   │   ├── ProfileResponse.java
│   │   │   │   ├── ProfileStatusResponse.java
│   │   │   │   ├── ApprovalRequest.java
│   │   │   │   └── ErrorResponse.java
│   │   │   │
│   │   │   ├── repository/
│   │   │   │   ├── UserRepository.java
│   │   │   │   └── UserProfileRepository.java
│   │   │   │
│   │   │   ├── service/
│   │   │   │   ├── AuthService.java
│   │   │   │   └── ProfileService.java
│   │   │   │
│   │   │   ├── controller/
│   │   │   │   ├── AuthController.java
│   │   │   │   └── ProfileController.java
│   │   │   │
│   │   │   ├── security/
│   │   │   │   ├── JwtUtil.java
│   │   │   │   └── JwtAuthenticationFilter.java
│   │   │   │
│   │   │   ├── config/
│   │   │   │   └── SecurityConfig.java
│   │   │   │
│   │   │   └── exception/
│   │   │       ├── AuthException.java
│   │   │       ├── ProfileException.java
│   │   │       └── GlobalExceptionHandler.java
│   │   │
│   │   └── resources/
│   │       └── application.yml
│   │
│   └── test/ (to be created)
│
└── target/ (generated after build)
```

---

## 🎯 Key Features Summary

### Authentication Features
1. ✅ User registration with automatic role-based status assignment
2. ✅ JWT token generation with user claims
3. ✅ Login with email or username
4. ✅ Token validation endpoint
5. ✅ User status management (PENDING, ACTIVE, BLOCKED)
6. ✅ Password encryption with BCrypt
7. ✅ Admin endpoints for user management

### Profile Management Features
1. ✅ Complete profile creation after registration
2. ✅ One-to-one relationship with User entity
3. ✅ Automatic profile status based on role
4. ✅ Profile CRUD operations
5. ✅ Doctor approval workflow
6. ✅ Admin approval/rejection with reasons
7. ✅ Partial profile updates (PATCH)
8. ✅ Role-based filtering
9. ✅ Status-based filtering
10. ✅ Profile status tracking

### Security Features
1. ✅ JWT-based authentication
2. ✅ Role-based access control (@PreAuthorize)
3. ✅ User isolation (users can only access their own data)
4. ✅ Admin-only endpoints
5. ✅ Token expiration handling
6. ✅ Stateless session management
7. ✅ Global exception handling

---

## 📊 API Endpoints Summary

### Authentication Endpoints (6 endpoints)
| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| POST | `/auth/register` | Public | Register new user |
| POST | `/auth/login` | Public | User login |
| GET | `/auth/user/{userId}` | Authenticated | Get user by ID |
| POST | `/auth/validate-token` | Authenticated | Validate JWT token |
| PATCH | `/auth/admin/user/{userId}/status` | Admin | Update user status |
| GET | `/auth/health` | Public | Health check |

### Profile Management Endpoints (9 endpoints)
| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| POST | `/profiles` | User | Create profile |
| GET | `/profiles/{userId}` | User/Admin | Get profile by user ID |
| GET | `/profiles` | Admin | Get all profiles |
| GET | `/profiles/role/{role}` | Admin | Get profiles by role |
| GET | `/profiles/status/{status}` | Admin | Get profiles by status |
| PATCH | `/profiles/{userId}` | User/Admin | Update profile |
| PUT | `/profiles/admin/approve/{userId}` | Admin | Approve profile |
| PUT | `/profiles/admin/reject/{userId}` | Admin | Reject profile |
| GET | `/profiles/status/{userId}` | User/Admin | Get profile status |

**Total Endpoints: 15**

---

## 🔄 Data Flow

### Registration Flow
```
User → POST /auth/register
  ├─> Validate input
  ├─> Check email/username uniqueness
  ├─> Create User entity
  │   ├─> role = PATIENT → status = ACTIVE
  │   └─> role = DOCTOR → status = PENDING
  ├─> Generate JWT token
  └─> Return: userId, role, status, token
```

### Profile Creation Flow
```
User → POST /profiles (with token)
  ├─> Validate token
  ├─> Extract userId from token
  ├─> Check if profile already exists
  ├─> Get User entity
  ├─> Create UserProfile entity
  │   ├─> role = PATIENT → profileStatus = APPROVED
  │   └─> role = DOCTOR → profileStatus = PENDING_APPROVAL
  ├─> Link UserProfile to User (One-to-One)
  └─> Return: Complete profile response
```

### Doctor Approval Flow
```
Admin → PUT /profiles/admin/approve/{userId}
  ├─> Validate admin token
  ├─> Get UserProfile by userId
  ├─> Check profileStatus = PENDING_APPROVAL
  ├─> Update profileStatus = APPROVED
  ├─> Update User.status = ACTIVE
  └─> Return: Approval confirmation
```

### Login Flow
```
User → POST /auth/login
  ├─> Find user by email/username
  ├─> Verify password
  ├─> Check user status (not BLOCKED)
  ├─> Generate new JWT token
  ├─> Fetch UserProfile if exists
  └─> Return: userId, role, status, token, profileData
```

---

## 🗄️ Database Schema

### Table: users
| Column | Type | Constraints |
|--------|------|-------------|
| user_id | VARCHAR(255) | PRIMARY KEY |
| email | VARCHAR(255) | UNIQUE, NOT NULL |
| username | VARCHAR(255) | UNIQUE, NOT NULL |
| password | VARCHAR(255) | NOT NULL |
| role | VARCHAR(20) | NOT NULL |
| status | VARCHAR(20) | NOT NULL, DEFAULT 'PENDING' |
| created_at | TIMESTAMP | NOT NULL |
| updated_at | TIMESTAMP | NOT NULL |

### Table: user_profiles
| Column | Type | Constraints |
|--------|------|-------------|
| user_id | VARCHAR(255) | PRIMARY KEY, FOREIGN KEY → users.user_id |
| name | VARCHAR(255) | NOT NULL |
| gender | VARCHAR(20) | NOT NULL |
| dob | DATE | NOT NULL |
| phone | VARCHAR(15) | NOT NULL |
| address | TEXT | NOT NULL |
| profile_picture | VARCHAR(500) | NULL |
| profile_status | VARCHAR(30) | NOT NULL, DEFAULT 'INCOMPLETE' |
| created_at | TIMESTAMP | NOT NULL |
| updated_at | TIMESTAMP | NOT NULL |

**Relationship:** One-to-One (User ↔ UserProfile)

---

## 🚀 Quick Start Guide

### 1. Prerequisites Check
```bash
# Check Java version (17+)
java -version

# Check Maven version (3.8+)
mvn -version

# Check MySQL is running
mysql --version
```

### 2. Database Setup
```sql
CREATE DATABASE auth_profile_db;
```

### 3. Configure Application
Edit `src/main/resources/application.yml`:
- Update database credentials
- Verify JWT secret
- Check port number (default: 8080)

### 4. Build and Run
```bash
# Build
mvn clean install

# Run
mvn spring-boot:run

# Or run JAR
java -jar target/auth-profile-service-1.0.0.jar
```

### 5. Test the Service
```bash
# Health check
curl http://localhost:8080/api/auth-profile/auth/health

# Register a patient
curl -X POST http://localhost:8080/api/auth-profile/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","username":"testuser","password":"password123","role":"PATIENT"}'
```

---

## 📝 Environment Variables (Optional)

You can override configuration using environment variables:

```bash
# Database
export DB_URL=jdbc:mysql://localhost:3306/auth_profile_db
export DB_USERNAME=root
export DB_PASSWORD=your_password

# JWT
export JWT_SECRET=your-secret-key
export JWT_EXPIRATION=900000

# Server
export SERVER_PORT=8080
```

---

## 🔍 Monitoring & Health

### Health Check Endpoint
```bash
curl http://localhost:8080/api/auth-profile/auth/health
```

### Actuator Endpoints (if enabled)
- `/actuator/health` - Application health
- `/actuator/info` - Application info
- `/actuator/metrics` - Application metrics
- `/actuator/prometheus` - Prometheus metrics

---

## 🧪 Sample Test Data

### Create Admin User (Manual SQL)
```sql
INSERT INTO users (user_id, email, username, password, role, status, created_at, updated_at)
VALUES (
  'admin-001',
  'admin@medicare.com',
  'admin',
  '$2a$10$encrypted_password_here',
  'ADMIN',
  'ACTIVE',
  NOW(),
  NOW()
);
```

### Create Test Patient
```bash
curl -X POST http://localhost:8080/api/auth-profile/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "patient@test.com",
    "username": "patient001",
    "password": "test123",
    "role": "PATIENT"
  }'
```

### Create Test Doctor
```bash
curl -X POST http://localhost:8080/api/auth-profile/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "doctor@test.com",
    "username": "doctor001",
    "password": "test123",
    "role": "DOCTOR"
  }'
```

---

## ✅ Implementation Checklist

### Core Functionality
- [x] User registration with role-based status
- [x] User login with JWT generation
- [x] Token validation
- [x] Profile creation after registration
- [x] Profile CRUD operations
- [x] Doctor approval workflow
- [x] Admin user management
- [x] Role-based access control
- [x] User isolation
- [x] Global exception handling

### Security
- [x] Password encryption (BCrypt)
- [x] JWT token generation
- [x] JWT token validation
- [x] Role-based authorization
- [x] Protected endpoints
- [x] Token expiration handling
- [x] Stateless authentication

### Database
- [x] User entity
- [x] UserProfile entity
- [x] One-to-One relationship
- [x] Auto-generated user_id (UUID)
- [x] Timestamps (created_at, updated_at)
- [x] Enums for status fields

### API Endpoints
- [x] Registration endpoint
- [x] Login endpoint
- [x] Profile creation endpoint
- [x] Profile update endpoint
- [x] Profile retrieval endpoints
- [x] Admin approval endpoints
- [x] Admin filtering endpoints
- [x] Health check endpoint

### Documentation
- [x] Complete README
- [x] API documentation
- [x] User flow diagrams
- [x] Testing examples
- [x] Troubleshooting guide
- [x] Project summary

---

### Service URL:
```
http://localhost:8080/api/auth-profile
```
