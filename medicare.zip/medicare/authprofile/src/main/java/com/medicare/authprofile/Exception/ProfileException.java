package com.medicare.authprofile.Exception;

public class ProfileException extends RuntimeException {
    public ProfileException(String message) {
        super(message);
    }
}
