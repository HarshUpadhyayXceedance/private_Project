package com.medicare.authprofile.Controller;


import com.medicare.authprofile.Dto.AuthResponse;
import com.medicare.authprofile.Dto.LoginRequest;
import com.medicare.authprofile.Dto.RegisterRequest;
import com.medicare.authprofile.Entity.User;
import com.medicare.authprofile.enums.UserStatus;
import com.medicare.authprofile.Service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "*")
public class AuthController {

    private final AuthService authService;

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@Valid @RequestBody RegisterRequest request) {
        log.info("POST /auth/register - Registration request for email: {}", request.getEmail());
        AuthResponse response = authService.register(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody LoginRequest request) {
        log.info("POST /auth/login - Login request for: {}", request.getEmailOrUsername());
        AuthResponse response = authService.login(request);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/user/{userId}")
    @PreAuthorize("hasAnyRole('ADMIN', 'EMPLOYEE', 'PATIENT')")
    public ResponseEntity<Map<String, Object>> getUserById(@PathVariable String userId) {
        log.info("GET /auth/user/{} - Get user by ID", userId);
        User user = authService.getUserById(userId);

        Map<String, Object> response = new HashMap<>();
        response.put("userId", user.getUserId());
        response.put("email", user.getEmail());
        response.put("username", user.getUsername());
        response.put("role", user.getRole().name());
        response.put("status", user.getStatus().name());
        response.put("createdAt", user.getCreatedAt());

        return ResponseEntity.ok(response);
    }

    @PatchMapping("/admin/user/{userId}/status")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Map<String, String>> updateUserStatus(
            @PathVariable String userId,
            @RequestParam String status
    ) {
        log.info("PATCH /auth/admin/user/{}/status - Update status to: {}", userId, status);

        UserStatus userStatus = UserStatus.valueOf(status.toUpperCase());
        authService.updateUserStatus(userId, userStatus);

        Map<String, String> response = new HashMap<>();
        response.put("message", "User status updated successfully");
        response.put("userId", userId);
        response.put("status", status);

        return ResponseEntity.ok(response);
    }

    @PostMapping("/validate-token")
    public ResponseEntity<Map<String, Object>> validateToken(@RequestHeader("Authorization") String authHeader) {
        log.info("POST /auth/validate-token - Validating token");

        String token = authHeader.substring(7); // Remove "Bearer " prefix
        boolean isValid = authService.validateToken(token);

        Map<String, Object> response = new HashMap<>();
        response.put("valid", isValid);

        if (isValid) {
            response.put("userId", authService.extractUserIdFromToken(token));
            response.put("role", authService.extractRoleFromToken(token));
        }

        return ResponseEntity.ok(response);
    }

    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        Map<String, String> response = new HashMap<>();
        response.put("status", "UP");
        response.put("service", "Auth-Profile Service");
        return ResponseEntity.ok(response);
    }
}