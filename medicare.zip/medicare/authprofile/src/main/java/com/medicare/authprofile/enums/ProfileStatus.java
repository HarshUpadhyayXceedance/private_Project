package com.medicare.authprofile.enums;

public enum ProfileStatus {
    INCOMPLETE,         // Profile not yet completed
    PENDING_APPROVAL,   // Doctor profile awaiting approval
    APPROVED,           // Profile approved
    REJECTED            // Profile rejected by admin
}