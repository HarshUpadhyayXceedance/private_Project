package com.medicare.authprofile.Controller;

import com.medicare.authprofile.Dto.*;
import com.medicare.authprofile.Dto.*;
import com.medicare.authprofile.enums.ProfileStatus;
import com.medicare.authprofile.Service.ProfileService;
import com.medicare.authprofile.enums.Role;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/profiles")
@RequiredArgsConstructor
@Slf4j
public class ProfileController {

    private final ProfileService profileService;

    @PostMapping
    @PreAuthorize("hasAnyRole('DOCTOR', 'PATIENT')")
    public ResponseEntity<ProfileResponse> createProfile(
            @Valid @RequestBody CreateProfileRequest request,
            Authentication authentication
    ) {
        String authenticatedUserId = authentication.getName();
        log.info("POST /profiles - Create profile for userId: {}", authenticatedUserId);

        ProfileResponse response = profileService.createProfile(authenticatedUserId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/{userId}")
    @PreAuthorize("hasAnyRole('ADMIN', 'DOCTOR', 'PATIENT')")
    public ResponseEntity<ProfileResponse> getProfileByUserId(
            @PathVariable String userId,
            Authentication authentication
    ) {
        log.info("GET /profiles/{} - Get profile", userId);

        String authenticatedUserId = authentication.getName();
        String role = authentication.getAuthorities().iterator().next().getAuthority();

        // Users can only view their own profile unless they're admin
        if (!role.equals("ROLE_ADMIN") && !authenticatedUserId.equals(userId)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        ProfileResponse response = profileService.getProfileByUserId(userId);
        return ResponseEntity.ok(response);
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<ProfileResponse>> getAllProfiles() {
        log.info("GET /profiles - Get all profiles");
        List<ProfileResponse> profiles = profileService.getAllProfiles();
        return ResponseEntity.ok(profiles);
    }

    @GetMapping("/role/{role}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<ProfileResponse>> getProfilesByRole(@PathVariable Role role) {
        log.info("GET /profiles/role/{} - Get profiles by role", role);
        List<ProfileResponse> profiles = profileService.getProfilesByRole(role);
        return ResponseEntity.ok(profiles);
    }

    @GetMapping("/status/{status}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<ProfileResponse>> getProfilesByStatus(@PathVariable String status) {
        log.info("GET /profiles/status/{} - Get profiles by status", status);
        ProfileStatus profileStatus = ProfileStatus.valueOf(status.toUpperCase());
        List<ProfileResponse> profiles = profileService.getProfilesByStatus(profileStatus);
        return ResponseEntity.ok(profiles);
    }

    @PatchMapping("/{userId}")
    @PreAuthorize("hasAnyRole('ADMIN', 'DOCTOR', 'PATIENT')")
    public ResponseEntity<ProfileResponse> updateProfile(
            @PathVariable String userId,
            @Valid @RequestBody UpdateProfileRequest request,
            Authentication authentication
    ) {
        log.info("PATCH /profiles/{} - Update profile", userId);

        String authenticatedUserId = authentication.getName();
        String role = authentication.getAuthorities().iterator().next().getAuthority();

        // Users can only update their own profile unless they're admin
        if (!role.equals("ROLE_ADMIN") && !authenticatedUserId.equals(userId)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        ProfileResponse response = profileService.updateProfile(userId, request);
        return ResponseEntity.ok(response);
    }

    @PutMapping("/admin/approve/{userId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ProfileStatusResponse> approveProfile(@PathVariable String userId) {
        log.info("PUT /profiles/admin/approve/{} - Approve profile", userId);
        ProfileStatusResponse response = profileService.approveProfile(userId);
        return ResponseEntity.ok(response);
    }

    @PutMapping("/admin/reject/{userId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ProfileStatusResponse> rejectProfile(
            @PathVariable String userId,
            @RequestBody ApprovalRequest request
    ) {
        log.info("PUT /profiles/admin/reject/{} - Reject profile", userId);
        ProfileStatusResponse response = profileService.rejectProfile(userId, request.getReason());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/status/{userId}")
    @PreAuthorize("hasAnyRole('ADMIN', 'DOCTOR', 'PATIENT')")
    public ResponseEntity<ProfileStatusResponse> getProfileStatus(
            @PathVariable String userId,
            Authentication authentication
    ) {
        log.info("GET /profiles/status/{} - Get profile status", userId);

        String authenticatedUserId = authentication.getName();
        String role = authentication.getAuthorities().iterator().next().getAuthority();

        // Users can only view their own status unless they're admin
        if (!role.equals("ROLE_ADMIN") && !authenticatedUserId.equals(userId)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        ProfileStatusResponse response = profileService.getProfileStatus(userId);
        return ResponseEntity.ok(response);
    }
}