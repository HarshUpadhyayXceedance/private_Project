package com.medicare.authprofile.Service;


import com.medicare.authprofile.Dto.AuthResponse;
import com.medicare.authprofile.Dto.LoginRequest;
import com.medicare.authprofile.Dto.ProfileData;
import com.medicare.authprofile.Dto.RegisterRequest;
import com.medicare.authprofile.Entity.User;
import com.medicare.authprofile.Entity.UserProfile;
import com.medicare.authprofile.enums.Role;
import com.medicare.authprofile.enums.UserStatus;
import com.medicare.authprofile.Exception.AuthException;
import com.medicare.authprofile.Repository.UserProfileRepository;
import com.medicare.authprofile.Repository.UserRepository;
import com.medicare.authprofile.Security.JwtUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthService {

    private final UserRepository userRepository;
    private final UserProfileRepository userProfileRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    @Transactional
    public AuthResponse register(RegisterRequest request) {
        log.info("Registration attempt for email: {}", request.getEmail());

        // Check if email already exists
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new AuthException("Email already registered");
        }

        // Check if username already exists
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new AuthException("Username already taken");
        }

        // Validate role
        if (request.getRole() == null) {
            throw new AuthException("Role must be specified");
        }

        // Determine initial status based on role
        UserStatus initialStatus = (request.getRole() == Role.PATIENT)
                ? UserStatus.ACTIVE
                : UserStatus.PENDING;

        // Create user
        User user = User.builder()
                .email(request.getEmail())
                .username(request.getUsername())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(request.getRole())
                .status(initialStatus)
                .build();

        User savedUser = userRepository.save(user);
        log.info("User registered successfully: {}", savedUser.getUserId());

        // Generate JWT token
        String token = jwtUtil.generateToken(
                savedUser.getUserId(),
                savedUser.getRole(),
                savedUser.getStatus()
        );

        return AuthResponse.builder()
                .userId(savedUser.getUserId())
                .role(savedUser.getRole().name())
                .status(savedUser.getStatus().name())
                .token(token)
                .message("Registration successful. Please complete your profile.")
                .build();
    }

    @Transactional(readOnly = true)
    public AuthResponse login(LoginRequest request) {
        log.info("Login attempt for: {}", request.getEmailOrUsername());


        User user = userRepository.findByEmailOrUsername(
                request.getEmailOrUsername(),
                request.getEmailOrUsername()
        ).orElseThrow(() -> new AuthException("Invalid credentials"));

        // Verify password
        if (passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new AuthException("Invalid credentials ");
        }

        if (user.getStatus() == UserStatus.BLOCKED) {
            throw new AuthException("Account is blocked. Please contact administrator");
        }

        log.info("Login successful for user: {}", user.getUserId());

        // Generate JWT token
        String token = jwtUtil.generateToken(
                user.getUserId(),
                user.getRole(),
                user.getStatus()
        );

        // Check if profile exists and include in response
        ProfileData profileData = null;
        UserProfile profile = userProfileRepository.findByUserId(user.getUserId()).orElse(null);
        if (profile != null) {
            profileData = ProfileData.builder()
                    .name(profile.getName())
                    .gender(profile.getGender().name())
                    .dob(profile.getDob())
                    .phone(profile.getPhone())
                    .address(profile.getAddress())
                    .profilePicture(profile.getProfilePicture())
                    .profileStatus(profile.getProfileStatus().name())
                    .build();
        }

        return AuthResponse.builder()
                .userId(user.getUserId())
                .role(user.getRole().name())
                .status(user.getStatus().name())
                .token(token)
                .profileData(profileData)
                .message("Login successful")
                .build();
    }

    @Transactional
    public void updateUserStatus(String userId, UserStatus status) {
        log.info("Updating status for user: {} to {}", userId, status);

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new AuthException("User not found"));

        user.setStatus(status);
        userRepository.save(user);

        log.info("User status updated successfully");
    }

    @Transactional(readOnly = true)
    public User getUserById(String userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new AuthException("User not found"));
    }

    @Transactional(readOnly = true)
    public boolean isUserActive(String userId) {
        return userRepository.findById(userId)
                .map(user -> user.getStatus() == UserStatus.ACTIVE)
                .orElse(false);
    }

    public boolean validateToken(String token) {
        return jwtUtil.validateToken(token);
    }

    public String extractUserIdFromToken(String token) {
        return jwtUtil.extractUserId(token);
    }

    public String extractRoleFromToken(String token) {
        return jwtUtil.extractRole(token);
    }
}
