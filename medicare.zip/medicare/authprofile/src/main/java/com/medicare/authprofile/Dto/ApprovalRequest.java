package com.medicare.authprofile.Dto;

import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApprovalRequest {
    private String action;  // "APPROVE" or "REJECT"
    private String reason;
}
