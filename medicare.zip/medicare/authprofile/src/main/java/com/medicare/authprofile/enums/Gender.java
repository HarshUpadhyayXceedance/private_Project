package com.medicare.authprofile.enums;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
