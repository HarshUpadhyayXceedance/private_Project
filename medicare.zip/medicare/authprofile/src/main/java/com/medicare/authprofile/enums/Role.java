package com.medicare.authprofile.enums;

public enum Role {
    EMPLOYEE,
    PATIENT,
}


