package com.medicare.authprofile.enums;

public enum Role {
    DOCTOR,
    PATIENT,
    ADMIN
}


