package com.medicare.authprofile.Dto;

import lombok.*;
import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProfileData {
    private String name;
    private String gender;
    private LocalDate dob;
    private String phone;
    private String address;
    private String profilePicture;
    private String profileStatus;
}