package com.medicare.authprofile.Dto;

import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuthResponse {
    private String userId;
    private String role;
    private String status;
    private String token;
    private String message;
    private ProfileData profileData;
}
