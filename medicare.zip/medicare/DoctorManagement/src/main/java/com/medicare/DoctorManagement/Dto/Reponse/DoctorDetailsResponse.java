package com.medicare.DoctorManagement.Dto.Reponse;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DoctorDetailsResponse {
    // Doctor info
    private Long doctorId;
    private String userId;
    private Long employeeId;
    private String specialization;
    private String qualification;
    private Integer experience;
    private String medicalRegistrationNumber;
    private Boolean licenseVerified;
    private String verificationStatus;
    private String orgCode;
    private String orgName;
    private Double consultationFee;
    private Double onlineConsultationFee;
    private Double emergencyConsultationFee;
    private Double followupConsultationFee;
    private String about;
    private String languagesSpoken;
    private String awards;
    private Integer slotDuration;
    private Integer bufferTime;

    // From Auth-Profile Service
    private String name;
    private String email;
    private String phone;
    private String profilePicture;

    // From Employee Commons Service
    private String employeeCode;
    private String departmentName;
    private String joiningDate;
    private List<EducationResponse> education;
    private List<ExperienceResponse> experienceResponses;

    // From local (availability & reviews)
    private List<AvailabilityResponse> availability;
    private Double averageRating;
    private Integer totalReviews;
    private List<ReviewResponse> recentReviews;
}