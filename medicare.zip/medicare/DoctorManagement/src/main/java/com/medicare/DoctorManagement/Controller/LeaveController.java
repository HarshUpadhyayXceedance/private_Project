package com.medicare.DoctorManagement.Controller;

import com.medicare.DoctorManagement.Dto.Request.ApplyLeaveRequest;
import com.medicare.DoctorManagement.Dto.Reponse.LeaveResponse;
import com.medicare.DoctorManagement.Service.LeaveService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/doctors/{doctorId}/leaves")
@RequiredArgsConstructor
@Slf4j
public class LeaveController {

    private final LeaveService leaveService;

    //==================== BASIC CRUD OPERATION ON LEAVE ==========#

    // Apply For Leave
    @PostMapping
    public ResponseEntity<LeaveResponse> applyLeave(
            @PathVariable Long doctorId, @Valid @RequestBody ApplyLeaveRequest request,
            @RequestHeader("Authorization") String authHeader) {

        log.info("POST /doctors/{}/leaves - Apply for leave", doctorId);
        LeaveResponse response = leaveService.applyLeave(doctorId, request, authHeader);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    // Get doctor leaves
    @GetMapping
    public ResponseEntity<List<LeaveResponse>> getDoctorLeaves(
            @PathVariable Long doctorId,
            @RequestHeader("Authorization") String authHeader) {

        log.info("GET /doctors/{}/leaves - Get doctor leaves", doctorId);
        List<LeaveResponse> response = leaveService.getDoctorLeaves(doctorId, authHeader);
        return ResponseEntity.ok(response);
    }

    // Get all pending leaves (Admin only)
    @GetMapping("/pending")
    public ResponseEntity<List<LeaveResponse>> getPendingLeaves(
            @RequestHeader("Authorization") String authHeader) {

        log.info("GET /doctors/leaves/pending - Get all pending leaves");
        List<LeaveResponse> response = leaveService.getPendingLeaves(authHeader);
        return ResponseEntity.ok(response);
    }

    // Approve leave (Admin only)
    @PutMapping("/{leaveId}/approve")
    public ResponseEntity<LeaveResponse> approveLeave(
            @PathVariable Long doctorId,
            @PathVariable Long leaveId,
            @RequestHeader("Authorization") String authHeader,
            @RequestHeader(value = "X-User-Id", required = false) String approvedBy) {

        log.info("PUT /doctors/{}/leaves/{}/approve - Approve leave", doctorId, leaveId);

        if (approvedBy == null) {
            approvedBy = "ADMIN";
        }

        LeaveResponse response = leaveService.approveLeave(doctorId, leaveId, approvedBy, authHeader);
        return ResponseEntity.ok(response);
    }

    // Cancel leave
    @DeleteMapping("/{leaveId}")
    public ResponseEntity<Void> cancelLeave(
            @PathVariable Long doctorId,
            @PathVariable Long leaveId) {

        log.info("DELETE /doctors/{}/leaves/{} - Cancel leave", doctorId, leaveId);
        leaveService.cancelLeave(doctorId, leaveId);
        return ResponseEntity.noContent().build();
    }
}
