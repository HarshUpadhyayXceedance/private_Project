package com.medicare.DoctorManagement.Dto.Request;

import com.medicare.DoctorManagement.Enum.ConsultationType;
import com.medicare.DoctorManagement.Enum.DayOfWeek;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


import java.time.LocalDate;
import java.time.LocalTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateAvailabilityRequest {

    @NotNull(message = "Day of week is required")
    private DayOfWeek dayOfWeek;

    @NotNull(message = "Start time is required")
    private LocalTime startTime;

    @NotNull(message = "End time is required")
    private LocalTime endTime;

    private ConsultationType consultationType;

    private LocalDate effectiveFrom;

    private LocalDate effectiveUntil;
}
