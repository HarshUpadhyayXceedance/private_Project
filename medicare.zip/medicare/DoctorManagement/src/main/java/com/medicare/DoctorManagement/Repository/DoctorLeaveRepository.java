package com.medicare.DoctorManagement.Repository;

import com.medicare.DoctorManagement.Entity.DoctorLeave;
import com.medicare.DoctorManagement.Enum.LeaveStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface DoctorLeaveRepository extends JpaRepository<DoctorLeave, Long> {

    List<DoctorLeave> findByDoctorId(Long doctorId);

    List<DoctorLeave> findByDoctorIdAndStatus(Long doctorId, LeaveStatus status);

    List<DoctorLeave> findByStatus(LeaveStatus status);

    boolean existsByDoctorIdAndLeaveDate(Long doctorId, LocalDate leaveDate);

    @Query("SELECT l FROM DoctorLeave l WHERE l.doctorId = :doctorId " +
            "AND l.leaveDate = :leaveDate AND l.status = 'APPROVED'")
    List<DoctorLeave> findApprovedLeaveOnDate(
            @Param("doctorId") Long doctorId,
            @Param("leaveDate") LocalDate leaveDate
    );

    void deleteByDoctorId(Long doctorId);
}