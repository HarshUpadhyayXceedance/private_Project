package com.medicare.DoctorManagement.Service;

import com.medicare.DoctorManagement.Client.AuthProfileClient;
import com.medicare.DoctorManagement.Client.EmployeeCommonsClient;
import com.medicare.DoctorManagement.Dto.Reponse.*;
import com.medicare.DoctorManagement.Dto.Request.CreateDoctorRequest;
import com.medicare.DoctorManagement.Dto.Request.UpdateDoctorRequest;
import com.medicare.DoctorManagement.Entity.Doctor;
import com.medicare.DoctorManagement.Entity.DoctorAvailability;
import com.medicare.DoctorManagement.Entity.DoctorReview;
import com.medicare.DoctorManagement.Enum.VerificationStatus;
import com.medicare.DoctorManagement.Exception.DoctorException;
import com.medicare.DoctorManagement.Repository.DoctorAvailabilityRepository;
import com.medicare.DoctorManagement.Repository.DoctorRepository;
import com.medicare.DoctorManagement.Repository.DoctorReviewRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class DoctorService {

    private final DoctorRepository doctorRepository;
    private final DoctorAvailabilityRepository availabilityRepository;
    private final DoctorReviewRepository reviewRepository;
    private final AuthProfileClient authProfileClient;
    private final EmployeeCommonsClient employeeCommonsClient;

    private static final DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;

    @Transactional
    public DoctorResponse createDoctor(CreateDoctorRequest request, String authHeader) {
        log.info("Creating doctor profile for userId: {}", request.getUserId());

        // Check if doctor already exists
        if (doctorRepository.existsByUserId(request.getUserId())) {
            throw new DoctorException("Doctor profile already exists for this user");
        }

        if (doctorRepository.existsByEmployeeId(request.getEmployeeId())) {
            throw new DoctorException("Doctor profile already exists for this employee");
        }

        if (doctorRepository.existsByMedicalRegistrationNumber(request.getMedicalRegistrationNumber())) {
            throw new DoctorException("Medical registration number already exists");
        }

        // Validate user exists in Auth-Profile Service and is EMPLOYEE role
        validateUserIsEmployee(request.getUserId(), authHeader);

        // Create doctor
        Doctor doctor = Doctor.builder()
                .userId(request.getUserId())
                .employeeId(request.getEmployeeId())
                .specialization(request.getSpecialization())
                .qualification(request.getQualification())
                .experience(request.getExperience())
                .medicalRegistrationNumber(request.getMedicalRegistrationNumber())
                .licenseVerified(false)
                .verificationStatus(VerificationStatus.PENDING)
                .orgCode(request.getOrgCode())
                .orgName(request.getOrgName())
                .orgVerified(false)
                .consultationFee(request.getConsultationFee())
                .onlineConsultationFee(request.getOnlineConsultationFee())
                .emergencyConsultationFee(request.getEmergencyConsultationFee())
                .followupConsultationFee(request.getFollowupConsultationFee())
                .about(request.getAbout())
                .languagesSpoken(request.getLanguagesSpoken())
                .awards(request.getAwards())
                .slotDuration(request.getSlotDuration() != null ? request.getSlotDuration() : 30)
                .bufferTime(request.getBufferTime() != null ? request.getBufferTime() : 0)
                .averageRating(0.0)
                .totalReviews(0)
                .build();

        Doctor savedDoctor = doctorRepository.save(doctor);
        log.info("Doctor profile created successfully with ID: {}", savedDoctor.getId());

        return mapToDoctorResponse(savedDoctor, "Doctor profile created successfully. Awaiting verification.");
    }

    @Transactional(readOnly = true)
    public DoctorResponse getDoctorById(Long doctorId) {
        log.info("Fetching doctor by ID: {}", doctorId);

        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new DoctorException("Doctor not found with ID: " + doctorId));

        return mapToDoctorResponse(doctor, null);
    }

    @Transactional(readOnly = true)
    public DoctorResponse getDoctorByUserId(String userId) {
        log.info("Fetching doctor by userId: {}", userId);

        Doctor doctor = doctorRepository.findByUserId(userId)
                .orElseThrow(() -> new DoctorException("Doctor not found for user: " + userId));

        return mapToDoctorResponse(doctor, null);
    }

    @Transactional(readOnly = true)
    public DoctorDetailsResponse getDoctorDetails(Long doctorId, String authHeader) {
        log.info("Fetching complete doctor details for ID: {}", doctorId);

        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new DoctorException("Doctor not found with ID: " + doctorId));

        // Fetch user profile from Auth-Profile Service
        UserProfileResponse profile = null;
        try {
            ResponseEntity<UserProfileResponse> profileResponse = authProfileClient.getUserProfile(
                    doctor.getUserId(),
                    authHeader
            );
            profile = profileResponse.getBody();
        } catch (Exception e) {
            log.warn("Failed to fetch user profile: {}", e.getMessage());
        }

        // Fetch employee data from Employee Commons
        EmployeeResponse employee = null;
        try {
            ResponseEntity<EmployeeResponse> employeeResponse = employeeCommonsClient.getEmployeeByUserId(
                    doctor.getUserId(),
                    authHeader
            );
            employee = employeeResponse.getBody();
        } catch (Exception e) {
            log.warn("Failed to fetch employee data: {}", e.getMessage());
        }

        // Fetch education from Employee Commons
        List<EducationResponse> education = null;
        try {
            ResponseEntity<List<EducationResponse>> educationResponse = employeeCommonsClient.getEducation(
                    doctor.getUserId(),
                    authHeader
            );
            education = educationResponse.getBody();
        } catch (Exception e) {
            log.warn("Failed to fetch education data: {}", e.getMessage());
        }

        // Fetch experience from Employee Commons
        List<ExperienceResponse> experience = null;
        try {
            ResponseEntity<List<ExperienceResponse>> experienceResponse = employeeCommonsClient.getExperience(
                    doctor.getUserId(),
                    authHeader
            );
            experience = experienceResponse.getBody();
        } catch (Exception e) {
            log.warn("Failed to fetch experience data: {}", e.getMessage());
        }

        // Fetch availability from local DB
        List<DoctorAvailability> availabilityList = availabilityRepository.findByDoctorId(doctorId);
        List<AvailabilityResponse> availability = availabilityList.stream()
                .map(this::mapToAvailabilityResponse)
                .collect(Collectors.toList());

        // Fetch recent reviews from local DB
        List<DoctorReview> reviewList = reviewRepository.findByDoctorIdOrderByCreatedAtDesc(doctorId)
                .stream()
                .limit(5)
                .toList();
        List<ReviewResponse> reviews = reviewList.stream()
                .map(review -> mapToReviewResponse(review, authHeader))
                .collect(Collectors.toList());

        return DoctorDetailsResponse.builder()
                // Doctor info
                .doctorId(doctor.getId())
                .userId(doctor.getUserId())
                .employeeId(doctor.getEmployeeId())
                .specialization(doctor.getSpecialization())
                .qualification(doctor.getQualification())
                .experience(doctor.getExperience())
                .medicalRegistrationNumber(doctor.getMedicalRegistrationNumber())
                .licenseVerified(doctor.getLicenseVerified())
                .verificationStatus(doctor.getVerificationStatus().name())
                .orgCode(doctor.getOrgCode())
                .orgName(doctor.getOrgName())
                .consultationFee(doctor.getConsultationFee())
                .onlineConsultationFee(doctor.getOnlineConsultationFee())
                .emergencyConsultationFee(doctor.getEmergencyConsultationFee())
                .followupConsultationFee(doctor.getFollowupConsultationFee())
                .about(doctor.getAbout())
                .languagesSpoken(doctor.getLanguagesSpoken())
                .awards(doctor.getAwards())
                .slotDuration(doctor.getSlotDuration())
                .bufferTime(doctor.getBufferTime())
                // From Auth-Profile
                .name(profile != null ? profile.getName() : null)
                .email(profile != null ? profile.getEmail() : null)
                .phone(profile != null ? profile.getPhone() : null)
                .profilePicture(profile != null ? profile.getProfilePicture() : null)
                // From Employee Commons
                .employeeCode(employee != null ? employee.getEmployeeCode() : null)
                .departmentName(employee != null ? employee.getDepartmentName() : null)
                .joiningDate(employee != null ? employee.getJoiningDate() : null)
                .education(education)
                .experienceResponses(experience)
                // Local data
                .availability(availability)
                .averageRating(doctor.getAverageRating())
                .totalReviews(doctor.getTotalReviews())
                .recentReviews(reviews)
                .build();
    }

    @Transactional(readOnly = true)
    public Page<DoctorResponse> getAllDoctors(Pageable pageable) {
        log.info("Fetching all doctors with pagination");
        return doctorRepository.findAll(pageable)
                .map(doctor -> mapToDoctorResponse(doctor, null));
    }

    @Transactional(readOnly = true)
    public List<DoctorResponse> getDoctorsBySpecialization(String specialization) {
        log.info("Fetching doctors by specialization: {}", specialization);
        return doctorRepository.findBySpecializationIgnoreCase(specialization).stream()
                .map(doctor -> mapToDoctorResponse(doctor, null))
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public Page<DoctorResponse> searchDoctors(String query, Pageable pageable) {
        log.info("Searching doctors with query: {}", query);
        return doctorRepository.searchDoctors(query, pageable)
                .map(doctor -> mapToDoctorResponse(doctor, null));
    }

    @Transactional(readOnly = true)
    public List<DoctorResponse> getTopRatedDoctors(Integer limit) {
        log.info("Fetching top {} rated doctors", limit);
        Pageable pageable = Pageable.ofSize(limit);
        return doctorRepository.findTopRatedDoctors(4.0, pageable).stream()
                .map(doctor -> mapToDoctorResponse(doctor, null))
                .collect(Collectors.toList());
    }

    @Transactional
    public DoctorResponse updateDoctor(Long doctorId, UpdateDoctorRequest request) {
        log.info("Updating doctor with ID: {}", doctorId);

        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new DoctorException("Doctor not found with ID: " + doctorId));

        // Update fields if provided
        if (request.getSpecialization() != null) {
            doctor.setSpecialization(request.getSpecialization());
        }
        if (request.getQualification() != null) {
            doctor.setQualification(request.getQualification());
        }
        if (request.getExperience() != null) {
            doctor.setExperience(request.getExperience());
        }
        if (request.getConsultationFee() != null) {
            doctor.setConsultationFee(request.getConsultationFee());
        }
        if (request.getOnlineConsultationFee() != null) {
            doctor.setOnlineConsultationFee(request.getOnlineConsultationFee());
        }
        if (request.getEmergencyConsultationFee() != null) {
            doctor.setEmergencyConsultationFee(request.getEmergencyConsultationFee());
        }
        if (request.getFollowupConsultationFee() != null) {
            doctor.setFollowupConsultationFee(request.getFollowupConsultationFee());
        }
        if (request.getAbout() != null) {
            doctor.setAbout(request.getAbout());
        }
        if (request.getLanguagesSpoken() != null) {
            doctor.setLanguagesSpoken(request.getLanguagesSpoken());
        }
        if (request.getAwards() != null) {
            doctor.setAwards(request.getAwards());
        }
        if (request.getSlotDuration() != null) {
            doctor.setSlotDuration(request.getSlotDuration());
        }
        if (request.getBufferTime() != null) {
            doctor.setBufferTime(request.getBufferTime());
        }

        Doctor updatedDoctor = doctorRepository.save(doctor);
        log.info("Doctor updated successfully: {}", doctorId);

        return mapToDoctorResponse(updatedDoctor, "Doctor profile updated successfully");
    }

    @Transactional
    public DoctorResponse verifyDoctor(Long doctorId) {
        log.info("Verifying doctor with ID: {}", doctorId);

        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new DoctorException("Doctor not found with ID: " + doctorId));

        doctor.setLicenseVerified(true);
        doctor.setVerificationStatus(VerificationStatus.VERIFIED);
        doctor.setOrgVerified(true);

        Doctor verifiedDoctor = doctorRepository.save(doctor);
        log.info("Doctor verified successfully: {}", doctorId);

        return mapToDoctorResponse(verifiedDoctor, "Doctor verified successfully");
    }

    @Transactional
    public void deleteDoctor(Long doctorId) {
        log.info("Deleting doctor with ID: {}", doctorId);

        if (!doctorRepository.existsById(doctorId)) {
            throw new DoctorException("Doctor not found with ID: " + doctorId);
        }

        doctorRepository.deleteById(doctorId);
        log.info("Doctor deleted successfully: {}", doctorId);
    }

    // Helper methods
    private void validateUserIsEmployee(String userId, String authHeader) {
        try {
            ResponseEntity<Map<String, Object>> response = authProfileClient.getUserDetails(userId, authHeader);

            if (response.getBody() == null) {
                throw new DoctorException("User not found in Auth-Profile service");
            }

            String role = (String) response.getBody().get("role");
            if (!"EMPLOYEE".equals(role)) {
                throw new DoctorException("User must have EMPLOYEE role to register as doctor");
            }

            log.info("User validated as EMPLOYEE: {}", userId);

        } catch (Exception e) {
            log.error("Failed to validate user: {}", e.getMessage());
            throw new DoctorException("Failed to validate user: " + e.getMessage());
        }
    }

    private DoctorResponse mapToDoctorResponse(Doctor doctor, String message) {
        return DoctorResponse.builder()
                .id(doctor.getId())
                .userId(doctor.getUserId())
                .employeeId(doctor.getEmployeeId())
                .specialization(doctor.getSpecialization())
                .qualification(doctor.getQualification())
                .experience(doctor.getExperience())
                .medicalRegistrationNumber(doctor.getMedicalRegistrationNumber())
                .licenseVerified(doctor.getLicenseVerified())
                .verificationStatus(doctor.getVerificationStatus().name())
                .orgCode(doctor.getOrgCode())
                .orgName(doctor.getOrgName())
                .orgVerified(doctor.getOrgVerified())
                .consultationFee(doctor.getConsultationFee())
                .onlineConsultationFee(doctor.getOnlineConsultationFee())
                .emergencyConsultationFee(doctor.getEmergencyConsultationFee())
                .followupConsultationFee(doctor.getFollowupConsultationFee())
                .about(doctor.getAbout())
                .languagesSpoken(doctor.getLanguagesSpoken())
                .awards(doctor.getAwards())
                .slotDuration(doctor.getSlotDuration())
                .bufferTime(doctor.getBufferTime())
                .averageRating(doctor.getAverageRating())
                .totalReviews(doctor.getTotalReviews())
                .createdAt(doctor.getCreatedAt() != null ? doctor.getCreatedAt().format(formatter) : null)
                .updatedAt(doctor.getUpdatedAt() != null ? doctor.getUpdatedAt().format(formatter) : null)
                .message(message)
                .build();
    }

    private AvailabilityResponse mapToAvailabilityResponse(DoctorAvailability availability) {
        return AvailabilityResponse.builder()
                .id(availability.getId())
                .doctorId(availability.getDoctorId())
                .dayOfWeek(availability.getDayOfWeek().name())
                .startTime(availability.getStartTime().toString())
                .endTime(availability.getEndTime().toString())
                .isAvailable(availability.getIsAvailable())
                .consultationType(availability.getConsultationType().name())
                .effectiveFrom(availability.getEffectiveFrom() != null ? availability.getEffectiveFrom().toString() : null)
                .effectiveUntil(availability.getEffectiveUntil() != null ? availability.getEffectiveUntil().toString() : null)
                .build();
    }

    private ReviewResponse mapToReviewResponse(DoctorReview review, String authHeader) {
        String patientName = null;
        try {
            ResponseEntity<UserProfileResponse> response = authProfileClient.getUserProfile(
                    review.getPatientUserId(),
                    authHeader
            );
            if (response.getBody() != null) {
                patientName = response.getBody().getName();
            }
        } catch (Exception e) {
            log.warn("Failed to fetch patient name for review");
        }

        return ReviewResponse.builder()
                .id(review.getId())
                .doctorId(review.getDoctorId())
                .patientUserId(review.getPatientUserId())
                .patientName(patientName)
                .rating(review.getRating())
                .reviewText(review.getReviewText())
                .appointmentId(review.getAppointmentId())
                .createdAt(review.getCreatedAt() != null ? review.getCreatedAt().format(formatter) : null)
                .build();
    }
}