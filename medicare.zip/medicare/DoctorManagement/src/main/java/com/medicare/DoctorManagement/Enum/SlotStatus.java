package com.medicare.DoctorManagement.Enum;

public enum SlotStatus {
    AVAILABLE,
    BOOKED,
    BLOCKED,
    COMPLETED,
    CANCELLED
}
