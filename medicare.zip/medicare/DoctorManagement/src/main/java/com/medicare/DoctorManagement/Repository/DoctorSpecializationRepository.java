package com.medicare.DoctorManagement.Repository;

import com.medicare.DoctorManagement.Entity.DoctorSpecialisation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DoctorSpecializationRepository extends JpaRepository<DoctorSpecialisation, Long> {

    List<DoctorSpecialisation> findByDoctorId(Long doctorId);

    Optional<DoctorSpecialisation> findByDoctorIdAndSpecializationName(Long doctorId, String specializationName);

    boolean existsByDoctorIdAndSpecializationName(Long doctorId, String specializationName);

    void deleteByDoctorId(Long doctorId);
}