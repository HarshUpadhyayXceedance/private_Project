package com.medicare.DoctorManagement.Entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;


@Entity
@Table(name = "doctor_reviews", indexes = {
        @Index(name = "idx_doctor_rating", columnList = "doctor_id, rating")
})
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DoctorReview {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "doctor_id", nullable = false)
    private Long doctorId;

    @Column(name = "patient_user_id", nullable = false)
    private String patientUserId;

    @Column(nullable = false)
    private Double rating;

    @Column(name = "review_text", columnDefinition = "TEXT")
    private String reviewText;

    @Column(name = "appointment_id")
    private Long appointmentId;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }
}

