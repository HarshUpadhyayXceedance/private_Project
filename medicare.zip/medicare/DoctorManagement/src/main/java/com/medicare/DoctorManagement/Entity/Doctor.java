package com.medicare.DoctorManagement.Entity;

import com.medicare.DoctorManagement.Enum.VerificationStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "doctors", indexes = {
        @Index(name = "idx_user_id", columnList = "user_id"),
        @Index(name = "idx_employee_id", columnList = "employee_id"),
        @Index(name = "idx_specialization", columnList = "specialization"),
        @Index(name = "idx_org_code", columnList = "org_code"),
        @Index(name = "idx_medical_reg", columnList = "medical_registration_number")
})
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Doctor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", unique = true, nullable = false)
    private String userId;

    @Column(name = "employee_id", unique = true, nullable = false)
    private Long employeeId; // Links to Employee Commons Service

    @Column(nullable = false)
    private String specialization;

    @Column(length = 500, nullable = false)
    private String qualification;

    @Column(nullable = false)
    private Integer experience; // years

    @Column(name = "medical_registration_number", unique = true, nullable = false, length = 100)
    private String medicalRegistrationNumber;

    @Column(name = "license_verified")
    @Builder.Default
    private Boolean licenseVerified = false;

    @Enumerated(EnumType.STRING)
    @Column(name = "verification_status")
    @Builder.Default
    private VerificationStatus verificationStatus = VerificationStatus.PENDING;

    @Column(name = "org_code", nullable = false, length = 100)
    private String orgCode;

    @Column(name = "org_name", nullable = false)
    private String orgName;

    @Column(name = "org_verified")
    @Builder.Default
    private Boolean orgVerified = false;

    @Column(name = "consultation_fee", nullable = false)
    private Double consultationFee;

    @Column(name = "online_consultation_fee")
    private Double onlineConsultationFee;

    @Column(name = "emergency_consultation_fee")
    private Double emergencyConsultationFee;

    @Column(name = "followup_consultation_fee")
    private Double followupConsultationFee;

    @Column(columnDefinition = "TEXT")
    private String about;

    @Column(name = "languages_spoken")
    private String languagesSpoken;

    @Column(columnDefinition = "TEXT")
    private String awards;

    @Column(name = "slot_duration")
    @Builder.Default
    private Integer slotDuration = 30; // minutes

    @Column(name = "buffer_time")
    @Builder.Default
    private Integer bufferTime = 0; // minutes between appointments

    @Column(name = "average_rating")
    @Builder.Default
    private Double averageRating = 0.0;

    @Column(name = "total_reviews")
    @Builder.Default
    private Integer totalReviews = 0;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}