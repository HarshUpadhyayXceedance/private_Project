package com.medicare.DoctorManagement.Dto.Reponse;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExperienceResponse {
    private Long id;
    private Long employeeId;
    private String organization;
    private String position;
    private String startDate;
    private String endDate;
    private Boolean isCurrent;
    private String description;
    private String location;
    private String message;
}