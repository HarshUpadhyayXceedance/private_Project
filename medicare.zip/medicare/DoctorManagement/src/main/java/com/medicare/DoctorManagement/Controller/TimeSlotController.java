package com.medicare.DoctorManagement.Controller;


import com.medicare.DoctorManagement.Dto.Reponse.GenerateSlotsResponse;
import com.medicare.DoctorManagement.Dto.Reponse.SlotAvailabilityResponse;
import com.medicare.DoctorManagement.Dto.Reponse.TimeSlotResponse;
import com.medicare.DoctorManagement.Dto.Request.BlockSlotRequest;
import com.medicare.DoctorManagement.Dto.Request.BookSlotRequest;
import com.medicare.DoctorManagement.Dto.Request.GenerateSlotsRequest;
import com.medicare.DoctorManagement.Service.TimeSlotService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/doctors/{doctorId}/slots")
@RequiredArgsConstructor
@Slf4j
public class TimeSlotController {

    private final TimeSlotService slotService;

    // Generate slots for date range
    @PostMapping("/generate")
    public ResponseEntity<GenerateSlotsResponse> generateSlots(
            @PathVariable Long doctorId,
            @Valid @RequestBody GenerateSlotsRequest request) {

        log.info("POST /doctors/{}/slots/generate - Generate slots", doctorId);
        GenerateSlotsResponse response = slotService.generateSlots(doctorId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    // Get available slots for a date
    @GetMapping("/available")
    public ResponseEntity<SlotAvailabilityResponse> getAvailableSlots(
            @PathVariable Long doctorId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {

        log.info("GET /doctors/{}/slots/available?date={} - Get available slots", doctorId, date);
        SlotAvailabilityResponse response = slotService.getAvailableSlots(doctorId, date);
        return ResponseEntity.ok(response);
    }

    // Get slot by ID
    @GetMapping("/{slotId}")
    public ResponseEntity<TimeSlotResponse> getSlotById(
            @PathVariable Long doctorId,
            @PathVariable Long slotId) {

        log.info("GET /doctors/{}/slots/{} - Get slot by ID", doctorId, slotId);
        TimeSlotResponse response = slotService.getSlotById(doctorId, slotId);
        return ResponseEntity.ok(response);
    }

    // Block slot
    @PutMapping("/{slotId}/block")
    public ResponseEntity<TimeSlotResponse> blockSlot(
            @PathVariable Long doctorId,
            @PathVariable Long slotId,
            @RequestBody BlockSlotRequest request) {

        log.info("PUT /doctors/{}/slots/{}/block - Block slot", doctorId, slotId);
        TimeSlotResponse response = slotService.blockSlot(doctorId, slotId, request);
        return ResponseEntity.ok(response);
    }

    // Unblock slot
    @PutMapping("/{slotId}/unblock")
    public ResponseEntity<TimeSlotResponse> unblockSlot(
            @PathVariable Long doctorId,
            @PathVariable Long slotId) {

        log.info("PUT /doctors/{}/slots/{}/unblock - Unblock slot", doctorId, slotId);
        TimeSlotResponse response = slotService.unblockSlot(doctorId, slotId);
        return ResponseEntity.ok(response);
    }

    // Book slot (Internal - called by Appointment Service)
    @PutMapping("/{slotId}/book")
    public ResponseEntity<TimeSlotResponse> bookSlot(
            @PathVariable Long doctorId,
            @PathVariable Long slotId,
            @Valid @RequestBody BookSlotRequest request) {

        log.info("PUT /doctors/{}/slots/{}/book - Book slot for appointment: {}",
                doctorId, slotId, request.getAppointmentId());
        TimeSlotResponse response = slotService.bookSlot(doctorId, slotId, request);
        return ResponseEntity.ok(response);
    }
}
