package com.medicare.DoctorManagement.Enum;

public enum VerificationStatus {
    PENDING,
    VERIFIED,
    REJECTED,
    EXPIRED
}
