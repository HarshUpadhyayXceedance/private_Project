package com.medicare.DoctorManagement.Dto.Reponse;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TimeSlotResponse {
    private Long id;
    private Long doctorId;
    private String slotDate;
    private String slotTime;
    private String slotEndTime;
    private String slotStatus;
    private Long appointmentId;
    private String consultationType;
    private String notes;
    private Boolean isBookable;
    private String message;
}