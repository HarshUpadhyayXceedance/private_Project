package com.medicare.DoctorManagement.Service;

import com.medicare.DoctorManagement.Client.AuthProfileClient;
import com.medicare.DoctorManagement.Dto.Request.AddReviewRequest;
import com.medicare.DoctorManagement.Dto.Reponse.RatingResponse;
import com.medicare.DoctorManagement.Dto.Reponse.ReviewResponse;
import com.medicare.DoctorManagement.Dto.Reponse.UserProfileResponse;
import com.medicare.DoctorManagement.Entity.Doctor;
import com.medicare.DoctorManagement.Entity.DoctorReview;
import com.medicare.DoctorManagement.Exception.DoctorException;
import com.medicare.DoctorManagement.Repository.DoctorRepository;
import com.medicare.DoctorManagement.Repository.DoctorReviewRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.format.DateTimeFormatter;

@Service
@RequiredArgsConstructor
@Slf4j
public class ReviewService {

    private final DoctorReviewRepository reviewRepository;
    private final DoctorRepository doctorRepository;
    private final AuthProfileClient authProfileClient;

    private static final DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;

    @Transactional
    public ReviewResponse addReview(Long doctorId, String patientUserId, AddReviewRequest request, String authHeader) {
        log.info("Adding review for doctor ID: {} by patient: {}", doctorId, patientUserId);

        // Verify doctor exists
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new DoctorException("Doctor not found with ID: " + doctorId));

        // Check if patient has already reviewed this doctor
        if (reviewRepository.existsByDoctorIdAndPatientUserId(doctorId, patientUserId)) {
            throw new DoctorException("You have already reviewed this doctor");
        }

        // Create review
        DoctorReview review = DoctorReview.builder()
                .doctorId(doctorId)
                .patientUserId(patientUserId)
                .rating(request.getRating())
                .reviewText(request.getReviewText())
                .appointmentId(request.getAppointmentId())
                .build();

        DoctorReview savedReview = reviewRepository.save(review);

        // Update doctor's average rating
        updateDoctorRating(doctorId);

        log.info("Review added successfully: {}", savedReview.getId());

        return mapToReviewResponse(savedReview, authHeader, "Review added successfully");
    }

    @Transactional(readOnly = true)
    public Page<ReviewResponse> getDoctorReviews(Long doctorId, Pageable pageable, String authHeader) {
        log.info("Fetching reviews for doctor ID: {}", doctorId);

        // Verify doctor exists
        if (!doctorRepository.existsById(doctorId)) {
            throw new DoctorException("Doctor not found with ID: " + doctorId);
        }

        return reviewRepository.findByDoctorIdOrderByCreatedAtDesc(doctorId, pageable)
                .map(review -> mapToReviewResponse(review, authHeader, null));
    }

    @Transactional(readOnly = true)
    public RatingResponse getDoctorRating(Long doctorId) {
        log.info("Fetching rating summary for doctor ID: {}", doctorId);

        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new DoctorException("Doctor not found with ID: " + doctorId));

        Integer fiveStar = reviewRepository.countByRatingRange(doctorId, 4.5, 5.1);
        Integer fourStar = reviewRepository.countByRatingRange(doctorId, 3.5, 4.5);
        Integer threeStar = reviewRepository.countByRatingRange(doctorId, 2.5, 3.5);
        Integer twoStar = reviewRepository.countByRatingRange(doctorId, 1.5, 2.5);
        Integer oneStar = reviewRepository.countByRatingRange(doctorId, 0.0, 1.5);

        return RatingResponse.builder()
                .averageRating(doctor.getAverageRating())
                .totalReviews(doctor.getTotalReviews())
                .fiveStarCount(fiveStar != null ? fiveStar : 0)
                .fourStarCount(fourStar != null ? fourStar : 0)
                .threeStarCount(threeStar != null ? threeStar : 0)
                .twoStarCount(twoStar != null ? twoStar : 0)
                .oneStarCount(oneStar != null ? oneStar : 0)
                .build();
    }

    // Helper methods
    private void updateDoctorRating(Long doctorId) {
        Double averageRating = reviewRepository.calculateAverageRating(doctorId);
        Integer totalReviews = reviewRepository.countReviews(doctorId);

        Doctor doctor = doctorRepository.findById(doctorId).orElse(null);
        if (doctor != null) {
            doctor.setAverageRating(averageRating != null ? Math.round(averageRating * 10.0) / 10.0 : 0.0);
            doctor.setTotalReviews(totalReviews != null ? totalReviews : 0);
            doctorRepository.save(doctor);
        }
    }

    private ReviewResponse mapToReviewResponse(DoctorReview review, String authHeader, String message) {
        String patientName = null;
        try {
            ResponseEntity<UserProfileResponse> response = authProfileClient.getUserProfile(
                    review.getPatientUserId(),
                    authHeader
            );
            if (response.getBody() != null) {
                patientName = response.getBody().getName();
            }
        } catch (Exception e) {
            log.warn("Failed to fetch patient name for review");
        }

        return ReviewResponse.builder()
                .id(review.getId())
                .doctorId(review.getDoctorId())
                .patientUserId(review.getPatientUserId())
                .patientName(patientName)
                .rating(review.getRating())
                .reviewText(review.getReviewText())
                .appointmentId(review.getAppointmentId())
                .createdAt(review.getCreatedAt() != null ? review.getCreatedAt().format(formatter) : null)
                .message(message)
                .build();
    }
}

