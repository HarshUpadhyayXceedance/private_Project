package com.medicare.DoctorManagement.Client;

import com.medicare.DoctorManagement.Dto.Reponse.EducationResponse;
import com.medicare.DoctorManagement.Dto.Reponse.EmployeeResponse;
import com.medicare.DoctorManagement.Dto.Reponse.ExperienceResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.List;

@FeignClient(
        name = "employee-commons-client",
        url = "${feign.gateway.base-url:http://localhost:8080}",
        path = "/api/employee-commons")

public interface EmployeeCommonsClient {

    // Get employee by user ID [GET /api/employee-commons/employees/user/{userId} ]
    @GetMapping("/employees/user/{userId}")
    ResponseEntity<EmployeeResponse> getEmployeeByUserId(
            @PathVariable("userId") String userId,
            @RequestHeader("Authorization") String authHeader
    );

    // Get employee education records [GET /api/employee-commons/employees/{userId}/education]
    @GetMapping("/employees/{userId}/education")
    ResponseEntity<List<EducationResponse>> getEducation(
            @PathVariable("userId") String userId,
            @RequestHeader("Authorization") String authHeader
    );

    // Get employee experience records [GET /api/employee-commons/employees/{userId}/experience]
    @GetMapping("/employees/{userId}/experience")
    ResponseEntity<List<ExperienceResponse>> getExperience(
            @PathVariable("userId") String userId,
            @RequestHeader("Authorization") String authHeader
    );
}