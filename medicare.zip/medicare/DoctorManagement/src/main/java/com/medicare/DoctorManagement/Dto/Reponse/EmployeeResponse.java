package com.medicare.DoctorManagement.Dto.Reponse;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeResponse {
    private Long id;
    private String userId;
    private String employeeCode;
    private String employeeType;
    private String departmentName;
    private String designation;
    private String joiningDate;
    private String employmentStatus;
}
