package com.medicare.DoctorManagement.Repository;

import com.medicare.DoctorManagement.Entity.DoctorAvailability;
import jakarta.validation.constraints.NotNull;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface DoctorAvailabilityRepository extends JpaRepository<DoctorAvailability, Long> {

    List<DoctorAvailability> findByDoctorId(Long doctorId);

    List<DoctorAvailability> findByDoctorIdAndDayOfWeek(Long doctorId, com.medicare.DoctorManagement.Enum.@NotNull(message = "Day of week is required") DayOfWeek dayOfWeek);

    Optional<DoctorAvailability> findByDoctorIdAndDayOfWeekAndIsAvailable(
            Long doctorId,
            DayOfWeek dayOfWeek,
            Boolean isAvailable
    );

    @Query("SELECT a FROM DoctorAvailability a WHERE a.doctorId = :doctorId " +
            "AND a.dayOfWeek = :dayOfWeek " +
            "AND (a.effectiveFrom IS NULL OR a.effectiveFrom <= :date) " +
            "AND (a.effectiveUntil IS NULL OR a.effectiveUntil >= :date)")
    List<DoctorAvailability> findEffectiveAvailability(
            @Param("doctorId") Long doctorId,
            @Param("dayOfWeek") DayOfWeek dayOfWeek,
            @Param("date") LocalDate date
    );

    void deleteByDoctorId(Long doctorId);
}