package com.medicare.DoctorManagement.Dto.Reponse;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LeaveResponse {
    private Long id;
    private Long doctorId;
    private String doctorName;
    private String leaveDate;
    private String leaveType;
    private String reason;
    private String status;
    private String approvedBy;
    private String createdAt;
    private String message;
}
