package com.medicare.DoctorManagement.Entity;


import com.medicare.DoctorManagement.Enum.ConsultationType;
import com.medicare.DoctorManagement.Enum.SlotStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Entity
@Table(name = "doctor_time_slots",
        uniqueConstraints = @UniqueConstraint(columnNames = {"doctor_id", "slot_date", "slot_time"}),
        indexes = {
                @Index(name = "idx_doctor_date", columnList = "doctor_id, slot_date"),
                @Index(name = "idx_slot_status", columnList = "slot_status")
        })
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DoctorTimeSlot {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "doctor_id", nullable = false)
    private Long doctorId;

    @Column(name = "slot_date", nullable = false)
    private LocalDate slotDate;

    @Column(name = "slot_time", nullable = false)
    private LocalTime slotTime;

    @Column(name = "slot_end_time", nullable = false)
    private LocalTime slotEndTime;

    @Enumerated(EnumType.STRING)
    @Column(name = "slot_status", length = 20)
    @Builder.Default
    private SlotStatus slotStatus = SlotStatus.AVAILABLE;

    @Column(name = "appointment_id")
    private Long appointmentId;

    @Enumerated(EnumType.STRING)
    @Column(name = "consultation_type", length = 50)
    @Builder.Default
    private ConsultationType consultationType = ConsultationType.IN_CLINIC;

    @Column(columnDefinition = "TEXT")
    private String notes;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}