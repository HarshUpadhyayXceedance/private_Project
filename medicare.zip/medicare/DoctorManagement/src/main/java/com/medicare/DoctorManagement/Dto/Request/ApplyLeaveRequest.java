package com.medicare.DoctorManagement.Dto.Request;

import com.medicare.DoctorManagement.Enum.LeaveType;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApplyLeaveRequest {

    @NotNull(message = "Leave date is required")
    private LocalDate leaveDate;

    @NotNull(message = "Leave type is required")
    private LeaveType leaveType;

    private String reason;
}