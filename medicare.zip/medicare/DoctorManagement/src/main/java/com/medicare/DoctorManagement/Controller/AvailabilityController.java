package com.medicare.DoctorManagement.Controller;

import com.medicare.DoctorManagement.Dto.Reponse.AvailabilityResponse;
import com.medicare.DoctorManagement.Dto.Request.CreateAvailabilityRequest;
import com.medicare.DoctorManagement.Dto.Request.UpdateAvailabilityRequest;
import com.medicare.DoctorManagement.Service.AvailabilityService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/doctors/availability")
@RequiredArgsConstructor
@Slf4j
public class AvailabilityController {

    private final AvailabilityService availabilityService;

    //================== BASIC CRUD OPERATION ON AVAILABILITY ================#

    // Add Specific Doctor Availability
    @PostMapping("/{doctorId}")
    public ResponseEntity<AvailabilityResponse> createAvailability(
            @PathVariable Long doctorId, @Valid @RequestBody CreateAvailabilityRequest request) {

        log.info("POST /doctors/{}/availability - Add availability", doctorId);
        AvailabilityResponse response = availabilityService.createAvailability(doctorId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    // Get Specific Doctor Availability
    @GetMapping("/{doctorId}")
    public ResponseEntity<List<AvailabilityResponse>> getDoctorAvailability(
            @PathVariable Long doctorId) {

        log.info("GET /doctors/{}/availability - Get doctor availability", doctorId);
        List<AvailabilityResponse> response = availabilityService.getDoctorAvailability(doctorId);
        return ResponseEntity.ok(response);
    }

    // Update Specific Availability
    @PatchMapping("/{availabilityId}")
    public ResponseEntity<AvailabilityResponse> updateAvailability(
            @PathVariable Long doctorId, @PathVariable Long availabilityId,
            @Valid @RequestBody UpdateAvailabilityRequest request) {

        log.info("PATCH /doctors/{}/availability/{} - Update availability", doctorId, availabilityId);
        AvailabilityResponse response = availabilityService.updateAvailability(doctorId, availabilityId, request);
        return ResponseEntity.ok(response);
    }

    // Delete Specific Doctor Availability
    @DeleteMapping("/{availabilityId}")
    public ResponseEntity<Void> deleteAvailability(
            @PathVariable Long doctorId, @PathVariable Long availabilityId) {

        log.info("DELETE /doctors/{}/availability/{} - Delete availability", doctorId, availabilityId);
        availabilityService.deleteAvailability(doctorId, availabilityId);
        return ResponseEntity.noContent().build();
    }

}

