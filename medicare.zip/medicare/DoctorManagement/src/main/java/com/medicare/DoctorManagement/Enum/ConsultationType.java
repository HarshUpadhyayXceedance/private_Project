package com.medicare.DoctorManagement.Enum;


public enum ConsultationType {
    IN_CLINIC,
    ONLINE,
    HOME_VISIT,
    EMERGENCY
}

