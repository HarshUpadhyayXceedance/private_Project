package com.medicare.DoctorManagement.Dto.Request;



import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateDoctorRequest {

    @NotBlank(message = "User ID is required")
    private String userId;

    @NotNull(message = "Employee ID is required")
    private Long employeeId;

    @NotBlank(message = "Specialization is required")
    private String specialization;

    @NotBlank(message = "Qualification is required")
    @Size(max = 500, message = "Qualification must not exceed 500 characters")
    private String qualification;

    @NotNull(message = "Experience is required")
    @Min(value = 0, message = "Experience cannot be negative")
    @Max(value = 60, message = "Experience cannot exceed 60 years")
    private Integer experience;

    @NotBlank(message = "Medical registration number is required")
    @Size(max = 100, message = "Medical registration number must not exceed 100 characters")
    private String medicalRegistrationNumber;

    @NotBlank(message = "Organization code is required")
    @Size(max = 100, message = "Organization code must not exceed 100 characters")
    private String orgCode;

    @NotBlank(message = "Organization name is required")
    private String orgName;

    @NotNull(message = "Consultation fee is required")
    @DecimalMin(value = "100.0", message = "Consultation fee must be at least 100")
    @DecimalMax(value = "10000.0", message = "Consultation fee cannot exceed 10000")
    private Double consultationFee;

    @DecimalMin(value = "100.0", message = "Online consultation fee must be at least 100")
    private Double onlineConsultationFee;

    @DecimalMin(value = "100.0", message = "Emergency consultation fee must be at least 100")
    private Double emergencyConsultationFee;

    @DecimalMin(value = "100.0", message = "Followup consultation fee must be at least 100")
    private Double followupConsultationFee;

    private String about;

    private String languagesSpoken;

    private String awards;

    @Min(value = 15, message = "Slot duration must be at least 15 minutes")
    @Max(value = 60, message = "Slot duration cannot exceed 60 minutes")
    private Integer slotDuration;

    @Min(value = 0, message = "Buffer time cannot be negative")
    @Max(value = 30, message = "Buffer time cannot exceed 30 minutes")
    private Integer bufferTime;
}
