package com.medicare.DoctorManagement.Service;


import com.medicare.DoctorManagement.Client.AuthProfileClient;
import com.medicare.DoctorManagement.Dto.Request.ApplyLeaveRequest;
import com.medicare.DoctorManagement.Dto.Reponse.LeaveResponse;
import com.medicare.DoctorManagement.Dto.Reponse.UserProfileResponse;
import com.medicare.DoctorManagement.Entity.Doctor;
import com.medicare.DoctorManagement.Entity.DoctorLeave;
import com.medicare.DoctorManagement.Entity.DoctorTimeSlot;
import com.medicare.DoctorManagement.Enum.LeaveStatus;
import com.medicare.DoctorManagement.Enum.SlotStatus;
import com.medicare.DoctorManagement.Exception.DoctorException;
import com.medicare.DoctorManagement.Repository.DoctorLeaveRepository;
import com.medicare.DoctorManagement.Repository.DoctorRepository;
import com.medicare.DoctorManagement.Repository.DoctorTimeSlotRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class LeaveService {

    private final DoctorLeaveRepository leaveRepository;
    private final DoctorRepository doctorRepository;
    private final DoctorTimeSlotRepository slotRepository;
    private final AuthProfileClient authProfileClient;

    private static final DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;

    @Transactional
    public LeaveResponse applyLeave(Long doctorId, ApplyLeaveRequest request, String authHeader) {
        log.info("Applying leave for doctor ID: {} on {}", doctorId, request.getLeaveDate());

        // Verify doctor exists
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new DoctorException("Doctor not found with ID: " + doctorId));

        // Check if leave already exists for this date
        if (leaveRepository.existsByDoctorIdAndLeaveDate(doctorId, request.getLeaveDate())) {
            throw new DoctorException("Leave already applied for this date");
        }

        // Check if there are booked appointments on this date
        List<DoctorTimeSlot> bookedSlots = slotRepository.findByDoctorIdAndSlotDateAndSlotStatus(
                doctorId,
                request.getLeaveDate(),
                SlotStatus.BOOKED
        );

        if (!bookedSlots.isEmpty()) {
            throw new DoctorException(
                    String.format("Cannot apply leave. You have %d booked appointments on this date. " +
                            "Please reschedule or cancel them first.", bookedSlots.size())
            );
        }

        // Create leave
        DoctorLeave leave = DoctorLeave.builder()
                .doctorId(doctorId)
                .leaveDate(request.getLeaveDate())
                .leaveType(request.getLeaveType())
                .reason(request.getReason())
                .status(LeaveStatus.PENDING)
                .build();

        DoctorLeave savedLeave = leaveRepository.save(leave);
        log.info("Leave applied successfully: {}", savedLeave.getId());

        return mapToLeaveResponse(savedLeave, doctor.getUserId(), authHeader,
                "Leave applied successfully. Awaiting approval.");
    }

    @Transactional(readOnly = true)
    public List<LeaveResponse> getDoctorLeaves(Long doctorId, String authHeader) {
        log.info("Fetching leaves for doctor ID: {}", doctorId);

        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new DoctorException("Doctor not found with ID: " + doctorId));

        return leaveRepository.findByDoctorId(doctorId).stream()
                .map(leave -> mapToLeaveResponse(leave, doctor.getUserId(), authHeader, null))
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<LeaveResponse> getPendingLeaves(String authHeader) {
        log.info("Fetching all pending leaves");

        return leaveRepository.findByStatus(LeaveStatus.PENDING).stream()
                .map(leave -> {
                    Doctor doctor = doctorRepository.findById(leave.getDoctorId()).orElse(null);
                    String userId = doctor != null ? doctor.getUserId() : null;
                    return mapToLeaveResponse(leave, userId, authHeader, null);
                })
                .collect(Collectors.toList());
    }

    @Transactional
    public LeaveResponse approveLeave(Long doctorId, Long leaveId, String approvedBy, String authHeader) {
        log.info("Approving leave ID: {} for doctor ID: {}", leaveId, doctorId);

        DoctorLeave leave = leaveRepository.findById(leaveId)
                .orElseThrow(() -> new DoctorException("Leave not found with ID: " + leaveId));

        if (!leave.getDoctorId().equals(doctorId)) {
            throw new DoctorException("Leave does not belong to this doctor");
        }

        if (leave.getStatus() != LeaveStatus.PENDING) {
            throw new DoctorException("Leave is not in pending status");
        }

        leave.setStatus(LeaveStatus.APPROVED);
        leave.setApprovedBy(approvedBy);

        // Block all available slots on this date
        List<DoctorTimeSlot> availableSlots = slotRepository.findByDoctorIdAndSlotDateAndSlotStatus(
                doctorId,
                leave.getLeaveDate(),
                SlotStatus.AVAILABLE
        );

        availableSlots.forEach(slot -> {
            slot.setSlotStatus(SlotStatus.BLOCKED);
            slot.setNotes("Doctor on " + leave.getLeaveType().name());
        });

        slotRepository.saveAll(availableSlots);

        DoctorLeave approvedLeave = leaveRepository.save(leave);
        log.info("Leave approved and {} slots blocked", availableSlots.size());

        Doctor doctor = doctorRepository.findById(doctorId).orElse(null);
        String userId = doctor != null ? doctor.getUserId() : null;

        return mapToLeaveResponse(approvedLeave, userId, authHeader, "Leave approved successfully");
    }

    @Transactional
    public void cancelLeave(Long doctorId, Long leaveId) {
        log.info("Cancelling leave ID: {} for doctor ID: {}", leaveId, doctorId);

        DoctorLeave leave = leaveRepository.findById(leaveId)
                .orElseThrow(() -> new DoctorException("Leave not found with ID: " + leaveId));

        if (!leave.getDoctorId().equals(doctorId)) {
            throw new DoctorException("Leave does not belong to this doctor");
        }

        if (leave.getStatus() == LeaveStatus.APPROVED) {
            throw new DoctorException("Cannot cancel approved leave. Please contact admin.");
        }

        leave.setStatus(LeaveStatus.CANCELLED);
        leaveRepository.save(leave);
        log.info("Leave cancelled successfully: {}", leaveId);
    }

    // Helper methods
    private LeaveResponse mapToLeaveResponse(
            DoctorLeave leave,
            String userId,
            String authHeader,
            String message) {

        String doctorName = null;
        if (userId != null) {
            try {
                ResponseEntity<UserProfileResponse> response = authProfileClient.getUserProfile(userId, authHeader);
                if (response.getBody() != null) {
                    doctorName = response.getBody().getName();
                }
            } catch (Exception e) {
                log.warn("Failed to fetch doctor name for leave");
            }
        }

        return LeaveResponse.builder()
                .id(leave.getId())
                .doctorId(leave.getDoctorId())
                .doctorName(doctorName)
                .leaveDate(leave.getLeaveDate().toString())
                .leaveType(leave.getLeaveType().name())
                .reason(leave.getReason())
                .status(leave.getStatus().name())
                .approvedBy(leave.getApprovedBy())
                .createdAt(leave.getCreatedAt() != null ? leave.getCreatedAt().format(formatter) : null)
                .message(message)
                .build();
    }
}


