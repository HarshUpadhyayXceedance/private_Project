package com.medicare.DoctorManagement.Repository;

import com.medicare.DoctorManagement.Entity.Doctor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DoctorRepository extends JpaRepository<Doctor, Long> {

    Optional<Doctor> findByUserId(String userId);

    Optional<Doctor> findByEmployeeId(Long employeeId);

    Optional<Doctor> findByMedicalRegistrationNumber(String medicalRegistrationNumber);

    boolean existsByUserId(String userId);

    boolean existsByEmployeeId(Long employeeId);

    boolean existsByMedicalRegistrationNumber(String medicalRegistrationNumber);

    List<Doctor> findBySpecializationIgnoreCase(String specialization);

    List<Doctor> findByOrgCode(String orgCode);

    Page<Doctor> findBySpecializationContainingIgnoreCase(String specialization, Pageable pageable);

    @Query("SELECT d FROM Doctor d WHERE d.averageRating >= :minRating ORDER BY d.averageRating DESC")
    List<Doctor> findTopRatedDoctors(@Param("minRating") Double minRating, Pageable pageable);

    @Query("SELECT d FROM Doctor d WHERE " +
            "LOWER(d.specialization) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
            "LOWER(d.qualification) LIKE LOWER(CONCAT('%', :query, '%'))")
    Page<Doctor> searchDoctors(@Param("query") String query, Pageable pageable);
}





