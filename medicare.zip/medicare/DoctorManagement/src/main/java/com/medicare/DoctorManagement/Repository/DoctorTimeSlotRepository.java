package com.medicare.DoctorManagement.Repository;

import com.medicare.DoctorManagement.Entity.DoctorTimeSlot;
import com.medicare.DoctorManagement.Enum.SlotStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;


@Repository
public interface DoctorTimeSlotRepository extends JpaRepository<DoctorTimeSlot, Long> {

    List<DoctorTimeSlot> findByDoctorIdAndSlotDate(Long doctorId, LocalDate slotDate);

    List<DoctorTimeSlot> findByDoctorIdAndSlotDateAndSlotStatus(
            Long doctorId, LocalDate slotDate, SlotStatus slotStatus);

    Optional<DoctorTimeSlot> findByDoctorIdAndSlotDateAndSlotTime(
            Long doctorId, LocalDate slotDate, LocalTime slotTime);

    boolean existsByDoctorIdAndSlotDateAndSlotTime(
            Long doctorId, LocalDate slotDate, LocalTime slotTime );

    List<DoctorTimeSlot> findByDoctorIdAndSlotDateBetween(
            Long doctorId, LocalDate startDate, LocalDate endDate );

    @Query("SELECT COUNT(s) FROM DoctorTimeSlot s WHERE s.doctorId = :doctorId " +
            "AND s.slotDate = :slotDate AND s.slotStatus = :status")
    Integer countSlotsByStatus(
            @Param("doctorId") Long doctorId,
            @Param("slotDate") LocalDate slotDate,
            @Param("status") SlotStatus status
    );

    Optional<DoctorTimeSlot> findByAppointmentId(Long appointmentId);

    void deleteByDoctorId(Long doctorId);
}