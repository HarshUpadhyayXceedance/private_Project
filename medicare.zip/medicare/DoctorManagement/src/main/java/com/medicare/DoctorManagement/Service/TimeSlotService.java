package com.medicare.DoctorManagement.Service;

import com.medicare.DoctorManagement.Dto.Reponse.GenerateSlotsResponse;
import com.medicare.DoctorManagement.Dto.Reponse.SlotAvailabilityResponse;
import com.medicare.DoctorManagement.Dto.Reponse.TimeSlotResponse;
import com.medicare.DoctorManagement.Dto.Request.BlockSlotRequest;
import com.medicare.DoctorManagement.Dto.Request.BookSlotRequest;
import com.medicare.DoctorManagement.Dto.Request.GenerateSlotsRequest;
import com.medicare.DoctorManagement.Entity.Doctor;
import com.medicare.DoctorManagement.Entity.DoctorAvailability;
import com.medicare.DoctorManagement.Entity.DoctorLeave;
import com.medicare.DoctorManagement.Entity.DoctorTimeSlot;
import com.medicare.DoctorManagement.Enum.ConsultationType;
import com.medicare.DoctorManagement.Enum.SlotStatus;
import com.medicare.DoctorManagement.Exception.DoctorException;
import com.medicare.DoctorManagement.Repository.DoctorAvailabilityRepository;
import com.medicare.DoctorManagement.Repository.DoctorLeaveRepository;
import com.medicare.DoctorManagement.Repository.DoctorRepository;
import com.medicare.DoctorManagement.Repository.DoctorTimeSlotRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class TimeSlotService {

    private final DoctorTimeSlotRepository slotRepository;
    private final DoctorRepository doctorRepository;
    private final DoctorAvailabilityRepository availabilityRepository;
    private final DoctorLeaveRepository leaveRepository;

    @Transactional
    public GenerateSlotsResponse generateSlots(Long doctorId, GenerateSlotsRequest request) {
        log.info("Generating slots for doctor ID: {} from {} to {}",
                doctorId, request.getStartDate(), request.getEndDate());

        // Verify doctor exists
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new DoctorException("Doctor not found with ID: " + doctorId));

        // Validate dates
        if (request.getEndDate().isBefore(request.getStartDate())) {
            throw new DoctorException("End date cannot be before start date");
        }

        int slotsGenerated = 0;
        LocalDate currentDate = request.getStartDate();

        while (!currentDate.isAfter(request.getEndDate())) {
            // Check if doctor is on leave
            List<DoctorLeave> approvedLeaves = leaveRepository.findApprovedLeaveOnDate(doctorId, currentDate);
            if (!approvedLeaves.isEmpty()) {
                log.info("Skipping {} - doctor on leave", currentDate);
                currentDate = currentDate.plusDays(1);
                continue;
            }

            // Get availability for this day
            DayOfWeek dayOfWeek = currentDate.getDayOfWeek();
            List<DoctorAvailability> availabilityList = availabilityRepository
                    .findEffectiveAvailability(doctorId, dayOfWeek, currentDate);

            if (availabilityList.isEmpty()) {
                log.info("No availability for {} - {}", currentDate, dayOfWeek);
                currentDate = currentDate.plusDays(1);
                continue;
            }

            // Generate slots for each availability period
            for (DoctorAvailability availability : availabilityList) {
                if (!availability.getIsAvailable()) {
                    continue;
                }

                List<DoctorTimeSlot> slots = generateSlotsForPeriod(
                        doctor,
                        currentDate,
                        availability.getStartTime(),
                        availability.getEndTime(),
                        availability.getConsultationType()
                );

                slotsGenerated += slots.size();
                slotRepository.saveAll(slots);
            }

            currentDate = currentDate.plusDays(1);
        }

        log.info("Generated {} slots for doctor ID: {}", slotsGenerated, doctorId);

        return GenerateSlotsResponse.builder()
                .slotsGenerated(slotsGenerated)
                .startDate(request.getStartDate().toString())
                .endDate(request.getEndDate().toString())
                .message(String.format("Successfully generated %d time slots", slotsGenerated))
                .build();
    }

    @Transactional(readOnly = true)
    public SlotAvailabilityResponse getAvailableSlots(Long doctorId, LocalDate date) {
        log.info("Fetching available slots for doctor ID: {} on {}", doctorId, date);

        // Verify doctor exists
        if (!doctorRepository.existsById(doctorId)) {
            throw new DoctorException("Doctor not found with ID: " + doctorId);
        }

        List<DoctorTimeSlot> allSlots = slotRepository.findByDoctorIdAndSlotDate(doctorId, date);

        int totalSlots = allSlots.size();
        int availableSlots = (int) allSlots.stream()
                .filter(slot -> slot.getSlotStatus() == SlotStatus.AVAILABLE)
                .count();
        int bookedSlots = (int) allSlots.stream()
                .filter(slot -> slot.getSlotStatus() == SlotStatus.BOOKED)
                .count();
        int blockedSlots = (int) allSlots.stream()
                .filter(slot -> slot.getSlotStatus() == SlotStatus.BLOCKED)
                .count();

        List<TimeSlotResponse> slotResponses = allSlots.stream()
                .map(slot -> mapToTimeSlotResponse(slot, null))
                .collect(Collectors.toList());

        return SlotAvailabilityResponse.builder()
                .date(date.toString())
                .totalSlots(totalSlots)
                .availableSlots(availableSlots)
                .bookedSlots(bookedSlots)
                .blockedSlots(blockedSlots)
                .slots(slotResponses)
                .build();
    }

    @Transactional(readOnly = true)
    public TimeSlotResponse getSlotById(Long doctorId, Long slotId) {
        log.info("Fetching slot ID: {} for doctor ID: {}", slotId, doctorId);

        DoctorTimeSlot slot = slotRepository.findById(slotId)
                .orElseThrow(() -> new DoctorException("Slot not found with ID: " + slotId));

        if (!slot.getDoctorId().equals(doctorId)) {
            throw new DoctorException("Slot does not belong to this doctor");
        }

        return mapToTimeSlotResponse(slot, null);
    }

    @Transactional
    public TimeSlotResponse blockSlot(Long doctorId, Long slotId, BlockSlotRequest request) {
        log.info("Blocking slot ID: {} for doctor ID: {}", slotId, doctorId);

        DoctorTimeSlot slot = slotRepository.findById(slotId)
                .orElseThrow(() -> new DoctorException("Slot not found with ID: " + slotId));

        if (!slot.getDoctorId().equals(doctorId)) {
            throw new DoctorException("Slot does not belong to this doctor");
        }

        if (slot.getSlotStatus() == SlotStatus.BOOKED) {
            throw new DoctorException("Cannot block a slot that is already booked");
        }

        slot.setSlotStatus(SlotStatus.BLOCKED);
        slot.setNotes(request.getNotes());

        DoctorTimeSlot updatedSlot = slotRepository.save(slot);
        log.info("Slot blocked successfully: {}", slotId);

        return mapToTimeSlotResponse(updatedSlot, "Slot blocked successfully");
    }

    @Transactional
    public TimeSlotResponse unblockSlot(Long doctorId, Long slotId) {
        log.info("Unblocking slot ID: {} for doctor ID: {}", slotId, doctorId);

        DoctorTimeSlot slot = slotRepository.findById(slotId)
                .orElseThrow(() -> new DoctorException("Slot not found with ID: " + slotId));

        if (!slot.getDoctorId().equals(doctorId)) {
            throw new DoctorException("Slot does not belong to this doctor");
        }

        if (slot.getSlotStatus() != SlotStatus.BLOCKED) {
            throw new DoctorException("Slot is not in blocked status");
        }

        slot.setSlotStatus(SlotStatus.AVAILABLE);
        slot.setNotes(null);

        DoctorTimeSlot updatedSlot = slotRepository.save(slot);
        log.info("Slot unblocked successfully: {}", slotId);

        return mapToTimeSlotResponse(updatedSlot, "Slot unblocked successfully");
    }

    @Transactional
    public TimeSlotResponse bookSlot(Long doctorId, Long slotId, BookSlotRequest request) {
        log.info("Booking slot ID: {} for doctor ID: {} with appointment ID: {}",
                slotId, doctorId, request.getAppointmentId());

        DoctorTimeSlot slot = slotRepository.findById(slotId)
                .orElseThrow(() -> new DoctorException("Slot not found with ID: " + slotId));

        if (!slot.getDoctorId().equals(doctorId)) {
            throw new DoctorException("Slot does not belong to this doctor");
        }

        if (slot.getSlotStatus() != SlotStatus.AVAILABLE) {
            throw new DoctorException("Slot is not available for booking");
        }

        slot.setSlotStatus(SlotStatus.BOOKED);
        slot.setAppointmentId(request.getAppointmentId());

        DoctorTimeSlot bookedSlot = slotRepository.save(slot);
        log.info("Slot booked successfully: {}", slotId);

        return mapToTimeSlotResponse(bookedSlot, "Slot booked successfully");
    }

    // Helper methods
    private List<DoctorTimeSlot> generateSlotsForPeriod(
            Doctor doctor,
            LocalDate date,
            LocalTime startTime,
            LocalTime endTime,
            ConsultationType consultationType) {

        List<DoctorTimeSlot> slots = new ArrayList<>();
        LocalTime currentTime = startTime;
        int slotDuration = doctor.getSlotDuration();
        int bufferTime = doctor.getBufferTime();

        while (currentTime.plusMinutes(slotDuration).isBefore(endTime) ||
                currentTime.plusMinutes(slotDuration).equals(endTime)) {

            // Check if slot already exists
            boolean exists = slotRepository.existsByDoctorIdAndSlotDateAndSlotTime(
                    doctor.getId(), date, currentTime);

            if (!exists) {
                LocalTime slotEndTime = currentTime.plusMinutes(slotDuration);

                DoctorTimeSlot slot = DoctorTimeSlot.builder()
                        .doctorId(doctor.getId())
                        .slotDate(date)
                        .slotTime(currentTime)
                        .slotEndTime(slotEndTime)
                        .slotStatus(SlotStatus.AVAILABLE)
                        .consultationType(consultationType)
                        .build();

                slots.add(slot);
            }

            currentTime = currentTime.plusMinutes(slotDuration + bufferTime);
        }

        return slots;
    }

    private TimeSlotResponse mapToTimeSlotResponse(DoctorTimeSlot slot, String message) {
        boolean isBookable = slot.getSlotStatus() == SlotStatus.AVAILABLE
                && !slot.getSlotDate().isBefore(LocalDate.now());

        return TimeSlotResponse.builder()
                .id(slot.getId())
                .doctorId(slot.getDoctorId())
                .slotDate(slot.getSlotDate().toString())
                .slotTime(slot.getSlotTime().toString())
                .slotEndTime(slot.getSlotEndTime().toString())
                .slotStatus(slot.getSlotStatus().name())
                .appointmentId(slot.getAppointmentId())
                .consultationType(slot.getConsultationType().name())
                .notes(slot.getNotes())
                .isBookable(isBookable)
                .message(message)
                .build();
    }
}
