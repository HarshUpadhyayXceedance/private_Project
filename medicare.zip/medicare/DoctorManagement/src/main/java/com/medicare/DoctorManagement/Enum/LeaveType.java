package com.medicare.DoctorManagement.Enum;

public enum LeaveType {
    CASUAL_LEAVE,
    SICK_LEAVE,
    VACATION,
    CONFERENCE,
    EMERGENCY_LEAVE,
    PUBLIC_HOLIDAY
}