package com.medicare.DoctorManagement.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "doctor_specializations",
        uniqueConstraints = @UniqueConstraint(columnNames = {"doctor_id", "specialization_name"}))
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DoctorSpecialisation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "doctor_id", nullable = false)
    private Long doctorId;

    @Column(name = "specialization_name", nullable = false)
    private String specializationName;

    @Column(name = "is_primary")
    @Builder.Default
    private Boolean isPrimary = false;

    @Column(name = "years_of_experience")
    private Integer yearsOfExperience;
}
