package com.medicare.DoctorManagement.Dto.Reponse;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserProfileResponse {
    private String userId;
    private String email;
    private String username;
    private String name;
    private String gender;
    private LocalDate dob;
    private String phone;
    private String address;
    private String profilePicture;
    private String role;
    private String status;
    private String profileStatus;
    private String createdAt;
    private String updatedAt;
}
