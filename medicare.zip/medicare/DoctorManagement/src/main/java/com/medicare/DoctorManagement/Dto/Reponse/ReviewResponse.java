package com.medicare.DoctorManagement.Dto.Reponse;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReviewResponse {
    private Long id;
    private Long doctorId;
    private String patientUserId;
    private String patientName;
    private Double rating;
    private String reviewText;
    private Long appointmentId;
    private String createdAt;
    private String message;
}