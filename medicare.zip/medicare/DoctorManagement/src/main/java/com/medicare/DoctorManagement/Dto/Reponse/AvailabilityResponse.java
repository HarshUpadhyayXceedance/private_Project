package com.medicare.DoctorManagement.Dto.Reponse;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AvailabilityResponse {
    private Long id;
    private Long doctorId;
    private String dayOfWeek;
    private String startTime;
    private String endTime;
    private Boolean isAvailable;
    private String consultationType;
    private String effectiveFrom;
    private String effectiveUntil;
    private String message;
}