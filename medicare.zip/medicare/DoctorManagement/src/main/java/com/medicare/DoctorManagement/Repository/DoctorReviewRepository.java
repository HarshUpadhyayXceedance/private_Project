package com.medicare.DoctorManagement.Repository;

import com.medicare.DoctorManagement.Entity.DoctorReview;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface DoctorReviewRepository extends JpaRepository<DoctorReview, Long> {

    Page<DoctorReview> findByDoctorIdOrderByCreatedAtDesc(Long doctorId, Pageable pageable);

    List<DoctorReview> findByDoctorIdOrderByCreatedAtDesc(Long doctorId);

    Optional<DoctorReview> findByDoctorIdAndPatientUserId(Long doctorId, String patientUserId);

    boolean existsByDoctorIdAndPatientUserId(Long doctorId, String patientUserId);

    @Query("SELECT AVG(r.rating) FROM DoctorReview r WHERE r.doctorId = :doctorId")
    Double calculateAverageRating(@Param("doctorId") Long doctorId);

    @Query("SELECT COUNT(r) FROM DoctorReview r WHERE r.doctorId = :doctorId")
    Integer countReviews(@Param("doctorId") Long doctorId);

    @Query("SELECT COUNT(r) FROM DoctorReview r WHERE r.doctorId = :doctorId " +
            "AND r.rating >= :minRating AND r.rating < :maxRating")
    Integer countByRatingRange(
            @Param("doctorId") Long doctorId,
            @Param("minRating") Double minRating,
            @Param("maxRating") Double maxRating
    );

    void deleteByDoctorId(Long doctorId);
}
