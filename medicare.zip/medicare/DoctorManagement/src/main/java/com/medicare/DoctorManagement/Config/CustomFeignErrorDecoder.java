package com.medicare.DoctorManagement.Config;

import com.medicare.DoctorManagement.Exception.DoctorException;
import feign.Response;
import feign.codec.ErrorDecoder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class CustomFeignErrorDecoder implements ErrorDecoder {

    private final ErrorDecoder defaultErrorDecoder = new Default();

    @Override
    public Exception decode(String methodKey, Response response) {
        log.error("Feign error in method: {}, Status: {}", methodKey, response.status());

        switch (response.status()) {
            case 400:
                return new DoctorException("Bad request to external service: " + methodKey);
            case 404:
                return new DoctorException("Resource not found in external service: " + methodKey);
            case 500:
                return new DoctorException("Internal server error in external service: " + methodKey);
            case 503:
                return new DoctorException("External service unavailable: " + methodKey);
            default:
                return defaultErrorDecoder.decode(methodKey, response);
        }
    }
}
