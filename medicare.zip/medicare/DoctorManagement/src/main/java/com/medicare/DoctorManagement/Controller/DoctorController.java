package com.medicare.DoctorManagement.Controller;

import com.medicare.DoctorManagement.Dto.Request.CreateDoctorRequest;
import com.medicare.DoctorManagement.Dto.Reponse.DoctorDetailsResponse;
import com.medicare.DoctorManagement.Dto.Reponse.DoctorResponse;
import com.medicare.DoctorManagement.Dto.Request.UpdateDoctorRequest;
import com.medicare.DoctorManagement.Service.DoctorService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/doctors")
@RequiredArgsConstructor
@Slf4j
public class DoctorController {

    @Autowired
    private final DoctorService doctorService;

    //========== BASIC CRUD ENDPOINT FOR DOCTOR =============//

    // Create doctor profile
    @PostMapping
    public ResponseEntity<DoctorResponse> createDoctor(@Valid @RequestBody CreateDoctorRequest request,
            @RequestHeader("Authorization") String authHeader) {

        log.info("POST /doctors - Create doctor profile for userId: {}", request.getUserId());
        DoctorResponse response = doctorService.createDoctor(request, authHeader);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    // Delete Doctor
    @DeleteMapping("/{doctorId}")
    public ResponseEntity<Void> deleteDoctor(@PathVariable Long doctorId) {
        log.info("DELETE /doctors/{} - Delete doctor", doctorId);
        doctorService.deleteDoctor(doctorId);
        return ResponseEntity.noContent().build();
    }

    // Update Doctor Profile
    @PatchMapping("/{doctorId}")
    public ResponseEntity<DoctorResponse> updateDoctor(
            @PathVariable Long doctorId,
            @Valid @RequestBody UpdateDoctorRequest request) {

        log.info("PATCH /doctors/{} - Update doctor profile", doctorId);
        DoctorResponse response = doctorService.updateDoctor(doctorId, request);
        return ResponseEntity.ok(response);
    }

    // Get Doctor Specific Detail  by ID
    @GetMapping("/{doctorId}")
    public ResponseEntity<DoctorResponse> getDoctorById(@PathVariable Long doctorId) {

        log.info("GET /doctors/{} - Get doctor by ID", doctorId);
        DoctorResponse response = doctorService.getDoctorById(doctorId);
        return ResponseEntity.ok(response);
    }

    //============ Advance Doctor Endpoints ===========//

    // Get Doctor Specific Detail by user ID [ FOR ADMIN/INTERNAL USE ]
    @GetMapping("/user/{userId}")
    public ResponseEntity<DoctorResponse> getDoctorByUserId(@PathVariable String userId) {
        log.info("GET /doctors/user/{} - Get doctor by user ID", userId);
        DoctorResponse response = doctorService.getDoctorByUserId(userId);
        return ResponseEntity.ok(response);
    }

    // Get Complete Doctor Details (Combined)
    @GetMapping("/{doctorId}/details")
    public ResponseEntity<DoctorDetailsResponse> getDoctorDetails(
            @PathVariable Long doctorId, @RequestHeader("Authorization") String authHeader) {

        log.info("GET /doctors/{}/details - Get complete doctor details", doctorId);
        DoctorDetailsResponse response = doctorService.getDoctorDetails(doctorId, authHeader);
        return ResponseEntity.ok(response);
    }

    // Get List of All Doctors (Paginated)
    @GetMapping
    public ResponseEntity<Page<DoctorResponse>> getAllDoctors(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        log.info("GET /doctors - Get all doctors (page={}, size={})", page, size);
        Pageable pageable = PageRequest.of(page, size);
        Page<DoctorResponse> response = doctorService.getAllDoctors(pageable);
        return ResponseEntity.ok(response);
    }

    // Searching Doctors by Specialization
    @GetMapping("/specialization/{specialization}")
    public ResponseEntity<List<DoctorResponse>> getDoctorsBySpecialization(
            @PathVariable String specialization) {

        log.info("GET /doctors/specialization/{} - Get doctors by specialization", specialization);
        List<DoctorResponse> response = doctorService.getDoctorsBySpecialization(specialization);
        return ResponseEntity.ok(response);
    }

    // Search doctors
    @GetMapping("/search")
    public ResponseEntity<Page<DoctorResponse>> searchDoctors(
            @RequestParam String query,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        log.info("GET /doctors/search?query={} - Search doctors", query);
        Pageable pageable = PageRequest.of(page, size);
        Page<DoctorResponse> response = doctorService.searchDoctors(query, pageable);
        return ResponseEntity.ok(response);
    }

    // Get top-rated doctors
    @GetMapping("/top-rated")
    public ResponseEntity<List<DoctorResponse>> getTopRatedDoctors(
            @RequestParam(defaultValue = "10") Integer limit) {

        log.info("GET /doctors/top-rated?limit={} - Get top rated doctors", limit);
        List<DoctorResponse> response = doctorService.getTopRatedDoctors(limit);
        return ResponseEntity.ok(response);
    }

    // Verify doctor (Admin only)
    @PutMapping("/{doctorId}/verify")
    public ResponseEntity<DoctorResponse> verifyDoctor(@PathVariable Long doctorId) {
        log.info("PUT /doctors/{}/verify - Verify doctor", doctorId);
        DoctorResponse response = doctorService.verifyDoctor(doctorId);
        return ResponseEntity.ok(response);
    }

}