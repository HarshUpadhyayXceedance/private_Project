package com.medicare.DoctorManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
public class DoctorManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoctorManagementApplication.class, args);
		System.out.println("=================================================== ");
		System.out.println("Doctor Management Application Started on PORT: 8083 ");
		System.out.println("=================================================== ");
	}

}

