package com.medicare.DoctorManagement.Entity;

import com.medicare.DoctorManagement.Enum.ConsultationType;
import com.medicare.DoctorManagement.Enum.DayOfWeek;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalTime;


@Entity
@Table(name = "doctor_availability", indexes = {
        @Index(name = "idx_doctor_day", columnList = "doctor_id, day_of_week")
})
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DoctorAvailability {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "doctor_id", nullable = false)
    private Long doctorId;

    @Enumerated(EnumType.STRING)
    @Column(name = "day_of_week", nullable = false, length = 20)
    private DayOfWeek dayOfWeek;

    @Column(name = "start_time", nullable = false)
    private LocalTime startTime;

    @Column(name = "end_time", nullable = false)
    private LocalTime endTime;

    @Column(name = "is_available")
    @Builder.Default
    private Boolean isAvailable = true;

    @Column(name = "effective_from")
    private LocalDate effectiveFrom;

    @Column(name = "effective_until")
    private LocalDate effectiveUntil;

    @Enumerated(EnumType.STRING)
    @Column(name = "consultation_type", length = 50)
    @Builder.Default
    private ConsultationType consultationType = ConsultationType.IN_CLINIC;
}
