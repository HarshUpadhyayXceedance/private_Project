package com.medicare.DoctorManagement.Dto.Reponse;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SlotAvailabilityResponse {
    private String date;
    private Integer totalSlots;
    private Integer availableSlots;
    private Integer bookedSlots;
    private Integer blockedSlots;
    private List<TimeSlotResponse> slots;
}