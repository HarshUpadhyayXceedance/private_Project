package com.medicare.DoctorManagement.Controller;

import com.medicare.DoctorManagement.Dto.Request.AddReviewRequest;
import com.medicare.DoctorManagement.Dto.Reponse.RatingResponse;
import com.medicare.DoctorManagement.Dto.Reponse.ReviewResponse;
import com.medicare.DoctorManagement.Service.ReviewService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/doctors/{doctorId}/reviews")
@RequiredArgsConstructor
@Slf4j
public class ReviewController {

    private final ReviewService reviewService;

    // Add review (Patient only)
    @PostMapping
    public ResponseEntity<ReviewResponse> addReview(
            @PathVariable Long doctorId,
            @Valid @RequestBody AddReviewRequest request,
            @RequestHeader("Authorization") String authHeader,
            @RequestHeader(value = "X-User-Id") String patientUserId) {

        log.info("POST /doctors/{}/reviews - Add review by patient: {}", doctorId, patientUserId);
        ReviewResponse response = reviewService.addReview(doctorId, patientUserId, request, authHeader);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    // Get doctor reviews (paginated)
    @GetMapping
    public ResponseEntity<Page<ReviewResponse>> getDoctorReviews(
            @PathVariable Long doctorId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestHeader("Authorization") String authHeader) {

        log.info("GET /doctors/{}/reviews - Get doctor reviews (page={}, size={})", doctorId, page, size);
        Pageable pageable = PageRequest.of(page, size);
        Page<ReviewResponse> response = reviewService.getDoctorReviews(doctorId, pageable, authHeader);
        return ResponseEntity.ok(response);
    }

    // Get doctor rating summary
    @GetMapping("/rating")
    public ResponseEntity<RatingResponse> getDoctorRating(@PathVariable Long doctorId) {
        log.info("GET /doctors/{}/reviews/rating - Get doctor rating summary", doctorId);
        RatingResponse response = reviewService.getDoctorRating(doctorId);
        return ResponseEntity.ok(response);
    }
}
