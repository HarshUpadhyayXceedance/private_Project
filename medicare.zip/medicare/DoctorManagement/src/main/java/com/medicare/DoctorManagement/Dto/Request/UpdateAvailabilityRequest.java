package com.medicare.DoctorManagement.Dto.Request;

import com.medicare.DoctorManagement.Enum.ConsultationType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateAvailabilityRequest {

    private LocalTime startTime;
    private LocalTime endTime;
    private Boolean isAvailable;
    private ConsultationType consultationType;
    private LocalDate effectiveFrom;
    private LocalDate effectiveUntil;
}
