package com.medicare.DoctorManagement.Dto.Reponse;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EducationResponse {
    private Long id;
    private Long employeeId;
    private String degree;
    private String institution;
    private Integer yearOfPassing;
    private String fieldOfStudy;
    private String gradeOrPercentage;
    private String message;
}