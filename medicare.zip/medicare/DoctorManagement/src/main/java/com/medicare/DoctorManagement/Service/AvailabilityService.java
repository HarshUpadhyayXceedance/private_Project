package com.medicare.DoctorManagement.Service;

import com.medicare.DoctorManagement.Dto.Reponse.AvailabilityResponse;
import com.medicare.DoctorManagement.Dto.Request.CreateAvailabilityRequest;
import com.medicare.DoctorManagement.Dto.Request.UpdateAvailabilityRequest;
import com.medicare.DoctorManagement.Entity.Doctor;
import com.medicare.DoctorManagement.Entity.DoctorAvailability;
import com.medicare.DoctorManagement.Enum.ConsultationType;
import com.medicare.DoctorManagement.Exception.DoctorException;
import com.medicare.DoctorManagement.Repository.DoctorAvailabilityRepository;
import com.medicare.DoctorManagement.Repository.DoctorRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class AvailabilityService {

    private final DoctorAvailabilityRepository availabilityRepository;
    private final DoctorRepository doctorRepository;

    @Transactional
    public AvailabilityResponse createAvailability(Long doctorId, CreateAvailabilityRequest request) {
        log.info("Creating availability for doctor ID: {}", doctorId);

        // Verify doctor exists
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new DoctorException("Doctor not found with ID: " + doctorId));

        // Validate times
        if (request.getEndTime().isBefore(request.getStartTime())) {
            throw new DoctorException("End time cannot be before start time");
        }

        // Check for overlapping availability on same day
        List<DoctorAvailability> existingAvailability = availabilityRepository
                .findByDoctorIdAndDayOfWeek(doctorId, request.getDayOfWeek());

        for (DoctorAvailability existing : existingAvailability) {
            if (timesOverlap(
                    request.getStartTime(),
                    request.getEndTime(),
                    existing.getStartTime(),
                    existing.getEndTime())) {
                throw new DoctorException(
                        "Availability overlaps with existing schedule on " + request.getDayOfWeek()
                );
            }
        }

        // Create availability
        DoctorAvailability availability = DoctorAvailability.builder()
                .doctorId(doctorId)
                .dayOfWeek(request.getDayOfWeek())
                .startTime(request.getStartTime())
                .endTime(request.getEndTime())
                .isAvailable(true)
                .effectiveFrom(request.getEffectiveFrom())
                .effectiveUntil(request.getEffectiveUntil())
                .consultationType(request.getConsultationType() != null ?
                        request.getConsultationType() : ConsultationType.IN_CLINIC)
                .build();

        DoctorAvailability savedAvailability = availabilityRepository.save(availability);
        log.info("Availability created successfully: {}", savedAvailability.getId());

        return mapToAvailabilityResponse(savedAvailability, "Availability created successfully");
    }

    @Transactional(readOnly = true)
    public List<AvailabilityResponse> getDoctorAvailability(Long doctorId) {
        log.info("Fetching availability for doctor ID: {}", doctorId);

        // Verify doctor exists
        if (!doctorRepository.existsById(doctorId)) {
            throw new DoctorException("Doctor not found with ID: " + doctorId);
        }

        return availabilityRepository.findByDoctorId(doctorId).stream()
                .map(availability -> mapToAvailabilityResponse(availability, null))
                .collect(Collectors.toList());
    }

    @Transactional
    public AvailabilityResponse updateAvailability(
            Long doctorId,
            Long availabilityId,
            UpdateAvailabilityRequest request) {

        log.info("Updating availability ID: {} for doctor ID: {}", availabilityId, doctorId);

        DoctorAvailability availability = availabilityRepository.findById(availabilityId)
                .orElseThrow(() -> new DoctorException("Availability not found with ID: " + availabilityId));

        if (!availability.getDoctorId().equals(doctorId)) {
            throw new DoctorException("Availability does not belong to this doctor");
        }

        // Update fields if provided
        if (request.getStartTime() != null) {
            availability.setStartTime(request.getStartTime());
        }
        if (request.getEndTime() != null) {
            availability.setEndTime(request.getEndTime());
        }
        if (request.getIsAvailable() != null) {
            availability.setIsAvailable(request.getIsAvailable());
        }
        if (request.getConsultationType() != null) {
            availability.setConsultationType(request.getConsultationType());
        }
        if (request.getEffectiveFrom() != null) {
            availability.setEffectiveFrom(request.getEffectiveFrom());
        }
        if (request.getEffectiveUntil() != null) {
            availability.setEffectiveUntil(request.getEffectiveUntil());
        }

        // Validate times if both are set
        if (availability.getEndTime().isBefore(availability.getStartTime())) {
            throw new DoctorException("End time cannot be before start time");
        }

        DoctorAvailability updatedAvailability = availabilityRepository.save(availability);
        log.info("Availability updated successfully: {}", availabilityId);

        return mapToAvailabilityResponse(updatedAvailability, "Availability updated successfully");
    }

    @Transactional
    public void deleteAvailability(Long doctorId, Long availabilityId) {
        log.info("Deleting availability ID: {} for doctor ID: {}", availabilityId, doctorId);

        DoctorAvailability availability = availabilityRepository.findById(availabilityId)
                .orElseThrow(() -> new DoctorException("Availability not found with ID: " + availabilityId));

        if (!availability.getDoctorId().equals(doctorId)) {
            throw new DoctorException("Availability does not belong to this doctor");
        }

        availabilityRepository.delete(availability);
        log.info("Availability deleted successfully: {}", availabilityId);
    }

    // Helper methods
    private boolean timesOverlap(
            java.time.LocalTime start1,
            java.time.LocalTime end1,
            java.time.LocalTime start2,
            java.time.LocalTime end2) {
        return start1.isBefore(end2) && end1.isAfter(start2);
    }

    private AvailabilityResponse mapToAvailabilityResponse(DoctorAvailability availability, String message) {
        return AvailabilityResponse.builder()
                .id(availability.getId())
                .doctorId(availability.getDoctorId())
                .dayOfWeek(availability.getDayOfWeek().name())
                .startTime(availability.getStartTime().toString())
                .endTime(availability.getEndTime().toString())
                .isAvailable(availability.getIsAvailable())
                .consultationType(availability.getConsultationType().name())
                .effectiveFrom(availability.getEffectiveFrom() != null ?
                        availability.getEffectiveFrom().toString() : null)
                .effectiveUntil(availability.getEffectiveUntil() != null ?
                        availability.getEffectiveUntil().toString() : null)
                .message(message)
                .build();
    }
}