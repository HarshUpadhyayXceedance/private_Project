package com.medicare.DoctorManagement.Dto.Reponse;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DoctorResponse {
    private Long id;
    private String userId;
    private Long employeeId;
    private String specialization;
    private String qualification;
    private Integer experience;
    private String medicalRegistrationNumber;
    private Boolean licenseVerified;
    private String verificationStatus;
    private String orgCode;
    private String orgName;
    private Boolean orgVerified;
    private Double consultationFee;
    private Double onlineConsultationFee;
    private Double emergencyConsultationFee;
    private Double followupConsultationFee;
    private String about;
    private String languagesSpoken;
    private String awards;
    private Integer slotDuration;
    private Integer bufferTime;
    private Double averageRating;
    private Integer totalReviews;
    private String createdAt;
    private String updatedAt;
    private String message;
}