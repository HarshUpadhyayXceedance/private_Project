package com.medicare.NotificationService.Enum;


public enum NotificationStatus {
    PENDING("Pending delivery"),
    QUEUED("Queued for processing"),
    SENDING("Currently sending"),
    SENT("Successfully sent"),
    DELIVERED("Delivered to recipient"),
    FAILED("Failed to send"),
    BOUNCED("Email bounced"),
    REJECTED("Rejected by recipient"),
    RETRY("Retry scheduled"),
    PERMANENTLY_FAILED("Permanently failed after max retries");

    private final String description;

    NotificationStatus(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}
