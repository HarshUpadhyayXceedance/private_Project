package com.medicare.NotificationService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
@EnableAsync
@EnableScheduling
public class NotificationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(NotificationServiceApplication.class, args);
		System.out.println("====================================");
		System.out.println("📧 Notification Service Started!");
		System.out.println("📍 Port: 8097");
		System.out.println("🔗 Context: /api/notification-service");
		System.out.println("📨 Email: Enabled");
		System.out.println("🔔 In-App: Enabled");
		System.out.println("🐰 RabbitMQ: localhost:5672");
		System.out.println("🗄️ Redis: localhost:6379");
		System.out.println("====================================");
	}
}
