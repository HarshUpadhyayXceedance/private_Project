package com.medicare.NotificationService.Enum;


public enum NotificationType {

    // Appointment Notifications
    APPOINTMENT_BOOKED("Appointment Booked", "appointment-booked"),
    APPOINTMENT_CONFIRMED("Appointment Confirmed", "appointment-confirmed"),
    APPOINTMENT_CANCELLED("Appointment Cancelled", "appointment-cancelled"),
    APPOINTMENT_RESCHEDULED("Appointment Rescheduled", "appointment-rescheduled"),
    APPOINTMENT_REMINDER("Appointment Reminder", "appointment-reminder"),
    APPOINTMENT_COMPLETED("Appointment Completed", "appointment-completed"),

    // Prescription Notifications
    PRESCRIPTION_READY("Prescription Ready", "prescription-ready"),
    PRESCRIPTION_DISPENSED("Prescription Dispensed", "prescription-dispensed"),

    // Payment Notifications
    PAYMENT_RECEIVED("Payment Received", "payment-confirmation"),
    PAYMENT_FAILED("Payment Failed", "payment-failed"),
    PAYMENT_REFUND("Payment Refunded", "payment-refund"),

    // Lab Test Notifications
    LAB_TEST_SCHEDULED("Lab Test Scheduled", "lab-test-scheduled"),
    LAB_RESULTS_READY("Lab Results Ready", "lab-results-ready"),

    // Doctor Notifications
    NEW_PATIENT_REGISTERED("New Patient Registered", "new-patient"),
    LEAVE_APPROVED("Leave Approved", "leave-approved"),
    LEAVE_REJECTED("Leave Rejected", "leave-rejected"),
    NEW_REVIEW_RECEIVED("New Review Received", "new-review"),

    // Admin Notifications
    NEW_DOCTOR_REGISTRATION("New Doctor Registration", "new-doctor-registration"),
    LOW_STOCK_ALERT("Low Stock Alert", "low-stock-alert"),
    SYSTEM_ALERT("System Alert", "system-alert"),

    // General
    WELCOME("Welcome", "welcome"),
    PASSWORD_RESET("Password Reset", "password-reset"),
    ACCOUNT_ACTIVATED("Account Activated", "account-activated");

    private final String displayName;
    private final String templateName;

    NotificationType(String displayName, String templateName) {
        this.displayName = displayName;
        this.templateName = templateName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getTemplateName() {
        return templateName;
    }
}