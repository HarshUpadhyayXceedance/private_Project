package com.medicare.patientManagement.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@FeignClient(name = "USER-PROFILE-SERVICE", path = "/api/user-profile")
public interface UserProfileServiceClient {

    @GetMapping("/{userId}")
    ResponseEntity<Map<String, Object>> getUserProfile(
            @PathVariable("userId") String userId,
            @RequestHeader("Authorization") String authHeader
    );
}