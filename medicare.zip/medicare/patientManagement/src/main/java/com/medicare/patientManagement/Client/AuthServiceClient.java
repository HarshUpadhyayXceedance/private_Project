package com.medicare.patientManagement.Client;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;


@FeignClient(name = "AUTH-SERVICE", path = "/api/auth")
public interface AuthServiceClient {

    @GetMapping("/validate")
    ResponseEntity<Map<String, Object>> validateToken(
            @RequestHeader("Authorization") String authHeader
    );

    @GetMapping("/user/{userId}")
    ResponseEntity<Map<String, Object>> getUserById(
            @PathVariable("userId") String userId,
            @RequestHeader("Authorization") String authHeader
    );
}



