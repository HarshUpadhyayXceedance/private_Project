package com.medicare.patientManagement.Dto;

import com.medicare.patientManagement.Enums.RecordType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateMedicalRecordRequest {

    @NotNull(message = "Patient ID is required")
    private Long patientId;

    @NotNull(message = "Visit date is required")
    @PastOrPresent(message = "Visit date cannot be in the future")
    private LocalDate visitDate;

    private String diagnosis;
    private String symptoms;
    private String treatment;
    private Long prescriptionId;
    private String doctorId;
    private String notes;

    @Builder.Default
    private RecordType recordType = RecordType.CONSULTATION;
}
