package com.medicare.patientManagement.Service;

import com.medicare.patientManagement.Dto.CreateVitalSignsRequest;
import com.medicare.patientManagement.Dto.VitalSignsResponse;
import com.medicare.patientManagement.Entity.VitalSigns;
import com.medicare.patientManagement.Exception.PatientException;
import com.medicare.patientManagement.Repository.PatientRepository;
import com.medicare.patientManagement.Repository.VitalSignsRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class VitalSignsService {

    private final VitalSignsRepository vitalSignsRepository;
    private final PatientRepository patientRepository;

    /**
     * Record new vital signs
     */
    @Transactional
    public VitalSignsResponse recordVitalSigns(CreateVitalSignsRequest request) {
        log.info("Recording vital signs for patient ID: {}", request.getPatientId());

        // Validate patient exists
        if (!patientRepository.existsById(request.getPatientId())) {
            throw new PatientException("Patient not found with ID: " + request.getPatientId());
        }

        // Create vital signs record
        VitalSigns vitalSigns = VitalSigns.builder()
                .patientId(request.getPatientId())
                .bloodPressureSystolic(request.getBloodPressureSystolic())
                .bloodPressureDiastolic(request.getBloodPressureDiastolic())
                .heartRate(request.getHeartRate())
                .temperature(request.getTemperature())
                .weight(request.getWeight() != null ? BigDecimal.valueOf(request.getWeight()) : null)
                .height(request.getHeight() != null ? BigDecimal.valueOf(request.getHeight()) : null)
                .oxygenSaturation(request.getOxygenSaturation())
                .recordedBy(request.getRecordedBy())
                .notes(request.getNotes())
                .build();

        // BMI will be auto-calculated in @PrePersist/@PreUpdate
        VitalSigns savedVitalSigns = vitalSignsRepository.save(vitalSigns);
        log.info("Vital signs recorded successfully with ID: {}", savedVitalSigns.getId());

        return mapToVitalSignsResponse(savedVitalSigns);
    }

    /**
     * Get vital signs by ID
     */
    @Transactional(readOnly = true)
    public VitalSignsResponse getVitalSignsById(Long vitalSignsId) {
        log.info("Fetching vital signs by ID: {}", vitalSignsId);

        VitalSigns vitalSigns = vitalSignsRepository.findById(vitalSignsId)
                .orElseThrow(() -> new PatientException("Vital signs not found with ID: " + vitalSignsId));

        return mapToVitalSignsResponse(vitalSigns);
    }

    /**
     * Get all vital signs for a patient
     */
    @Transactional(readOnly = true)
    public Page<VitalSignsResponse> getVitalSignsByPatientId(Long patientId, Pageable pageable) {
        log.info("Fetching vital signs for patient ID: {}", patientId);

        // Validate patient exists
        if (!patientRepository.existsById(patientId)) {
            throw new PatientException("Patient not found with ID: " + patientId);
        }

        Page<VitalSigns> vitalSigns = vitalSignsRepository.findByPatientId(patientId, pageable);
        return vitalSigns.map(this::mapToVitalSignsResponse);
    }

    /**
     * Get vital signs by date range
     */
    @Transactional(readOnly = true)
    public List<VitalSignsResponse> getVitalSignsByDateRange(
            Long patientId,
            LocalDateTime startDate,
            LocalDateTime endDate) {

        log.info("Fetching vital signs for patient {} between {} and {}",
                patientId, startDate, endDate);

        List<VitalSigns> vitalSigns = vitalSignsRepository
                .findByPatientIdAndDateRange(patientId, startDate, endDate);

        return vitalSigns.stream()
                .map(this::mapToVitalSignsResponse)
                .collect(Collectors.toList());
    }

    /**
     * Get latest vital signs for patient
     */
    @Transactional(readOnly = true)
    public VitalSignsResponse getLatestVitalSigns(Long patientId) {
        log.info("Fetching latest vital signs for patient ID: {}", patientId);

        VitalSigns vitalSigns = vitalSignsRepository.findLatestByPatientId(patientId)
                .orElseThrow(() -> new PatientException("No vital signs found for patient ID: " + patientId));

        return mapToVitalSignsResponse(vitalSigns);
    }

    /**
     * Count vital signs records for patient
     */
    @Transactional(readOnly = true)
    public long countVitalSigns(Long patientId) {
        return vitalSignsRepository.countByPatientId(patientId);
    }

    /**
     * Delete vital signs record
     */
    @Transactional
    public void deleteVitalSigns(Long vitalSignsId) {
        log.info("Deleting vital signs record ID: {}", vitalSignsId);

        if (!vitalSignsRepository.existsById(vitalSignsId)) {
            throw new PatientException("Vital signs not found with ID: " + vitalSignsId);
        }

        vitalSignsRepository.deleteById(vitalSignsId);
        log.info("Vital signs record deleted successfully");
    }

    // ============= HELPER METHODS =============

    /**
     * Map VitalSigns entity to VitalSignsResponse DTO
     */
    private VitalSignsResponse mapToVitalSignsResponse(VitalSigns vitalSigns) {
        DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;

        // Format blood pressure as "systolic/diastolic"
        String bloodPressure = null;
        if (vitalSigns.getBloodPressureSystolic() != null &&
                vitalSigns.getBloodPressureDiastolic() != null) {
            bloodPressure = vitalSigns.getBloodPressureSystolic() + "/" +
                    vitalSigns.getBloodPressureDiastolic();
        }

        return VitalSignsResponse.builder()
                .id(vitalSigns.getId())
                .patientId(vitalSigns.getPatientId())
                .recordedDate(vitalSigns.getRecordedDate().format(formatter))
                .bloodPressure(bloodPressure)
                .heartRate(vitalSigns.getHeartRate())
                .temperature(vitalSigns.getTemperature())
                .weight(vitalSigns.getWeight() != null ? vitalSigns.getWeight().doubleValue() : null)
                .height(vitalSigns.getHeight() != null ? vitalSigns.getHeight().doubleValue() : null)
                .bmi(vitalSigns.getBmi() != null ? vitalSigns.getBmi().doubleValue() : null)
                .oxygenSaturation(vitalSigns.getOxygenSaturation())
                .recordedBy(vitalSigns.getRecordedBy())
                .notes(vitalSigns.getNotes())
                .build();
    }
}
