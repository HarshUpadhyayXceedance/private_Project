package com.medicare.patientManagement.Exception;

public class PatientException extends RuntimeException {
    public PatientException(String message) {
        super(message);
    }
}