package com.medicare.patientManagement.Enums;

public enum DocumentType {
    PRESCRIPTION("Prescription"),
    LAB_REPORT("Laboratory Report"),
    IMAGING_REPORT("Imaging Report"),
    DISCHARGE_SUMMARY("Discharge Summary"),
    INSURANCE_CARD("Insurance Card"),
    ID_PROOF("ID Proof"),
    MEDICAL_CERTIFICATE("Medical Certificate"),
    VACCINATION_CARD("Vaccination Card"),
    OTHER("Other Document");

    private final String displayName;

    DocumentType(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
