package com.medicare.patientManagement.Dto;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateVitalSignsRequest {

    @NotNull(message = "Patient ID is required")
    private Long patientId;

    @Min(value = 60, message = "Systolic pressure must be at least 60")
    @Max(value = 250, message = "Systolic pressure must not exceed 250")
    private Integer bloodPressureSystolic;

    @Min(value = 40, message = "Diastolic pressure must be at least 40")
    @Max(value = 150, message = "Diastolic pressure must not exceed 150")
    private Integer bloodPressureDiastolic;

    @Min(value = 40, message = "Heart rate must be at least 40")
    @Max(value = 200, message = "Heart rate must not exceed 200")
    private Integer heartRate;

    @DecimalMin(value = "95.0", message = "Temperature must be at least 95°F")
    @DecimalMax(value = "106.0", message = "Temperature must not exceed 106°F")
    private Double temperature;

    @DecimalMin(value = "1.0", message = "Weight must be at least 1 kg")
    @DecimalMax(value = "500.0", message = "Weight must not exceed 500 kg")
    private Double weight;

    @DecimalMin(value = "30.0", message = "Height must be at least 30 cm")
    @DecimalMax(value = "250.0", message = "Height must not exceed 250 cm")
    private Double height;

    @Min(value = 0, message = "Oxygen saturation must be at least 0")
    @Max(value = 100, message = "Oxygen saturation must not exceed 100")
    private Integer oxygenSaturation;

    private String recordedBy;
    private String notes;
}
