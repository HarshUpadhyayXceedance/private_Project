package com.medicare.patientManagement.Enums;

public enum RecordType {
    CONSULTATION("Regular Consultation"),
    EMERGENCY("Emergency Visit"),
    FOLLOW_UP("Follow-up Visit"),
    SURGERY("Surgical Procedure"),
    LAB_TEST("Laboratory Test"),
    IMAGING("Imaging/Radiology"),
    VACCINATION("Vaccination"),
    CHECKUP("Routine Checkup"),
    OTHER("Other");

    private final String displayName;

    RecordType(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
