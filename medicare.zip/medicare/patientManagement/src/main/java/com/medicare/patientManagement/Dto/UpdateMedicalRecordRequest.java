package com.medicare.patientManagement.Dto;

import com.medicare.patientManagement.Enums.RecordType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateMedicalRecordRequest {

    private String diagnosis;
    private String symptoms;
    private String treatment;
    private Long prescriptionId;
    private String notes;
    private RecordType recordType;
}
