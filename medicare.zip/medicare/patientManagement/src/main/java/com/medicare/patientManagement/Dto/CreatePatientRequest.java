package com.medicare.patientManagement.Dto;

import com.medicare.patientManagement.Enums.BloodGroup;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreatePatientRequest {

    @NotBlank(message = "User ID is required")
    private String userId;

    private BloodGroup bloodGroup;

    private String allergies;

    private String chronicConditions;

    private String insuranceProvider;

    private String insuranceNumber;

    @NotBlank(message = "Emergency contact name is required")
    private String emergencyContactName;

    @NotBlank(message = "Emergency contact phone is required")
    @Pattern(regexp = "^[0-9]{10}$", message = "Phone number must be 10 digits")
    private String emergencyContactPhone;

    private String emergencyContactRelation;
}

