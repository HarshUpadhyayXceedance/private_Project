package com.medicare.patientManagement.Dto;

import com.medicare.patientManagement.Enums.BloodGroup;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdatePatientRequest {

    private BloodGroup bloodGroup;
    private String allergies;
    private String chronicConditions;
    private String insuranceProvider;
    private String insuranceNumber;
    private String emergencyContactName;

    @Pattern(regexp = "^[0-9]{10}$", message = "Phone number must be 10 digits")
    private String emergencyContactPhone;

    private String emergencyContactRelation;
}