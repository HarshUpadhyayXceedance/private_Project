package com.medicare.patientManagement.Controller;

import com.medicare.patientManagement.Dto.CreateMedicalRecordRequest;
import com.medicare.patientManagement.Dto.MedicalRecordResponse;
import com.medicare.patientManagement.Dto.UpdateMedicalRecordRequest;
import com.medicare.patientManagement.Enums.RecordType;
import com.medicare.patientManagement.Service.MedicalRecordService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/patients/{patientId}/medical-records")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "*", maxAge = 3600)
public class MedicalRecordController {

    private final MedicalRecordService medicalRecordService;


    @PostMapping
    @PreAuthorize("hasAnyRole('DOCTOR', 'ADMIN')")
    public ResponseEntity<MedicalRecordResponse> createMedicalRecord(
            @PathVariable Long patientId,
            @Valid @RequestBody CreateMedicalRecordRequest request) {

        log.info("Creating medical record for patient ID: {}", patientId);

        // Ensure patientId in path matches patientId in request
        request.setPatientId(patientId);

        MedicalRecordResponse response = medicalRecordService.createMedicalRecord(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }


    @GetMapping
    @PreAuthorize("hasAnyRole('PATIENT', 'DOCTOR', 'ADMIN')")
    public ResponseEntity<Page<MedicalRecordResponse>> getMedicalRecords(
            @PathVariable Long patientId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        log.info("Fetching medical records for patient ID: {}", patientId);
        Pageable pageable = PageRequest.of(page, size);
        Page<MedicalRecordResponse> records = medicalRecordService.getMedicalRecordsByPatientId(patientId, pageable);
        return ResponseEntity.ok(records);
    }


    @GetMapping("/{recordId}")
    @PreAuthorize("hasAnyRole('PATIENT', 'DOCTOR', 'ADMIN')")
    public ResponseEntity<MedicalRecordResponse> getMedicalRecordById(
            @PathVariable Long patientId,
            @PathVariable Long recordId) {

        log.info("Fetching medical record ID: {} for patient ID: {}", recordId, patientId);
        MedicalRecordResponse response = medicalRecordService.getMedicalRecordById(recordId);
        return ResponseEntity.ok(response);
    }


    @GetMapping("/date-range")
    @PreAuthorize("hasAnyRole('PATIENT', 'DOCTOR', 'ADMIN')")
    public ResponseEntity<List<MedicalRecordResponse>> getMedicalRecordsByDateRange(
            @PathVariable Long patientId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {

        log.info("Fetching medical records between {} and {}", startDate, endDate);
        List<MedicalRecordResponse> records = medicalRecordService
                .getMedicalRecordsByDateRange(patientId, startDate, endDate);
        return ResponseEntity.ok(records);
    }


    @GetMapping("/recent")
    @PreAuthorize("hasAnyRole('PATIENT', 'DOCTOR', 'ADMIN')")
    public ResponseEntity<List<MedicalRecordResponse>> getRecentMedicalRecords(
            @PathVariable Long patientId,
            @RequestParam(defaultValue = "5") int limit) {

        log.info("Fetching recent {} medical records", limit);
        List<MedicalRecordResponse> records = medicalRecordService
                .getRecentMedicalRecords(patientId, limit);
        return ResponseEntity.ok(records);
    }


    @GetMapping("/type/{recordType}")
    @PreAuthorize("hasAnyRole('PATIENT', 'DOCTOR', 'ADMIN')")
    public ResponseEntity<List<MedicalRecordResponse>> getMedicalRecordsByType(
            @PathVariable Long patientId,
            @PathVariable RecordType recordType) {

        log.info("Fetching {} records for patient ID: {}", recordType, patientId);
        List<MedicalRecordResponse> records = medicalRecordService
                .getMedicalRecordsByType(patientId, recordType);
        return ResponseEntity.ok(records);
    }


    @PatchMapping("/{recordId}")
    @PreAuthorize("hasAnyRole('DOCTOR', 'ADMIN')")
    public ResponseEntity<MedicalRecordResponse> updateMedicalRecord(
            @PathVariable Long patientId,
            @PathVariable Long recordId,
            @Valid @RequestBody UpdateMedicalRecordRequest request) {

        log.info("Updating medical record ID: {}", recordId);
        MedicalRecordResponse response = medicalRecordService.updateMedicalRecord(recordId, request);
        return ResponseEntity.ok(response);
    }


    @DeleteMapping("/{recordId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deleteMedicalRecord(
            @PathVariable Long patientId,
            @PathVariable Long recordId) {

        log.info("Deleting medical record ID: {}", recordId);
        medicalRecordService.deleteMedicalRecord(recordId);
        return ResponseEntity.noContent().build();
    }
}

