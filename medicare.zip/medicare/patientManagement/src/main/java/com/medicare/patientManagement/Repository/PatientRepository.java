package com.medicare.patientManagement.Repository;

import com.medicare.patientManagement.Entity.Patient;
import com.medicare.patientManagement.Enums.BloodGroup;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface PatientRepository extends JpaRepository<Patient, Long> {

    Optional<Patient> findByUserId(String userId);
    boolean existsByUserId(String userId);
    List<Patient> findByBloodGroup(BloodGroup bloodGroup);
    Page<Patient> findAll(Pageable pageable);


    @Query("SELECT p FROM Patient p WHERE p.userId LIKE %:searchTerm%")
    List<Patient> searchPatients(@Param("searchTerm") String searchTerm);


    @Query("SELECT p FROM Patient p WHERE p.chronicConditions LIKE %:condition%")
    List<Patient> findByChronicConditionsContaining(@Param("condition") String condition);


    @Query("SELECT p FROM Patient p WHERE p.allergies IS NOT NULL AND p.allergies != ''")
    List<Patient> findPatientsWithAllergies();

    long countByBloodGroup(BloodGroup bloodGroup);
}





