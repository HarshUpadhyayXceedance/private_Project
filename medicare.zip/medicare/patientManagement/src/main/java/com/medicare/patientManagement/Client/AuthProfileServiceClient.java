package com.medicare.patientManagement.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@FeignClient(
        name = "auth-profile-client",
        url = "${auth-profile.service.url:http://localhost:8080}",
        path = "/api/auth-profile"
)
public interface AuthProfileServiceClient {

    @GetMapping("/validate")
    ResponseEntity<Map<String, Object>> validateToken(
            @RequestHeader("Authorization") String authHeader
    );

    @GetMapping("/auth/user/{userId}")
    ResponseEntity<Map<String, Object>> getUserById(
            @PathVariable("userId") String userId,
            @RequestHeader("Authorization") String authHeader
    );

    @GetMapping("/profiles/{userId}")
    ResponseEntity<Map<String, Object>> getUserProfile(
            @PathVariable("userId") String userId,
            @RequestHeader("Authorization") String authHeader
    );

}
