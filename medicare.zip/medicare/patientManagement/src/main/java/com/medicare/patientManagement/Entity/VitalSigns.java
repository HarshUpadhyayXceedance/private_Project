package com.medicare.patientManagement.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;

@Entity
@Table(name = "vital_signs", indexes = {
        @Index(name = "idx_patient_date", columnList = "patient_id, recorded_date")})
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VitalSigns {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "patient_id", nullable = false)
    private Long patientId;

    @CreationTimestamp
    @Column(name = "recorded_date")
    private LocalDateTime recordedDate;

    @Column(name = "blood_pressure_systolic")
    private Integer bloodPressureSystolic;  // mmHg

    @Column(name = "blood_pressure_diastolic")
    private Integer bloodPressureDiastolic;  // mmHg

    @Column(name = "heart_rate")
    private Integer heartRate;  // bpm

    @Column(name = "temperature")
    private Double temperature;  // Fahrenheit (approx values fine with Double)

    @Column(precision = 5, scale = 2)
    private BigDecimal weight;  // kg, exact

    @Column(precision = 5, scale = 2)
    private BigDecimal height;  // cm, exact

    @Column(precision = 5, scale = 2)
    private BigDecimal bmi;  // Auto-calculated, exact

    @Column(name = "oxygen_saturation")
    private Integer oxygenSaturation;  // percentage (SpO2)

    @Column(name = "recorded_by")
    private String recordedBy;  // Doctor/Nurse name

    @Column(columnDefinition = "TEXT")
    private String notes;

    @PrePersist
    @PreUpdate
    public void calculateBmi() {
        if (weight != null && height != null && height.compareTo(BigDecimal.ZERO) > 0) {
            // Convert cm → meters
            BigDecimal heightInMeters = height.divide(BigDecimal.valueOf(100), 4, RoundingMode.HALF_UP);
            BigDecimal heightSquared = heightInMeters.multiply(heightInMeters);

            this.bmi = weight.divide(heightSquared, 2, RoundingMode.HALF_UP); // round to 2 decimals
        }
    }
}
