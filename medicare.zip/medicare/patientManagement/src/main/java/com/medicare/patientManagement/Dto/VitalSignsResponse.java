package com.medicare.patientManagement.Dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VitalSignsResponse {

    private Long id;
    private Long patientId;
    private String recordedDate;
    private String bloodPressure;  // Formatted as "120/80"
    private Integer heartRate;
    private Double temperature;
    private Double weight;
    private Double height;
    private Double bmi;
    private Integer oxygenSaturation;
    private String recordedBy;
    private String notes;
}