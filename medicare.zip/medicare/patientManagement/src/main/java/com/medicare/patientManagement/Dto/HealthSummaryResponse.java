package com.medicare.patientManagement.Dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HealthSummaryResponse {

    private PatientResponse patientInfo;
    private VitalSignsResponse latestVitals;
    private List<String> activeConditions;
    private List<String> allergies;
    private List<MedicalRecordResponse> recentVisits;
    private String summary;
}
