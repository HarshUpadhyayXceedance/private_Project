package com.medicare.patientManagement.Dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MedicalRecordResponse {

    private Long id;
    private Long patientId;
    private String visitDate;
    private String diagnosis;
    private String symptoms;
    private String treatment;
    private Long prescriptionId;
    private String doctorId;
    private String notes;
    private String recordType;
    private String createdAt;
    private String updatedAt;
}
