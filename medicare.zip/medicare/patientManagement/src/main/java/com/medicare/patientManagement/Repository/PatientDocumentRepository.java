package com.medicare.patientManagement.Repository;

import com.medicare.patientManagement.Entity.PatientDocument;
import com.medicare.patientManagement.Enums.DocumentType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;


@Repository
public interface PatientDocumentRepository extends JpaRepository<PatientDocument, Long> {

    List<PatientDocument> findByPatientId(Long patientId);
    List<PatientDocument> findByPatientIdAndDocumentType(Long patientId, DocumentType documentType);
    long countByPatientId(Long patientId);
    List<PatientDocument> findByUploadedBy(String uploadedBy);
}
