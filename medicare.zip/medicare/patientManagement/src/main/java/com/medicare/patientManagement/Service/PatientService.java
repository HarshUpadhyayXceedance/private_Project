package com.medicare.patientManagement.Service;



import com.medicare.patientManagement.Client.AuthServiceClient;
import com.medicare.patientManagement.Dto.CreatePatientRequest;
import com.medicare.patientManagement.Dto.EmergencyContactResponse;
import com.medicare.patientManagement.Dto.PatientResponse;
import com.medicare.patientManagement.Dto.UpdatePatientRequest;
import com.medicare.patientManagement.Entity.Patient;
import com.medicare.patientManagement.Enums.BloodGroup;
import com.medicare.patientManagement.Exception.PatientException;
import com.medicare.patientManagement.Repository.PatientRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Patient Service
 * Handles all patient-related business logic
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class PatientService {

    private final PatientRepository patientRepository;
    private final AuthServiceClient authServiceClient;

    @Transactional
    public PatientResponse createPatient(CreatePatientRequest request, String authHeader) {
        log.info("Creating patient profile for userId: {}", request.getUserId());

        // Check if patient already exists
        if (patientRepository.existsByUserId(request.getUserId())) {
            throw new PatientException("Patient profile already exists for this user");
        }

        // Validate user exists in Auth Service
        validateUserExists(request.getUserId(), authHeader);

        // Create patient entity
        Patient patient = Patient.builder()
                .userId(request.getUserId())
                .bloodGroup(request.getBloodGroup())
                .allergies(request.getAllergies())
                .chronicConditions(request.getChronicConditions())
                .insuranceProvider(request.getInsuranceProvider())
                .insuranceNumber(request.getInsuranceNumber())
                .emergencyContactName(request.getEmergencyContactName())
                .emergencyContactPhone(request.getEmergencyContactPhone())
                .emergencyContactRelation(request.getEmergencyContactRelation())
                .build();

        Patient savedPatient = patientRepository.save(patient);
        log.info("Patient profile created successfully with ID: {}", savedPatient.getId());

        return mapToPatientResponse(savedPatient, "Patient profile created successfully");
    }

    /**
     * Get patient by ID
     */
    @Transactional(readOnly = true)
    public PatientResponse getPatientById(Long patientId) {
        log.info("Fetching patient by ID: {}", patientId);

        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new PatientException("Patient not found with ID: " + patientId));

        return mapToPatientResponse(patient, null);
    }

    /**
     * Get patient by user ID
     */
    @Transactional(readOnly = true)
    public PatientResponse getPatientByUserId(String userId) {
        log.info("Fetching patient by userId: {}", userId);

        Patient patient = patientRepository.findByUserId(userId)
                .orElseThrow(() -> new PatientException("Patient not found for user: " + userId));

        return mapToPatientResponse(patient, null);
    }

    /**
     * Get all patients with pagination
     */
    @Transactional(readOnly = true)
    public Page<PatientResponse> getAllPatients(Pageable pageable) {
        log.info("Fetching all patients - Page: {}, Size: {}",
                pageable.getPageNumber(), pageable.getPageSize());

        Page<Patient> patients = patientRepository.findAll(pageable);
        return patients.map(patient -> mapToPatientResponse(patient, null));
    }

    /**
     * Get patients by blood group
     */
    @Transactional(readOnly = true)
    public List<PatientResponse> getPatientsByBloodGroup(BloodGroup bloodGroup) {
        log.info("Fetching patients by blood group: {}", bloodGroup);

        List<Patient> patients = patientRepository.findByBloodGroup(bloodGroup);
        return patients.stream()
                .map(patient -> mapToPatientResponse(patient, null))
                .collect(Collectors.toList());
    }

    /**
     * Update patient profile
     */
    @Transactional
    public PatientResponse updatePatient(Long patientId, UpdatePatientRequest request) {
        log.info("Updating patient profile for ID: {}", patientId);

        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new PatientException("Patient not found with ID: " + patientId));

        // Update only non-null fields
        if (request.getBloodGroup() != null) {
            patient.setBloodGroup(request.getBloodGroup());
        }
        if (request.getAllergies() != null) {
            patient.setAllergies(request.getAllergies());
        }
        if (request.getChronicConditions() != null) {
            patient.setChronicConditions(request.getChronicConditions());
        }
        if (request.getInsuranceProvider() != null) {
            patient.setInsuranceProvider(request.getInsuranceProvider());
        }
        if (request.getInsuranceNumber() != null) {
            patient.setInsuranceNumber(request.getInsuranceNumber());
        }
        if (request.getEmergencyContactName() != null) {
            patient.setEmergencyContactName(request.getEmergencyContactName());
        }
        if (request.getEmergencyContactPhone() != null) {
            patient.setEmergencyContactPhone(request.getEmergencyContactPhone());
        }
        if (request.getEmergencyContactRelation() != null) {
            patient.setEmergencyContactRelation(request.getEmergencyContactRelation());
        }

        Patient updatedPatient = patientRepository.save(patient);
        log.info("Patient profile updated successfully");

        return mapToPatientResponse(updatedPatient, "Patient profile updated successfully");
    }

    /**
     * Get emergency contact for a patient
     */
    @Transactional(readOnly = true)
    public EmergencyContactResponse getEmergencyContact(Long patientId) {
        log.info("Fetching emergency contact for patient ID: {}", patientId);

        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new PatientException("Patient not found with ID: " + patientId));

        return EmergencyContactResponse.builder()
                .name(patient.getEmergencyContactName())
                .phone(patient.getEmergencyContactPhone())
                .relation(patient.getEmergencyContactRelation())
                .build();
    }

    /**
     * Update emergency contact
     */
    @Transactional
    public PatientResponse updateEmergencyContact(
            Long patientId,
            String name,
            String phone,
            String relation) {

        log.info("Updating emergency contact for patient ID: {}", patientId);

        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new PatientException("Patient not found with ID: " + patientId));

        if (name != null) {
            patient.setEmergencyContactName(name);
        }
        if (phone != null) {
            patient.setEmergencyContactPhone(phone);
        }
        if (relation != null) {
            patient.setEmergencyContactRelation(relation);
        }

        Patient updatedPatient = patientRepository.save(patient);
        log.info("Emergency contact updated successfully");

        return mapToPatientResponse(updatedPatient, "Emergency contact updated successfully");
    }

    /**
     * Get patients with allergies
     */
    @Transactional(readOnly = true)
    public List<PatientResponse> getPatientsWithAllergies() {
        log.info("Fetching patients with allergies");

        List<Patient> patients = patientRepository.findPatientsWithAllergies();
        return patients.stream()
                .map(patient -> mapToPatientResponse(patient, null))
                .collect(Collectors.toList());
    }

    /**
     * Search patients by chronic condition
     */
    @Transactional(readOnly = true)
    public List<PatientResponse> searchByChronicCondition(String condition) {
        log.info("Searching patients by chronic condition: {}", condition);

        List<Patient> patients = patientRepository.findByChronicConditionsContaining(condition);
        return patients.stream()
                .map(patient -> mapToPatientResponse(patient, null))
                .collect(Collectors.toList());
    }

    /**
     * Delete patient profile
     */
    @Transactional
    public void deletePatient(Long patientId) {
        log.info("Deleting patient profile with ID: {}", patientId);

        if (!patientRepository.existsById(patientId)) {
            throw new PatientException("Patient not found with ID: " + patientId);
        }

        patientRepository.deleteById(patientId);
        log.info("Patient profile deleted successfully");
    }

    /**
     * Get patient count by blood group
     */
    @Transactional(readOnly = true)
    public long getPatientCountByBloodGroup(BloodGroup bloodGroup) {
        return patientRepository.countByBloodGroup(bloodGroup);
    }

    // ============= HELPER METHODS =============

    /**
     * Validate user exists in Auth Service
     */
    private void validateUserExists(String userId, String authHeader) {
        try {
            var response = authServiceClient.getUserById(userId, authHeader);
            if (!response.getStatusCode().is2xxSuccessful()) {
                throw new PatientException("User not found in Auth Service");
            }
        } catch (Exception e) {
            log.error("Failed to validate user: {}", e.getMessage());
            throw new PatientException("Failed to validate user: " + e.getMessage());
        }
    }

    /**
     * Map Patient entity to PatientResponse DTO
     */
    private PatientResponse mapToPatientResponse(Patient patient, String message) {
        DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;

        return PatientResponse.builder()
                .id(patient.getId())
                .userId(patient.getUserId())
                .bloodGroup(patient.getBloodGroup() != null ? patient.getBloodGroup().getDisplayName() : null)
                .allergies(patient.getAllergies())
                .chronicConditions(patient.getChronicConditions())
                .insuranceProvider(patient.getInsuranceProvider())
                .insuranceNumber(patient.getInsuranceNumber())
                .emergencyContactName(patient.getEmergencyContactName())
                .emergencyContactPhone(patient.getEmergencyContactPhone())
                .emergencyContactRelation(patient.getEmergencyContactRelation())
                .createdAt(patient.getCreatedAt().format(formatter))
                .updatedAt(patient.getUpdatedAt().format(formatter))
                .message(message)
                .build();
    }
}
