package com.medicare.patientManagement.Service;

import com.medicare.patientManagement.Client.AuthProfileServiceClient;
import com.medicare.patientManagement.Dto.*;
import com.medicare.patientManagement.Entity.Patient;
import com.medicare.patientManagement.Enums.BloodGroup;
import com.medicare.patientManagement.Exception.PatientException;
import com.medicare.patientManagement.Repository.PatientRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

//Patient Service - Enhanced with Complete Profile Fetching
@Service
@RequiredArgsConstructor
@Slf4j
public class PatientService {

    private final PatientRepository patientRepository;
    private final AuthProfileServiceClient authServiceClient;

    //Get Complete Patient Profile
    @Transactional(readOnly = true)
    public CompletePatientProfileResponse getCompletePatientProfile(String userId, String authHeader) {
        log.info("Fetching complete patient profile for userId: {}", userId);

        try {
            // 1. Fetch Patient Data from local database
            Patient patient = patientRepository.findByUserId(userId)
                    .orElseThrow(() -> new PatientException("Patient not found for user: " + userId));

            // 2. Fetch User Profile from Auth-Profile Service
            Map<String, Object> profileData = fetchUserProfileFromAuthService(userId, authHeader);

            // 3. Fetch User Auth Data from Auth Service
            Map<String, Object> authData = fetchUserAuthFromAuthService(userId, authHeader);

            // 4. Combine all data into CompletePatientProfileResponse
            CompletePatientProfileResponse response = buildCompletePatientProfile(
                    patient,
                    authData,
                    profileData
            );

            log.info("Successfully fetched complete patient profile for userId: {}", userId);
            return response;

        } catch (Exception e) {
            log.error("Error fetching complete patient profile: {}", e.getMessage());
            throw new PatientException("Failed to fetch complete patient profile: " + e.getMessage());
        }
    }

    // Get Complete Patient Profile by Patient ID
    @Transactional(readOnly = true)
    public CompletePatientProfileResponse getCompletePatientProfileById(Long patientId, String authHeader) {
        log.info("Fetching complete patient profile for patientId: {}", patientId);

        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new PatientException("Patient not found with ID: " + patientId));

        return getCompletePatientProfile(patient.getUserId(), authHeader);
    }

    // Get All Complete Patient Profiles (Admin only)
    @Transactional(readOnly = true)
    public Page<CompletePatientProfileResponse> getAllCompletePatientProfiles(
            Pageable pageable,
            String authHeader) {

        log.info("Fetching all complete patient profiles");

        Page<Patient> patients = patientRepository.findAll(pageable);

        return patients.map(patient -> {
            try {
                return getCompletePatientProfile(patient.getUserId(), authHeader);
            } catch (Exception e) {
                log.error("Error fetching profile for patient {}: {}", patient.getId(), e.getMessage());
                // Return partial data if external services fail
                return buildPartialProfile(patient);
            }
        });
    }

    @Transactional
    public PatientResponse createPatient(CreatePatientRequest request, String authHeader) {
        log.info("Creating patient profile for userId: {}", request.getUserId());

        if (patientRepository.existsByUserId(request.getUserId())) {
            throw new PatientException("Patient profile already exists for this user");
        }

        validateUserExists(request.getUserId(), authHeader);

        Patient patient = Patient.builder()
                .userId(request.getUserId())
                .bloodGroup(request.getBloodGroup())
                .allergies(request.getAllergies())
                .chronicConditions(request.getChronicConditions())
                .insuranceProvider(request.getInsuranceProvider())
                .insuranceNumber(request.getInsuranceNumber())
                .emergencyContactName(request.getEmergencyContactName())
                .emergencyContactPhone(request.getEmergencyContactPhone())
                .emergencyContactRelation(request.getEmergencyContactRelation())
                .build();

        Patient savedPatient = patientRepository.save(patient);
        log.info("Patient profile created successfully with ID: {}", savedPatient.getId());

        return mapToPatientResponse(savedPatient, "Patient profile created successfully");
    }

    @Transactional(readOnly = true)
    public PatientResponse getPatientById(Long patientId) {
        log.info("Fetching patient by ID: {}", patientId);

        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new PatientException("Patient not found with ID: " + patientId));

        return mapToPatientResponse(patient, null);
    }

    @Transactional(readOnly = true)
    public PatientResponse getPatientByUserId(String userId) {
        log.info("Fetching patient by userId: {}", userId);

        Patient patient = patientRepository.findByUserId(userId)
                .orElseThrow(() -> new PatientException("Patient not found for user: " + userId));

        return mapToPatientResponse(patient, null);
    }

    @Transactional(readOnly = true)
    public Page<PatientResponse> getAllPatients(Pageable pageable) {
        log.info("Fetching all patients - Page: {}, Size: {}",
                pageable.getPageNumber(), pageable.getPageSize());

        Page<Patient> patients = patientRepository.findAll(pageable);
        return patients.map(patient -> mapToPatientResponse(patient, null));
    }

    @Transactional(readOnly = true)
    public List<PatientResponse> getPatientsByBloodGroup(BloodGroup bloodGroup) {
        log.info("Fetching patients by blood group: {}", bloodGroup);

        List<Patient> patients = patientRepository.findByBloodGroup(bloodGroup);
        return patients.stream()
                .map(patient -> mapToPatientResponse(patient, null))
                .collect(Collectors.toList());
    }

    @Transactional
    public PatientResponse updatePatient(Long patientId, UpdatePatientRequest request) {
        log.info("Updating patient profile for ID: {}", patientId);

        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new PatientException("Patient not found with ID: " + patientId));

        if (request.getBloodGroup() != null) {
            patient.setBloodGroup(request.getBloodGroup());
        }
        if (request.getAllergies() != null) {
            patient.setAllergies(request.getAllergies());
        }
        if (request.getChronicConditions() != null) {
            patient.setChronicConditions(request.getChronicConditions());
        }
        if (request.getInsuranceProvider() != null) {
            patient.setInsuranceProvider(request.getInsuranceProvider());
        }
        if (request.getInsuranceNumber() != null) {
            patient.setInsuranceNumber(request.getInsuranceNumber());
        }
        if (request.getEmergencyContactName() != null) {
            patient.setEmergencyContactName(request.getEmergencyContactName());
        }
        if (request.getEmergencyContactPhone() != null) {
            patient.setEmergencyContactPhone(request.getEmergencyContactPhone());
        }
        if (request.getEmergencyContactRelation() != null) {
            patient.setEmergencyContactRelation(request.getEmergencyContactRelation());
        }

        Patient updatedPatient = patientRepository.save(patient);
        log.info("Patient profile updated successfully");

        return mapToPatientResponse(updatedPatient, "Patient profile updated successfully");
    }

    @Transactional(readOnly = true)
    public EmergencyContactResponse getEmergencyContact(Long patientId) {
        log.info("Fetching emergency contact for patient ID: {}", patientId);

        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new PatientException("Patient not found with ID: " + patientId));

        return EmergencyContactResponse.builder()
                .name(patient.getEmergencyContactName())
                .phone(patient.getEmergencyContactPhone())
                .relation(patient.getEmergencyContactRelation())
                .build();
    }

    @Transactional
    public PatientResponse updateEmergencyContact(
            Long patientId,
            String name,
            String phone,
            String relation) {

        log.info("Updating emergency contact for patient ID: {}", patientId);

        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new PatientException("Patient not found with ID: " + patientId));

        if (name != null) {
            patient.setEmergencyContactName(name);
        }
        if (phone != null) {
            patient.setEmergencyContactPhone(phone);
        }
        if (relation != null) {
            patient.setEmergencyContactRelation(relation);
        }

        Patient updatedPatient = patientRepository.save(patient);
        log.info("Emergency contact updated successfully");

        return mapToPatientResponse(updatedPatient, "Emergency contact updated successfully");
    }

    @Transactional(readOnly = true)
    public List<PatientResponse> getPatientsWithAllergies() {
        log.info("Fetching patients with allergies");

        List<Patient> patients = patientRepository.findPatientsWithAllergies();
        return patients.stream()
                .map(patient -> mapToPatientResponse(patient, null))
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<PatientResponse> searchByChronicCondition(String condition) {
        log.info("Searching patients by chronic condition: {}", condition);

        List<Patient> patients = patientRepository.findByChronicConditionsContaining(condition);
        return patients.stream()
                .map(patient -> mapToPatientResponse(patient, null))
                .collect(Collectors.toList());
    }

    @Transactional
    public void deletePatient(Long patientId) {
        log.info("Deleting patient profile with ID: {}", patientId);

        if (!patientRepository.existsById(patientId)) {
            throw new PatientException("Patient not found with ID: " + patientId);
        }

        patientRepository.deleteById(patientId);
        log.info("Patient profile deleted successfully");
    }

    @Transactional(readOnly = true)
    public long getPatientCountByBloodGroup(BloodGroup bloodGroup) {
        return patientRepository.countByBloodGroup(bloodGroup);
    }

    // ============= HELPER METHODS =============

    // Fetch User Profile from Auth-Profile Service
    private Map<String, Object> fetchUserProfileFromAuthService(String userId, String authHeader) {
        try {
            var response = authServiceClient.getUserProfile(userId, authHeader);

            if (!response.getStatusCode().is2xxSuccessful() || response.getBody() == null) {
                throw new PatientException("Failed to fetch user profile from Auth-Profile Service");
            }

            return response.getBody();

        } catch (Exception e) {
            log.error("Error fetching user profile: {}", e.getMessage());
            throw new PatientException("Failed to fetch user profile: " + e.getMessage());
        }
    }

    // Fetch User Auth Data from Auth Service
    private Map<String, Object> fetchUserAuthFromAuthService(String userId, String authHeader) {
        try {
            var response = authServiceClient.getUserById(userId, authHeader);

            if (!response.getStatusCode().is2xxSuccessful() || response.getBody() == null) {
                throw new PatientException("Failed to fetch user auth data from Auth Service");
            }

            return response.getBody();

        } catch (Exception e) {
            log.error("Error fetching user auth data: {}", e.getMessage());
            throw new PatientException("Failed to fetch user auth data: " + e.getMessage());
        }
    }

    // Build Complete Patient Profile by combining all data sources

    private CompletePatientProfileResponse buildCompletePatientProfile(
            Patient patient,
            Map<String, Object> authData,
            Map<String, Object> profileData) {

        DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;

        // Calculate age from DOB
        Integer age = null;
        if (profileData.get("dob") != null) {
            try {
                LocalDate dob = LocalDate.parse(profileData.get("dob").toString());
                age = Period.between(dob, LocalDate.now()).getYears();
            } catch (Exception e) {
                log.warn("Failed to calculate age: {}", e.getMessage());
            }
        }

        return CompletePatientProfileResponse.builder()
                // Auth Service Data
                .userId(patient.getUserId())
                .email(getStringValue(authData, "email"))
                .username(getStringValue(authData, "username"))
                .role(getStringValue(authData, "role"))
                .userStatus(getStringValue(authData, "status"))
                .accountCreatedAt(getStringValue(authData, "createdAt"))

                // Profile Service Data
                .name(getStringValue(profileData, "name"))
                .gender(getStringValue(profileData, "gender"))
                .dob(profileData.get("dob") != null ? LocalDate.parse(profileData.get("dob").toString()) : null)
                .phone(getStringValue(profileData, "phone"))
                .address(getStringValue(profileData, "address"))
                .profilePicture(getStringValue(profileData, "profilePicture"))
                .profileStatus(getStringValue(profileData, "profileStatus"))
                .profileCreatedAt(getStringValue(profileData, "createdAt"))
                .profileUpdatedAt(getStringValue(profileData, "updatedAt"))

                // Patient Management Data
                .patientId(patient.getId())
                .bloodGroup(patient.getBloodGroup() != null ? patient.getBloodGroup().getDisplayName() : null)
                .allergies(patient.getAllergies())
                .chronicConditions(patient.getChronicConditions())
                .insuranceProvider(patient.getInsuranceProvider())
                .insuranceNumber(patient.getInsuranceNumber())
                .emergencyContactName(patient.getEmergencyContactName())
                .emergencyContactPhone(patient.getEmergencyContactPhone())
                .emergencyContactRelation(patient.getEmergencyContactRelation())
                .patientCreatedAt(patient.getCreatedAt().format(formatter))
                .patientUpdatedAt(patient.getUpdatedAt().format(formatter))

                // Computed Fields
                .age(age)
                .hasInsurance(patient.getInsuranceProvider() != null && !patient.getInsuranceProvider().isEmpty())
                .hasChronicConditions(patient.getChronicConditions() != null && !patient.getChronicConditions().isEmpty())
                .hasAllergies(patient.getAllergies() != null && !patient.getAllergies().isEmpty())

                .message("Complete patient profile fetched successfully")
                .build();
    }

    //Build Partial Profile when external services are unavailable

    private CompletePatientProfileResponse buildPartialProfile(Patient patient) {
        DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;

        return CompletePatientProfileResponse.builder()
                .userId(patient.getUserId())
                .patientId(patient.getId())
                .bloodGroup(patient.getBloodGroup() != null ? patient.getBloodGroup().getDisplayName() : null)
                .allergies(patient.getAllergies())
                .chronicConditions(patient.getChronicConditions())
                .insuranceProvider(patient.getInsuranceProvider())
                .insuranceNumber(patient.getInsuranceNumber())
                .emergencyContactName(patient.getEmergencyContactName())
                .emergencyContactPhone(patient.getEmergencyContactPhone())
                .emergencyContactRelation(patient.getEmergencyContactRelation())
                .patientCreatedAt(patient.getCreatedAt().format(formatter))
                .patientUpdatedAt(patient.getUpdatedAt().format(formatter))
                .hasInsurance(patient.getInsuranceProvider() != null)
                .hasChronicConditions(patient.getChronicConditions() != null)
                .hasAllergies(patient.getAllergies() != null)
                .message("Partial profile - some data unavailable")
                .build();
    }

    // Validate user exists in Auth Service
    private void validateUserExists(String userId, String authHeader) {
        try {
            var response = authServiceClient.getUserById(userId, authHeader);
            if (!response.getStatusCode().is2xxSuccessful()) {
                throw new PatientException("User not found in Auth Service");
            }
        } catch (Exception e) {
            log.error("Failed to validate user: {}", e.getMessage());
            throw new PatientException("Failed to validate user: " + e.getMessage());
        }
    }

    // Map Patient entity to PatientResponse DTO
    private PatientResponse mapToPatientResponse(Patient patient, String message) {
        DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;

        return PatientResponse.builder()
                .id(patient.getId())
                .userId(patient.getUserId())
                .bloodGroup(patient.getBloodGroup() != null ? patient.getBloodGroup().getDisplayName() : null)
                .allergies(patient.getAllergies())
                .chronicConditions(patient.getChronicConditions())
                .insuranceProvider(patient.getInsuranceProvider())
                .insuranceNumber(patient.getInsuranceNumber())
                .emergencyContactName(patient.getEmergencyContactName())
                .emergencyContactPhone(patient.getEmergencyContactPhone())
                .emergencyContactRelation(patient.getEmergencyContactRelation())
                .createdAt(patient.getCreatedAt().format(formatter))
                .updatedAt(patient.getUpdatedAt().format(formatter))
                .message(message)
                .build();
    }

    // Safely extract string value from map
    private String getStringValue(Map<String, Object> map, String key) {
        Object value = map.get(key);
        return value != null ? value.toString() : null;
    }
}