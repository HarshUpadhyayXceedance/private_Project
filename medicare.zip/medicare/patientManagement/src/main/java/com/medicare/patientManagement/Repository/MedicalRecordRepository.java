package com.medicare.patientManagement.Repository;

import com.medicare.patientManagement.Entity.MedicalRecord;
import com.medicare.patientManagement.Enums.RecordType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface MedicalRecordRepository extends JpaRepository<MedicalRecord, Long> {


    Page<MedicalRecord> findByPatientId(Long patientId, Pageable pageable);


    @Query("SELECT m FROM MedicalRecord m WHERE m.patientId = :patientId " +
            "AND m.visitDate BETWEEN :startDate AND :endDate " +
            "ORDER BY m.visitDate DESC")
    List<MedicalRecord> findByPatientIdAndDateRange(
            @Param("patientId") Long patientId,
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate
    );


    List<MedicalRecord> findByPatientIdAndRecordType(Long patientId, RecordType recordType);


    @Query("SELECT m FROM MedicalRecord m WHERE m.patientId = :patientId " +
            "ORDER BY m.visitDate DESC, m.createdAt DESC")
    List<MedicalRecord> findRecentRecordsByPatientId(
            @Param("patientId") Long patientId,
            Pageable pageable
    );

    Page<MedicalRecord> findByDoctorId(String doctorId, Pageable pageable);


    long countByPatientId(Long patientId);


    List<MedicalRecord> findByPrescriptionId(Long prescriptionId);


    @Query("SELECT m FROM MedicalRecord m WHERE m.patientId = :patientId " +
            "ORDER BY m.visitDate DESC, m.createdAt DESC LIMIT 1")
    MedicalRecord findLatestRecordByPatientId(@Param("patientId") Long patientId);
}
