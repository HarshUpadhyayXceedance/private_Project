package com.medicare.patientManagement.Service;

import com.medicare.patientManagement.Dto.CreateMedicalRecordRequest;
import com.medicare.patientManagement.Dto.MedicalRecordResponse;
import com.medicare.patientManagement.Dto.UpdateMedicalRecordRequest;
import com.medicare.patientManagement.Entity.MedicalRecord;
import com.medicare.patientManagement.Enums.RecordType;
import com.medicare.patientManagement.Exception.PatientException;
import com.medicare.patientManagement.Repository.MedicalRecordRepository;
import com.medicare.patientManagement.Repository.PatientRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class MedicalRecordService {

    private final MedicalRecordRepository medicalRecordRepository;
    private final PatientRepository patientRepository;

    /**
     * Create new medical record
     */
    @Transactional
    public MedicalRecordResponse createMedicalRecord(CreateMedicalRecordRequest request) {
        log.info("Creating medical record for patient ID: {}", request.getPatientId());

        // Validate patient exists
        if (!patientRepository.existsById(request.getPatientId())) {
            throw new PatientException("Patient not found with ID: " + request.getPatientId());
        }

        // Create medical record
        MedicalRecord record = MedicalRecord.builder()
                .patientId(request.getPatientId())
                .visitDate(request.getVisitDate())
                .diagnosis(request.getDiagnosis())
                .symptoms(request.getSymptoms())
                .treatment(request.getTreatment())
                .prescriptionId(request.getPrescriptionId())
                .doctorId(request.getDoctorId())
                .notes(request.getNotes())
                .recordType(request.getRecordType())
                .build();

        MedicalRecord savedRecord = medicalRecordRepository.save(record);
        log.info("Medical record created successfully with ID: {}", savedRecord.getId());

        return mapToMedicalRecordResponse(savedRecord);
    }

    /**
     * Get medical record by ID
     */
    @Transactional(readOnly = true)
    public MedicalRecordResponse getMedicalRecordById(Long recordId) {
        log.info("Fetching medical record by ID: {}", recordId);

        MedicalRecord record = medicalRecordRepository.findById(recordId)
                .orElseThrow(() -> new PatientException("Medical record not found with ID: " + recordId));

        return mapToMedicalRecordResponse(record);
    }

    /**
     * Get all medical records for a patient
     */
    @Transactional(readOnly = true)
    public Page<MedicalRecordResponse> getMedicalRecordsByPatientId(Long patientId, Pageable pageable) {
        log.info("Fetching medical records for patient ID: {}", patientId);

        // Validate patient exists
        if (!patientRepository.existsById(patientId)) {
            throw new PatientException("Patient not found with ID: " + patientId);
        }

        Page<MedicalRecord> records = medicalRecordRepository.findByPatientId(patientId, pageable);
        return records.map(this::mapToMedicalRecordResponse);
    }

    /**
     * Get medical records by date range
     */
    @Transactional(readOnly = true)
    public List<MedicalRecordResponse> getMedicalRecordsByDateRange(
            Long patientId,
            LocalDate startDate,
            LocalDate endDate) {

        log.info("Fetching medical records for patient {} between {} and {}",
                patientId, startDate, endDate);

        List<MedicalRecord> records = medicalRecordRepository
                .findByPatientIdAndDateRange(patientId, startDate, endDate);

        return records.stream()
                .map(this::mapToMedicalRecordResponse)
                .collect(Collectors.toList());
    }

    /**
     * Get recent medical records
     */
    @Transactional(readOnly = true)
    public List<MedicalRecordResponse> getRecentMedicalRecords(Long patientId, int limit) {
        log.info("Fetching recent {} medical records for patient ID: {}", limit, patientId);

        Pageable pageable = PageRequest.of(0, limit);
        List<MedicalRecord> records = medicalRecordRepository
                .findRecentRecordsByPatientId(patientId, pageable);

        return records.stream()
                .map(this::mapToMedicalRecordResponse)
                .collect(Collectors.toList());
    }

    /**
     * Get medical records by record type
     */
    @Transactional(readOnly = true)
    public List<MedicalRecordResponse> getMedicalRecordsByType(Long patientId, RecordType recordType) {
        log.info("Fetching {} records for patient ID: {}", recordType, patientId);

        List<MedicalRecord> records = medicalRecordRepository
                .findByPatientIdAndRecordType(patientId, recordType);

        return records.stream()
                .map(this::mapToMedicalRecordResponse)
                .collect(Collectors.toList());
    }

    /**
     * Get medical records by doctor
     */
    @Transactional(readOnly = true)
    public Page<MedicalRecordResponse> getMedicalRecordsByDoctor(String doctorId, Pageable pageable) {
        log.info("Fetching medical records for doctor ID: {}", doctorId);

        Page<MedicalRecord> records = medicalRecordRepository.findByDoctorId(doctorId, pageable);
        return records.map(this::mapToMedicalRecordResponse);
    }

    /**
     * Update medical record
     */
    @Transactional
    public MedicalRecordResponse updateMedicalRecord(Long recordId, UpdateMedicalRecordRequest request) {
        log.info("Updating medical record ID: {}", recordId);

        MedicalRecord record = medicalRecordRepository.findById(recordId)
                .orElseThrow(() -> new PatientException("Medical record not found with ID: " + recordId));

        // Update only non-null fields
        if (request.getDiagnosis() != null) {
            record.setDiagnosis(request.getDiagnosis());
        }
        if (request.getSymptoms() != null) {
            record.setSymptoms(request.getSymptoms());
        }
        if (request.getTreatment() != null) {
            record.setTreatment(request.getTreatment());
        }
        if (request.getPrescriptionId() != null) {
            record.setPrescriptionId(request.getPrescriptionId());
        }
        if (request.getNotes() != null) {
            record.setNotes(request.getNotes());
        }
        if (request.getRecordType() != null) {
            record.setRecordType(request.getRecordType());
        }

        MedicalRecord updatedRecord = medicalRecordRepository.save(record);
        log.info("Medical record updated successfully");

        return mapToMedicalRecordResponse(updatedRecord);
    }

    /**
     * Delete medical record
     */
    @Transactional
    public void deleteMedicalRecord(Long recordId) {
        log.info("Deleting medical record ID: {}", recordId);

        if (!medicalRecordRepository.existsById(recordId)) {
            throw new PatientException("Medical record not found with ID: " + recordId);
        }

        medicalRecordRepository.deleteById(recordId);
        log.info("Medical record deleted successfully");
    }

    /**
     * Get latest medical record for patient
     */
    @Transactional(readOnly = true)
    public MedicalRecordResponse getLatestMedicalRecord(Long patientId) {
        log.info("Fetching latest medical record for patient ID: {}", patientId);

        MedicalRecord record = medicalRecordRepository.findLatestRecordByPatientId(patientId);
        if (record == null) {
            throw new PatientException("No medical records found for patient ID: " + patientId);
        }

        return mapToMedicalRecordResponse(record);
    }

    /**
     * Count medical records for patient
     */
    @Transactional(readOnly = true)
    public long countMedicalRecords(Long patientId) {
        return medicalRecordRepository.countByPatientId(patientId);
    }

    // ============= HELPER METHODS =============

    /**
     * Map MedicalRecord entity to MedicalRecordResponse DTO
     */
    private MedicalRecordResponse mapToMedicalRecordResponse(MedicalRecord record) {
        DateTimeFormatter dateFormatter = DateTimeFormatter.ISO_DATE;
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ISO_DATE_TIME;

        return MedicalRecordResponse.builder()
                .id(record.getId())
                .patientId(record.getPatientId())
                .visitDate(record.getVisitDate().format(dateFormatter))
                .diagnosis(record.getDiagnosis())
                .symptoms(record.getSymptoms())
                .treatment(record.getTreatment())
                .prescriptionId(record.getPrescriptionId())
                .doctorId(record.getDoctorId())
                .notes(record.getNotes())
                .recordType(record.getRecordType().name())
                .createdAt(record.getCreatedAt().format(dateTimeFormatter))
                .updatedAt(record.getUpdatedAt().format(dateTimeFormatter))
                .build();
    }
}