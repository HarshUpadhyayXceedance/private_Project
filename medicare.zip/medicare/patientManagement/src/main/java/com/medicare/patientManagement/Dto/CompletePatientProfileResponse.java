package com.medicare.patientManagement.Dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CompletePatientProfileResponse {

    //"userId": "3cccbe0f-9639-4aba-9be2-47561fd32fbd",
    //"email": "john.doe@example.com",
    //"username": "johndoe123",
    //"role": "PATIENT",
    //"userStatus": "ACTIVE",
    //"accountCreatedAt": "2025-10-14T10:36:40.124969",
    private String userId;
    private String email;
    private String username;
    private String role;
    private String userStatus;
    private String accountCreatedAt;

    //'name": "John Doe",
    //"gender": "MALE",
    //"dob": "1990-05-15",
    //"phone": "9876543210",
    //"address": "123 Main Street, Apartment 4B, Mumbai, Maharashtra, 400001",
    //"profilePicture": "https://example.com/profile-photos/johndoe.jpg",
    //"profileStatus": "APPROVED",
    private String name;
    private String gender;
    private LocalDate dob;
    private String phone;
    private String address;
    private String profilePicture;
    private String profileStatus;

//        "patientId": 1,
//        "bloodGroup": "O+",
//        "allergies": "Penicillin, Peanuts, Dust",
//        "chronicConditions": "Type 2 Diabetes, Hypertension",
//        "insuranceProvider": "Star Health Insurance",
//        "insuranceNumber": "STAR-2024-123456",
//        "emergencyContactName": "Jane Doe",
//        "emergencyContactPhone": "9876543210",
//        "emergencyContactRelation": "Spouse",
    private Long patientId;
    private String bloodGroup;
    private String allergies;
    private String chronicConditions;
    private String insuranceProvider;
    private String insuranceNumber;
    private String emergencyContactName;
    private String emergencyContactPhone;
    private String emergencyContactRelation;

//        "profileCreatedAt": "2025-10-14T10:38:27.349876",
//        "profileUpdatedAt": "2025-10-14T10:38:27.349895",
//        "patientCreatedAt": "2025-10-14T11:34:54.428072",
//        "patientUpdatedAt": "2025-10-14T11:34:54.428117",
//        "message": "Complete patient profile fetched successfully",
    private String profileCreatedAt;
    private String profileUpdatedAt;
    private String patientCreatedAt;
    private String patientUpdatedAt;
    private String message;

//        "age": 35,
//        "hasInsurance": true,
//        "hasChronicConditions": true,
//        "hasAllergies": true
    private Integer age;
    private Boolean hasInsurance;
    private Boolean hasChronicConditions;
    private Boolean hasAllergies;
}






