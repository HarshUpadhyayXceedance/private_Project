package com.medicare.patientManagement.Controller;

import com.medicare.patientManagement.Dto.*;
import com.medicare.patientManagement.Enums.BloodGroup;
import com.medicare.patientManagement.Service.PatientService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/patients")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "*", maxAge = 3600)
public class PatientController {
    @Autowired
    private final PatientService patientService;

    // Get Complete Patient Profile by User ID
    @GetMapping("/complete/user/{userId}")
    @PreAuthorize("hasAnyRole('PATIENT', 'EMPLOYEE', 'ADMIN')")
    public ResponseEntity<CompletePatientProfileResponse> getCompletePatientProfile(@PathVariable String userId,
                     @RequestHeader("Authorization") String authHeader, Authentication authentication) {

        log.info("GET /patients/complete/user/{} - Get complete patient profile", userId);

        String authenticatedUserId = authentication.getName();
        boolean isEmployeeOrAdmin = authentication.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_EMPLOYEE") ||
                        auth.getAuthority().equals("ROLE_ADMIN"));

        if (!isEmployeeOrAdmin && !authenticatedUserId.equals(userId)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        CompletePatientProfileResponse response =
                patientService.getCompletePatientProfile(userId, authHeader);
        return ResponseEntity.ok(response);
    }

    // Get Complete Patient Profile by Patient ID
    @GetMapping("/complete/{patientId}")
    @PreAuthorize("hasAnyRole('EMPLOYEE', 'ADMIN')")
    public ResponseEntity<CompletePatientProfileResponse> getCompletePatientProfileById(
            @PathVariable Long patientId, @RequestHeader("Authorization") String authHeader) {

        log.info("GET /patients/complete/{} - Get complete patient profile by ID", patientId);

        CompletePatientProfileResponse response =
                patientService.getCompletePatientProfileById(patientId, authHeader);
        return ResponseEntity.ok(response);
    }

    // Get All Complete Patient Profiles (Employee/Admin only)
    @GetMapping("/complete")
    @PreAuthorize("hasAnyRole('EMPLOYEE', 'ADMIN')")
    public ResponseEntity<Page<CompletePatientProfileResponse>> getAllCompletePatientProfiles(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestHeader("Authorization") String authHeader) {

        log.info("GET /patients/complete - Get all complete patient profiles");

        Pageable pageable = PageRequest.of(page, size);
        Page<CompletePatientProfileResponse> patients =
                patientService.getAllCompletePatientProfiles(pageable, authHeader);
        return ResponseEntity.ok(patients);
    }

    // Get Current User's Complete Profile (Shortcut endpoint)
    @GetMapping("/complete/me")
    @PreAuthorize("hasRole('PATIENT')")
    public ResponseEntity<CompletePatientProfileResponse> getMyCompleteProfile(
            @RequestHeader("Authorization") String authHeader,
            Authentication authentication) {

        String authenticatedUserId = authentication.getName();
        log.info("GET /patients/complete/me - Get complete profile for current user: {}", authenticatedUserId);

        CompletePatientProfileResponse response =
                patientService.getCompletePatientProfile(authenticatedUserId, authHeader);
        return ResponseEntity.ok(response);
    }

    // Create a new Patient record
    @PostMapping
    @PreAuthorize("hasAnyRole('PATIENT', 'ADMIN')")
    public ResponseEntity<PatientResponse> createPatient(
            @Valid @RequestBody CreatePatientRequest request,
            @RequestHeader("Authorization") String authHeader,
            Authentication authentication) {

        log.info("POST /patients - Patient creation request for userId: {}", request.getUserId());

        String authenticatedUserId = authentication.getName();
        boolean isAdmin = authentication.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN"));

        if (!isAdmin && !authenticatedUserId.equals(request.getUserId())) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        PatientResponse response = patientService.createPatient(request, authHeader);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    // Get Patient by Patient ID
    @GetMapping("/{patientId}")
    @PreAuthorize("hasAnyRole('EMPLOYEE', 'ADMIN')")
    public ResponseEntity<PatientResponse> getPatientById(@PathVariable Long patientId) {

        log.info("GET /patients/{} - Fetching patient by ID", patientId);

        PatientResponse response = patientService.getPatientById(patientId);
        return ResponseEntity.ok(response);
    }

    // Get Patient by User ID
    @GetMapping("/user/{userId}")
    @PreAuthorize("hasAnyRole('PATIENT', 'EMPLOYEE', 'ADMIN')")
    public ResponseEntity<PatientResponse> getPatientByUserId(
            @PathVariable String userId,
            Authentication authentication) {

        log.info("GET /patients/user/{} - Fetching patient by userId", userId);

        String authenticatedUserId = authentication.getName();
        boolean isEmployeeOrAdmin = authentication.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_EMPLOYEE") ||
                        auth.getAuthority().equals("ROLE_ADMIN"));

        if (!isEmployeeOrAdmin && !authenticatedUserId.equals(userId)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        PatientResponse response = patientService.getPatientByUserId(userId);
        return ResponseEntity.ok(response);
    }

    // Get All Patients (Paginated)
    @GetMapping
    @PreAuthorize("hasAnyRole('EMPLOYEE', 'ADMIN')")
    public ResponseEntity<Page<PatientResponse>> getAllPatients(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        log.info("GET /patients - Fetching all patients - Page: {}, Size: {}", page, size);

        Pageable pageable = PageRequest.of(page, size);
        Page<PatientResponse> patients = patientService.getAllPatients(pageable);
        return ResponseEntity.ok(patients);
    }

    // Get Patients by Blood Group
    @GetMapping("/blood-group/{bloodGroup}")
    @PreAuthorize("hasAnyRole('EMPLOYEE', 'ADMIN')")
    public ResponseEntity<List<PatientResponse>> getPatientsByBloodGroup(
            @PathVariable BloodGroup bloodGroup) {

        log.info("GET /patients/blood-group/{} - Fetching patients by blood group", bloodGroup);

        List<PatientResponse> patients = patientService.getPatientsByBloodGroup(bloodGroup);
        return ResponseEntity.ok(patients);
    }

    // Update Patient Profile
    @PatchMapping("/{patientId}")
    @PreAuthorize("hasAnyRole('PATIENT', 'ADMIN')")
    public ResponseEntity<PatientResponse> updatePatient(
            @PathVariable Long patientId,
            @Valid @RequestBody UpdatePatientRequest request,
            Authentication authentication) {

        log.info("PATCH /patients/{} - Updating patient profile", patientId);

        PatientResponse patient = patientService.getPatientById(patientId);
        String authenticatedUserId = authentication.getName();
        boolean isAdmin = authentication.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN"));

        if (!isAdmin && !authenticatedUserId.equals(patient.getUserId())) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        PatientResponse response = patientService.updatePatient(patientId, request);
        return ResponseEntity.ok(response);
    }

    // Get Patient's Emergency Contact
    @GetMapping("/{patientId}/emergency-contact")
    @PreAuthorize("hasAnyRole('EMPLOYEE', 'ADMIN')")
    public ResponseEntity<EmergencyContactResponse> getEmergencyContact(
            @PathVariable Long patientId) {

        log.info("GET /patients/{}/emergency-contact - Fetching emergency contact", patientId);

        EmergencyContactResponse response = patientService.getEmergencyContact(patientId);
        return ResponseEntity.ok(response);
    }

    // Update Patient's Emergency Contact
    @PatchMapping("/{patientId}/emergency-contact")
    @PreAuthorize("hasAnyRole('PATIENT', 'ADMIN')")
    public ResponseEntity<PatientResponse> updateEmergencyContact(
            @PathVariable Long patientId,
            @RequestBody Map<String, String> request,
            Authentication authentication) {

        log.info("PATCH /patients/{}/emergency-contact - Updating emergency contact", patientId);

        PatientResponse patient = patientService.getPatientById(patientId);
        String authenticatedUserId = authentication.getName();
        boolean isAdmin = authentication.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN"));

        if (!isAdmin && !authenticatedUserId.equals(patient.getUserId())) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        PatientResponse response = patientService.updateEmergencyContact(
                patientId,
                request.get("emergencyContactName"),
                request.get("emergencyContactPhone"),
                request.get("emergencyContactRelation")
        );

        return ResponseEntity.ok(response);
    }

    // Delete Patient Record
    @DeleteMapping("/{patientId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deletePatient(@PathVariable Long patientId) {

        log.info("DELETE /patients/{} - Deleting patient", patientId);

        patientService.deletePatient(patientId);
        return ResponseEntity.noContent().build();
    }

    // Health Check Endpoint
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of(
                "status", "UP",
                "service", "patient-management-service"
        ));
    }
}