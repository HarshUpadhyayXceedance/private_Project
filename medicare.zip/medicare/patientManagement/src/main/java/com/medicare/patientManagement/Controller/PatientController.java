package com.medicare.patientManagement.Controller;

import com.medicare.patientManagement.Dto.CreatePatientRequest;
import com.medicare.patientManagement.Dto.EmergencyContactResponse;
import com.medicare.patientManagement.Dto.PatientResponse;
import com.medicare.patientManagement.Dto.UpdatePatientRequest;
import com.medicare.patientManagement.Enums.BloodGroup;
import com.medicare.patientManagement.Service.PatientService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/patients")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "*", maxAge = 3600)
public class PatientController {

    private final PatientService patientService;


    @PostMapping
    @PreAuthorize("hasAnyRole('PATIENT', 'ADMIN')")
    public ResponseEntity<PatientResponse> createPatient(
            @Valid @RequestBody CreatePatientRequest request,
            @RequestHeader("Authorization") String authHeader,
            Authentication authentication) {

        log.info("Patient creation request for userId: {}", request.getUserId());

        // Verify user is creating their own profile (unless admin)
        String authenticatedUserId = authentication.getName();
        boolean isAdmin = authentication.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN"));

        if (!isAdmin && !authenticatedUserId.equals(request.getUserId())) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        PatientResponse response = patientService.createPatient(request, authHeader);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/{patientId}")
    @PreAuthorize("hasAnyRole('DOCTOR', 'ADMIN')")
    public ResponseEntity<PatientResponse> getPatientById(@PathVariable Long patientId) {
        log.info("Fetching patient by ID: {}", patientId);
        PatientResponse response = patientService.getPatientById(patientId);
        return ResponseEntity.ok(response);
    }


    @GetMapping("/user/{userId}")
    @PreAuthorize("hasAnyRole('PATIENT', 'DOCTOR', 'ADMIN')")
    public ResponseEntity<PatientResponse> getPatientByUserId(
            @PathVariable String userId,
            Authentication authentication) {

        log.info("Fetching patient by userId: {}", userId);

        // Users can only access their own data unless doctor/admin
        String authenticatedUserId = authentication.getName();
        boolean isDoctorOrAdmin = authentication.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_DOCTOR") ||
                        auth.getAuthority().equals("ROLE_ADMIN"));

        if (!isDoctorOrAdmin && !authenticatedUserId.equals(userId)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        PatientResponse response = patientService.getPatientByUserId(userId);
        return ResponseEntity.ok(response);
    }


    @GetMapping
    @PreAuthorize("hasAnyRole('DOCTOR', 'ADMIN')")
    public ResponseEntity<Page<PatientResponse>> getAllPatients(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        log.info("Fetching all patients - Page: {}, Size: {}", page, size);
        Pageable pageable = PageRequest.of(page, size);
        Page<PatientResponse> patients = patientService.getAllPatients(pageable);
        return ResponseEntity.ok(patients);
    }


    @GetMapping("/blood-group/{bloodGroup}")
    @PreAuthorize("hasAnyRole('DOCTOR', 'ADMIN')")
    public ResponseEntity<List<PatientResponse>> getPatientsByBloodGroup(
            @PathVariable BloodGroup bloodGroup) {

        log.info("Fetching patients by blood group: {}", bloodGroup);
        List<PatientResponse> patients = patientService.getPatientsByBloodGroup(bloodGroup);
        return ResponseEntity.ok(patients);
    }


    @PatchMapping("/{patientId}")
    @PreAuthorize("hasAnyRole('PATIENT', 'ADMIN')")
    public ResponseEntity<PatientResponse> updatePatient(
            @PathVariable Long patientId,
            @Valid @RequestBody UpdatePatientRequest request,
            Authentication authentication) {

        log.info("Updating patient profile for ID: {}", patientId);

        // Get patient to verify ownership
        PatientResponse patient = patientService.getPatientById(patientId);
        String authenticatedUserId = authentication.getName();
        boolean isAdmin = authentication.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN"));

        if (!isAdmin && !authenticatedUserId.equals(patient.getUserId())) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        PatientResponse response = patientService.updatePatient(patientId, request);
        return ResponseEntity.ok(response);
    }


    @GetMapping("/{patientId}/emergency-contact")
    @PreAuthorize("hasAnyRole('DOCTOR', 'ADMIN')")
    public ResponseEntity<EmergencyContactResponse> getEmergencyContact(
            @PathVariable Long patientId) {

        log.info("Fetching emergency contact for patient ID: {}", patientId);
        EmergencyContactResponse response = patientService.getEmergencyContact(patientId);
        return ResponseEntity.ok(response);
    }


    @PatchMapping("/{patientId}/emergency-contact")
    @PreAuthorize("hasAnyRole('PATIENT', 'ADMIN')")
    public ResponseEntity<PatientResponse> updateEmergencyContact(
            @PathVariable Long patientId,
            @RequestBody Map<String, String> request,
            Authentication authentication) {

        log.info("Updating emergency contact for patient ID: {}", patientId);

        // Verify ownership
        PatientResponse patient = patientService.getPatientById(patientId);
        String authenticatedUserId = authentication.getName();
        boolean isAdmin = authentication.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN"));

        if (!isAdmin && !authenticatedUserId.equals(patient.getUserId())) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        PatientResponse response = patientService.updateEmergencyContact(
                patientId,
                request.get("emergencyContactName"),
                request.get("emergencyContactPhone"),
                request.get("emergencyContactRelation")
        );
        return ResponseEntity.ok(response);
    }


    @DeleteMapping("/{patientId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deletePatient(@PathVariable Long patientId) {
        log.info("Deleting patient ID: {}", patientId);
        patientService.deletePatient(patientId);
        return ResponseEntity.noContent().build();
    }


    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of(
                "status", "UP",
                "service", "patient-management-service"
        ));
    }
}

