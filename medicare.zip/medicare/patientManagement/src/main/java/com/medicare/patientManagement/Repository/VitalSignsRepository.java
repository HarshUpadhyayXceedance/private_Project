package com.medicare.patientManagement.Repository;

import com.medicare.patientManagement.Entity.VitalSigns;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;


@Repository
public interface VitalSignsRepository extends JpaRepository<VitalSigns, Long> {


    Page<VitalSigns> findByPatientId(Long patientId, Pageable pageable);


    @Query("SELECT v FROM VitalSigns v WHERE v.patientId = :patientId " +
            "AND v.recordedDate BETWEEN :startDate AND :endDate " +
            "ORDER BY v.recordedDate DESC")
    List<VitalSigns> findByPatientIdAndDateRange(
            @Param("patientId") Long patientId,
            @Param("startDate") LocalDateTime startDate,
            @Param("endDate") LocalDateTime endDate
    );


    @Query("SELECT v FROM VitalSigns v WHERE v.patientId = :patientId " +
            "ORDER BY v.recordedDate DESC LIMIT 1")
    Optional<VitalSigns> findLatestByPatientId(@Param("patientId") Long patientId);


    long countByPatientId(Long patientId);

    List<VitalSigns> findByRecordedBy(String recordedBy);
}
