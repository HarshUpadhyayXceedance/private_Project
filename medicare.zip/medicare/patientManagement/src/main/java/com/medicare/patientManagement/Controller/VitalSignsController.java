package com.medicare.patientManagement.Controller;

import com.medicare.patientManagement.Dto.CreateVitalSignsRequest;
import com.medicare.patientManagement.Dto.VitalSignsResponse;
import com.medicare.patientManagement.Service.VitalSignsService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.List;


@RestController
@RequestMapping("/patients/{patientId}/vital-signs")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "*", maxAge = 3600)
public class VitalSignsController {

    private final VitalSignsService vitalSignsService;


    @PostMapping
    @PreAuthorize("hasAnyRole('DOCTOR', 'ADMIN')")
    public ResponseEntity<VitalSignsResponse> recordVitalSigns(
            @PathVariable Long patientId,
            @Valid @RequestBody CreateVitalSignsRequest request) {

        log.info("Recording vital signs for patient ID: {}", patientId);

        // Ensure patientId in path matches patientId in request
        request.setPatientId(patientId);

        VitalSignsResponse response = vitalSignsService.recordVitalSigns(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }


    @GetMapping
    @PreAuthorize("hasAnyRole('PATIENT', 'DOCTOR', 'ADMIN')")
    public ResponseEntity<Page<VitalSignsResponse>> getVitalSigns(
            @PathVariable Long patientId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        log.info("Fetching vital signs for patient ID: {}", patientId);
        Pageable pageable = PageRequest.of(page, size);
        Page<VitalSignsResponse> vitalSigns = vitalSignsService.getVitalSignsByPatientId(patientId, pageable);
        return ResponseEntity.ok(vitalSigns);
    }


    @GetMapping("/date-range")
    @PreAuthorize("hasAnyRole('PATIENT', 'DOCTOR', 'ADMIN')")
    public ResponseEntity<List<VitalSignsResponse>> getVitalSignsByDateRange(
            @PathVariable Long patientId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate) {

        log.info("Fetching vital signs between {} and {}", startDate, endDate);
        List<VitalSignsResponse> vitalSigns = vitalSignsService
                .getVitalSignsByDateRange(patientId, startDate, endDate);
        return ResponseEntity.ok(vitalSigns);
    }


    @GetMapping("/latest")
    @PreAuthorize("hasAnyRole('PATIENT', 'DOCTOR', 'ADMIN')")
    public ResponseEntity<VitalSignsResponse> getLatestVitalSigns(@PathVariable Long patientId) {
        log.info("Fetching latest vital signs for patient ID: {}", patientId);
        VitalSignsResponse response = vitalSignsService.getLatestVitalSigns(patientId);
        return ResponseEntity.ok(response);
    }


    @GetMapping("/{vitalSignsId}")
    @PreAuthorize("hasAnyRole('PATIENT', 'DOCTOR', 'ADMIN')")
    public ResponseEntity<VitalSignsResponse> getVitalSignsById(
            @PathVariable Long patientId,
            @PathVariable Long vitalSignsId) {

        log.info("Fetching vital signs ID: {}", vitalSignsId);
        VitalSignsResponse response = vitalSignsService.getVitalSignsById(vitalSignsId);
        return ResponseEntity.ok(response);
    }


    @DeleteMapping("/{vitalSignsId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deleteVitalSigns(
            @PathVariable Long patientId,
            @PathVariable Long vitalSignsId) {

        log.info("Deleting vital signs ID: {}", vitalSignsId);
        vitalSignsService.deleteVitalSigns(vitalSignsId);
        return ResponseEntity.noContent().build();
    }
}