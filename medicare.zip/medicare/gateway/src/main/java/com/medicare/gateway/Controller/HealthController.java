package com.medicare.gateway.Controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/health")
@Slf4j
public class HealthController {

    @GetMapping
    public ResponseEntity<Map<String, Object>> health() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "UP");
        response.put("service", "API Gateway");
        response.put("timestamp", LocalDateTime.now().toString());
        response.put("message", "Gateway is running successfully");

        return ResponseEntity.ok(response);
    }

    @GetMapping("/routes")
    public ResponseEntity<Map<String, Object>> getRoutes() {
        Map<String, Object> response = new HashMap<>();
        response.put("routes", Map.of(
                "auth-profile", "/api/auth-profile/**",
                "doctor-management", "/api/doctor-management/**",
                "patient-management", "/api/patient-management/**",
                "appointments", "/api/appointments/**",
                "billing", "/api/billing/**",
                "prescriptions", "/api/prescriptions/**",
                "pharmacy", "/api/pharmacy/**"
        ));
        response.put("timestamp", LocalDateTime.now().toString());

        return ResponseEntity.ok(response);
    }
}