package com.medicare.gateway.Config;


import com.medicare.gateway.Filter.AuthenticationFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GatewayRouteConfig {

    @Autowired
    private AuthenticationFilter authenticationFilter;

    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
        return builder.routes()
                // Auth-Profile Service Routes (Public)
                .route("auth-profile-public", r -> r
                        .path("/api/auth-profile/auth/register",
                                "/api/auth-profile/auth/login",
                                "/api/auth-profile/auth/health")
                        .uri("lb://AUTH-PROFILE-SERVICE"))

                // Auth-Profile Service Routes (Protected)
                .route("auth-profile-protected", r -> r
                        .path("/api/auth-profile/**")
                        .filters(f -> f.filter(authenticationFilter.apply(new AuthenticationFilter.Config())))
                        .uri("lb://AUTH-PROFILE-SERVICE"))

                // Doctor Management Service Routes
                .route("doctor-management", r -> r
                        .path("/api/doctor-management/**")
                        .filters(f -> f.filter(authenticationFilter.apply(new AuthenticationFilter.Config())))
                        .uri("lb://DOCTOR-MANAGEMENT-SERVICE"))

                // Patient Management Service Routes
                .route("patient-management", r -> r
                        .path("/api/patient-management/**")
                        .filters(f -> f.filter(authenticationFilter.apply(new AuthenticationFilter.Config())))
                        .uri("lb://PATIENT-MANAGEMENT-SERVICE"))
                // Employee Common Service Routes
                .route("employee-commons-service", r -> r
                        .path("/api/employee-commons/**")
                        .filters(f -> f
                                .filter(authenticationFilter.apply(new AuthenticationFilter.Config())))
                        .uri("http://localhost:8084"))
                // Appointment Service Routes
                .route("appointment-service", r -> r
                        .path("/api/appointments/**")
                        .filters(f -> f.filter(authenticationFilter.apply(new AuthenticationFilter.Config())))
                        .uri("lb://APPOINTMENT-SERVICE"))

                // Billing Service Routes
                .route("billing-service", r -> r
                        .path("/api/billing/**")
                        .filters(f -> f.filter(authenticationFilter.apply(new AuthenticationFilter.Config())))
                        .uri("lb://BILLING-SERVICE"))

                // Prescription Service Routes
                .route("prescription-service", r -> r
                        .path("/api/prescriptions/**")
                        .filters(f -> f.filter(authenticationFilter.apply(new AuthenticationFilter.Config())))
                        .uri("lb://PRESCRIPTION-SERVICE"))

                // Pharmacy Service Routes
                .route("pharmacy-service", r -> r
                        .path("/api/pharmacy/**")
                        .filters(f -> f.filter(authenticationFilter.apply(new AuthenticationFilter.Config())))
                        .uri("lb://PHARMACY-SERVICE"))

                .build();
    }
}