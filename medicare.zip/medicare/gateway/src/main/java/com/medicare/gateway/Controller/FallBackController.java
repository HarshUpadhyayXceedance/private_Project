package com.medicare.gateway.Controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/fallback")
@Slf4j
public class FallBackController {

    @GetMapping("/auth-profile")
    public ResponseEntity<Map<String, Object>> authProfileFallback() {
        log.error("Auth-Profile Service is currently unavailable");
        return buildFallbackResponse("Auth-Profile Service", HttpStatus.SERVICE_UNAVAILABLE);
    }

    @GetMapping("/doctor-management")
    public ResponseEntity<Map<String, Object>> doctorManagementFallback() {
        log.error("Doctor Management Service is currently unavailable");
        return buildFallbackResponse("Doctor Management Service", HttpStatus.SERVICE_UNAVAILABLE);
    }

    @GetMapping("/patient-management")
    public ResponseEntity<Map<String, Object>> patientManagementFallback() {
        log.error("Patient Management Service is currently unavailable");
        return buildFallbackResponse("Patient Management Service", HttpStatus.SERVICE_UNAVAILABLE);
    }

    @GetMapping("/appointments")
    public ResponseEntity<Map<String, Object>> appointmentsFallback() {
        log.error("Appointment Service is currently unavailable");
        return buildFallbackResponse("Appointment Service", HttpStatus.SERVICE_UNAVAILABLE);
    }

    @GetMapping("/billing")
    public ResponseEntity<Map<String, Object>> billingFallback() {
        log.error("Billing Service is currently unavailable");
        return buildFallbackResponse("Billing Service", HttpStatus.SERVICE_UNAVAILABLE);
    }

    @GetMapping("/prescriptions")
    public ResponseEntity<Map<String, Object>> prescriptionsFallback() {
        log.error("Prescription Service is currently unavailable");
        return buildFallbackResponse("Prescription Service", HttpStatus.SERVICE_UNAVAILABLE);
    }

    @GetMapping("/pharmacy")
    public ResponseEntity<Map<String, Object>> pharmacyFallback() {
        log.error("Pharmacy Service is currently unavailable");
        return buildFallbackResponse("Pharmacy Service", HttpStatus.SERVICE_UNAVAILABLE);
    }

    private ResponseEntity<Map<String, Object>> buildFallbackResponse(String serviceName, HttpStatus status) {
        Map<String, Object> response = new HashMap<>();
        response.put("status", status.value());
        response.put("error", status.getReasonPhrase());
        response.put("message", serviceName + " is currently unavailable. Please try again later.");
        response.put("timestamp", LocalDateTime.now().toString());
        response.put("service", serviceName);

        return ResponseEntity.status(status).body(response);
    }
}