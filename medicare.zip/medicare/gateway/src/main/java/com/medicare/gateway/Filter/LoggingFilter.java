package com.medicare.gateway.Filter;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;

@Component
@Slf4j
public class LoggingFilter implements GlobalFilter, Ordered {

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();

        // Log request details
        log.info("========== Incoming Request ==========");
        log.info("Request ID: {}", request.getId());
        log.info("Method: {}", request.getMethod());
        log.info("Path: {}", request.getURI().getPath());
        log.info("Query Params: {}", request.getURI().getQuery());
        log.info("Remote Address: {}", request.getRemoteAddress());
        log.info("Time: {}", LocalDateTime.now());

        long startTime = System.currentTimeMillis();

        return chain.filter(exchange).then(Mono.fromRunnable(() -> {
            ServerHttpResponse response = exchange.getResponse();
            long endTime = System.currentTimeMillis();
            long duration = endTime - startTime;

            // Log response details
            log.info("========== Outgoing Response ==========");
            log.info("Request ID: {}", request.getId());
            log.info("Status Code: {}", response.getStatusCode());
            log.info("Duration: {} ms", duration);
            log.info("======================================");
        }));
    }

    @Override
    public int getOrder() {
        return Ordered.HIGHEST_PRECEDENCE;
    }
}
