package com.medicare.EmployeeCommonService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeCommonServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
