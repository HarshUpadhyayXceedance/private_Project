package com.medicare.EmployeeCommonService.Dto.Response;

import lombok.*;
import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeResponse {
    private Long id;
    private String userId;
    private String employeeCode;
    private String employeeType;

    private String departmentName;
    private Long departmentId;
    private String designation;
    private String joiningDate;
    private String employmentStatus;
    private BigDecimal salary;
    private Long reportingManagerId;
    private String reportingManagerName;

    // User profile data (from Auth-Profile service)
    private String name;
    private String email;
    private String phone;
    private String profilePicture;

    private String createdAt;
    private String updatedAt;
    private String message;
}

