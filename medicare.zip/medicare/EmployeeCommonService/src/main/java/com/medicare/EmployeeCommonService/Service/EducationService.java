package com.medicare.EmployeeCommonService.Service;


import com.medicare.EmployeeCommonService.Dto.Request.AddEducationRequest;
import com.medicare.EmployeeCommonService.Dto.Response.EducationResponse;
import com.medicare.EmployeeCommonService.Entity.Employee;
import com.medicare.EmployeeCommonService.Entity.EmployeeEducation;
import com.medicare.EmployeeCommonService.Exception.EmployeeException;
import com.medicare.EmployeeCommonService.Repository.EmployeeEducationRepository;
import com.medicare.EmployeeCommonService.Repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class EducationService {

    private final EmployeeEducationRepository educationRepository;
    private final EmployeeRepository employeeRepository;

    // ADD EDUCATION
    @Transactional
    public EducationResponse addEducation(String userId, AddEducationRequest request) {
        log.info("Adding education for userId: {}", userId);

        Employee employee = employeeRepository.findByUserId(userId)
                .orElseThrow(() -> new EmployeeException("Employee not found"));

        EmployeeEducation education = EmployeeEducation.builder()
                .employee(employee)
                .degree(request.getDegree())
                .institution(request.getInstitution())
                .yearOfPassing(request.getYearOfPassing())
                .fieldOfStudy(request.getFieldOfStudy())
                .gradeOrPercentage(request.getGradeOrPercentage())
                .build();

        EmployeeEducation savedEducation = educationRepository.save(education);
        log.info("Education added successfully");

        return mapToEducationResponse(savedEducation, "Education added successfully");
    }

    // GET EMPLOYEE EDUCATION RECORDS
    @Transactional(readOnly = true)
    public List<EducationResponse> getEducationRecords(String userId) {
        log.info("Fetching education records for userId: {}", userId);

        Employee employee = employeeRepository.findByUserId(userId)
                .orElseThrow(() -> new EmployeeException("Employee not found"));

        return educationRepository.findByEmployeeIdOrderByYearOfPassingDesc(employee.getId()).stream()
                .map(education -> mapToEducationResponse(education, null))
                .collect(Collectors.toList());
    }

    // ======================= DELETE EDUCATION =====================//
    @Transactional
    public void deleteEducation(String userId, Long educationId) {
        log.info("Deleting education: {} for userId: {}", educationId, userId);

        Employee employee = employeeRepository.findByUserId(userId)
                .orElseThrow(() -> new EmployeeException("Employee not found"));

        EmployeeEducation education = educationRepository.findById(educationId)
                .orElseThrow(() -> new EmployeeException("Education record not found"));

        if (!education.getEmployee().getId().equals(employee.getId())) {
            throw new EmployeeException("Cannot delete education record of another employee");
        }

        educationRepository.delete(education);
        log.info("Education deleted successfully");
    }

    //====================== HELPER METHOD ====================//
    private EducationResponse mapToEducationResponse(EmployeeEducation education, String message) {
        return EducationResponse.builder()
                .id(education.getId())
                .employeeId(education.getEmployee().getId())
                .degree(education.getDegree())
                .institution(education.getInstitution())
                .yearOfPassing(education.getYearOfPassing())
                .fieldOfStudy(education.getFieldOfStudy())
                .gradeOrPercentage(education.getGradeOrPercentage())
                .message(message)
                .build();
    }
}
