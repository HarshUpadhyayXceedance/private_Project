package com.medicare.EmployeeCommonService.Service;
import com.medicare.EmployeeCommonService.Dto.Request.AddExperienceRequest;
import com.medicare.EmployeeCommonService.Dto.Response.ExperienceResponse;
import com.medicare.EmployeeCommonService.Entity.Employee;
import com.medicare.EmployeeCommonService.Entity.EmployeeExperience;
import com.medicare.EmployeeCommonService.Exception.EmployeeException;
import com.medicare.EmployeeCommonService.Repository.EmployeeExperienceRepository;
import com.medicare.EmployeeCommonService.Repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ExperienceService {

    private final EmployeeExperienceRepository experienceRepository;
    private final EmployeeRepository employeeRepository;

    @Transactional
    public ExperienceResponse addExperience(String userId, AddExperienceRequest request) {
        log.info("Adding experience for userId: {}", userId);

        Employee employee = employeeRepository.findByUserId(userId)
                .orElseThrow(() -> new EmployeeException("Employee not found"));

        // Validate dates
        if (request.getEndDate() != null && request.getEndDate().isBefore(request.getStartDate())) {
            throw new EmployeeException("End date cannot be before start date");
        }

        EmployeeExperience experience = EmployeeExperience.builder()
                .employee(employee)
                .organization(request.getOrganization())
                .position(request.getPosition())
                .startDate(request.getStartDate())
                .endDate(request.getEndDate())
                .isCurrent(request.getIsCurrent() != null ? request.getIsCurrent() : false)
                .description(request.getDescription())
                .location(request.getLocation())
                .build();

        EmployeeExperience savedExperience = experienceRepository.save(experience);
        log.info("Experience added successfully");

        return mapToExperienceResponse(savedExperience, "Experience added successfully");
    }

    @Transactional(readOnly = true)
    public List<ExperienceResponse> getExperienceRecords(String userId) {
        log.info("Fetching experience records for userId: {}", userId);

        Employee employee = employeeRepository.findByUserId(userId)
                .orElseThrow(() -> new EmployeeException("Employee not found"));

        return experienceRepository.findByEmployeeIdOrderByStartDateDesc(employee.getId()).stream()
                .map(experience -> mapToExperienceResponse(experience, null))
                .collect(Collectors.toList());
    }

    @Transactional
    public void deleteExperience(String userId, Long experienceId) {
        log.info("Deleting experience: {} for userId: {}", experienceId, userId);

        Employee employee = employeeRepository.findByUserId(userId)
                .orElseThrow(() -> new EmployeeException("Employee not found"));

        EmployeeExperience experience = experienceRepository.findById(experienceId)
                .orElseThrow(() -> new EmployeeException("Experience record not found"));

        if (!experience.getEmployee().getId().equals(employee.getId())) {
            throw new EmployeeException("Cannot delete experience record of another employee");
        }

        experienceRepository.delete(experience);
        log.info("Experience deleted successfully");
    }

    private ExperienceResponse mapToExperienceResponse(EmployeeExperience experience, String message) {
        return ExperienceResponse.builder()
                .id(experience.getId())
                .employeeId(experience.getEmployee().getId())
                .organization(experience.getOrganization())
                .position(experience.getPosition())
                .startDate(experience.getStartDate().toString())
                .endDate(experience.getEndDate() != null ? experience.getEndDate().toString() : null)
                .isCurrent(experience.getIsCurrent())
                .description(experience.getDescription())
                .location(experience.getLocation())
                .message(message)
                .build();
    }
}
