package com.medicare.EmployeeCommonService.Repository;

import com.medicare.EmployeeCommonService.Entity.EmployeeEducation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface EmployeeEducationRepository extends JpaRepository<EmployeeEducation, Long> {

    List<EmployeeEducation> findByEmployeeIdOrderByYearOfPassingDesc(Long employeeId);
}
