package com.medicare.EmployeeCommonService.Controller;


import com.medicare.EmployeeCommonService.Dto.Response.EmployeeResponse;
import com.medicare.EmployeeCommonService.Dto.Request.RegisterEmployeeRequest;
import com.medicare.EmployeeCommonService.Dto.Request.UpdateEmployeeRequest;
import com.medicare.EmployeeCommonService.Enum.EmployeeType;
import com.medicare.EmployeeCommonService.Service.EmployeeService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/employees")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "*")
public class EmployeeController {

    private final EmployeeService employeeService;

    // Register new employee [ POST /api/employee-commons/employees/register ]

    @PostMapping("/register")
    public ResponseEntity<EmployeeResponse> registerEmployee(
            @Valid @RequestBody RegisterEmployeeRequest request,
            @RequestHeader("Authorization") String authHeader
    ) {
        log.info("POST /employees/register - Registering employee");
        EmployeeResponse response = employeeService.registerEmployee(request, authHeader);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    // Get employee by ID [ GET /api/employee-commons/employees/{employeeId} ]
    @GetMapping("/{employeeId}")
    public ResponseEntity<EmployeeResponse> getEmployeeById(
            @PathVariable Long employeeId,
            @RequestHeader("Authorization") String authHeader)
    {
        log.info("GET /employees/{} - Get employee by ID", employeeId);
        EmployeeResponse response = employeeService.getEmployeeById(employeeId, authHeader);
        return ResponseEntity.ok(response);
    }

    // Get employee by user ID [ GET /api/employee-commons/employees/user/{userId} ]
    @GetMapping("/user/{userId}")
    public ResponseEntity<EmployeeResponse> getEmployeeByUserId(
            @PathVariable String userId,
            @RequestHeader("Authorization") String authHeader
    ) {
        log.info("GET /employees/user/{} - Get employee by user ID", userId);
        EmployeeResponse response = employeeService.getEmployeeByUserId(userId, authHeader);
        return ResponseEntity.ok(response);
    }

    // Get all employees (Admin only) [ GET /api/employee-commons/employees ]
    @GetMapping
    public ResponseEntity<List<EmployeeResponse>> getAllEmployees(
            @RequestHeader("Authorization") String authHeader
    ) {
        log.info("GET /employees - Get all employees");
        List<EmployeeResponse> employees = employeeService.getAllEmployees(authHeader);
        return ResponseEntity.ok(employees);
    }

    // Get employees by type (Admin only) [ GET /api/employee-commons/employees/type/{employeeType} ]
    @GetMapping("/type/{employeeType}")
    public ResponseEntity<List<EmployeeResponse>> getEmployeesByType(
            @PathVariable EmployeeType employeeType,
            @RequestHeader("Authorization") String authHeader
    ) {
        log.info("GET /employees/type/{} - Get employees by type", employeeType);
        List<EmployeeResponse> employees = employeeService.getEmployeesByType(employeeType, authHeader);
        return ResponseEntity.ok(employees);
    }

    // Get employees by department (Admin only) [ GET /api/employee-commons/employees/department/{departmentId} ]
    @GetMapping("/department/{departmentId}")
    public ResponseEntity<List<EmployeeResponse>> getEmployeesByDepartment(
            @PathVariable Long departmentId,
            @RequestHeader("Authorization") String authHeader
    ) {
        log.info("GET /employees/department/{} - Get employees by department", departmentId);
        List<EmployeeResponse> employees = employeeService.getEmployeesByDepartment(departmentId, authHeader);
        return ResponseEntity.ok(employees);
    }

    // Update employee (Admin only) [ PATCH /api/employee-commons/employees/{employeeId} ]
    @PatchMapping("/{employeeId}")
    public ResponseEntity<EmployeeResponse> updateEmployee(
            @PathVariable Long employeeId,
            @Valid @RequestBody UpdateEmployeeRequest request,
            @RequestHeader("Authorization") String authHeader
    ) {
        log.info("PATCH /employees/{} - Update employee", employeeId);
        EmployeeResponse response = employeeService.updateEmployee(employeeId, request, authHeader);
        return ResponseEntity.ok(response);
    }

    // Delete employee (Admin only) [ DELETE /api/employee-commons/employees/{employeeId} ]

    @DeleteMapping("/{employeeId}")
    public ResponseEntity<Void> deleteEmployee(@PathVariable Long employeeId) {
        log.info("DELETE /employees/{} - Delete employee", employeeId);
        employeeService.deleteEmployee(employeeId);
        return ResponseEntity.noContent().build();
    }

    // Health check [ GET /api/employee-commons/employees/health ]
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("Employee Commons Service is running");
    }
}


