package com.medicare.EmployeeCommonService.Dto.Response;

import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DepartmentResponse {
    private Long id;
    private String name;
    private String description;
    private Long departmentHeadId;
    private String departmentHeadName;
    private Boolean isActive;
    private Integer employeeCount;
    private String createdAt;
    private String message;
}
