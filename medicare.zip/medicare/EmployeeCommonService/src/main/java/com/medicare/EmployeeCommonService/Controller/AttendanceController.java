package com.medicare.EmployeeCommonService.Controller;

import com.medicare.EmployeeCommonService.Dto.Response.AttendanceResponse;
import com.medicare.EmployeeCommonService.Dto.Request.RecordAttendanceRequest;
import com.medicare.EmployeeCommonService.Service.AttendanceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/employees")
@RequiredArgsConstructor
@Slf4j
public class AttendanceController {

    private final AttendanceService attendanceService;

    // RECORD ATTENDANCE
    @PostMapping("/{userId}/attendance")
    public ResponseEntity<AttendanceResponse> recordAttendance(
            @PathVariable String userId,
            @Valid @RequestBody RecordAttendanceRequest request,
            @RequestHeader("Authorization") String authHeader) {

        log.info("POST /employees/{}/attendance - Record attendance", userId);
        AttendanceResponse response = attendanceService.recordAttendance(userId, request, authHeader);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    // Get Employee Attendance By Month
    @GetMapping("/{userId}/attendance/month")
    public ResponseEntity<List<AttendanceResponse>> getAttendanceByMonth(
            @PathVariable String userId,
            @RequestParam int month,
            @RequestParam int year,
            @RequestHeader("Authorization") String authHeader) {

        log.info("GET /employees/{}/attendance/month?month={}&year={}", userId, month, year);
        List<AttendanceResponse> attendance = attendanceService.getAttendanceByMonth(userId, month, year, authHeader);
        return ResponseEntity.ok(attendance);
    }

    // Get Attendance by Date range
    @GetMapping("/{userId}/attendance/range")
    public ResponseEntity<List<AttendanceResponse>> getAttendanceByDateRange(
            @PathVariable String userId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
            @RequestHeader("Authorization") String authHeader) {

        log.info("GET /employees/{}/attendance/range?startDate={}&endDate={}", userId, startDate, endDate);
        List<AttendanceResponse> attendance = attendanceService.getAttendanceByDateRange(
                userId, startDate, endDate, authHeader);
        return ResponseEntity.ok(attendance);
    }

    // Update Check-Out Time
    @PatchMapping("/{userId}/attendance/{attendanceId}/checkout")
    public ResponseEntity<AttendanceResponse> updateCheckOut(
            @PathVariable String userId, @PathVariable Long attendanceId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime checkOutTime,
            @RequestHeader("Authorization") String authHeader) {

        log.info("PATCH /employees/{}/attendance/{}/checkout", userId, attendanceId);
        AttendanceResponse response = attendanceService.updateCheckOut(userId, attendanceId, checkOutTime, authHeader);
        return ResponseEntity.ok(response);
    }

    // Get Attendance Summary
    @GetMapping("/{userId}/attendance/summary")
    public ResponseEntity<Map<String, Object>> getAttendanceSummary(
            @PathVariable String userId, @RequestParam int month, @RequestParam int year,
            @RequestHeader("Authorization") String authHeader) {

        log.info("GET /employees/{}/attendance/summary?month={}&year={}", userId, month, year);
        Map<String, Object> summary = attendanceService.getAttendanceSummary(userId, month, year, authHeader);
        return ResponseEntity.ok(summary);
    }
}