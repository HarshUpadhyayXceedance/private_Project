package com.medicare.EmployeeCommonService.Repository;

import com.medicare.EmployeeCommonService.Entity.EmployeeAttendance;
import com.medicare.EmployeeCommonService.Enum.AttendanceStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface EmployeeAttendanceRepository extends JpaRepository<EmployeeAttendance, Long> {

    Optional<EmployeeAttendance> findByEmployeeIdAndAttendanceDate(Long employeeId, LocalDate attendanceDate);
    List<EmployeeAttendance> findByEmployeeIdAndAttendanceDateBetween(Long employeeId, LocalDate startDate, LocalDate endDate);
    List<EmployeeAttendance> findByAttendanceDate(LocalDate attendanceDate);

    @Query("SELECT a FROM EmployeeAttendance a WHERE a.employee.id = :employeeId " +
            "AND MONTH(a.attendanceDate) = :month AND YEAR(a.attendanceDate) = :year")
    List<EmployeeAttendance> findByEmployeeIdAndMonthAndYear(Long employeeId, int month, int year);

    @Query("SELECT COUNT(a) FROM EmployeeAttendance a WHERE a.employee.id = :employeeId " +
            "AND a.status = :status AND MONTH(a.attendanceDate) = :month AND YEAR(a.attendanceDate) = :year")
    Long countByEmployeeIdAndStatusAndMonthAndYear(Long employeeId, AttendanceStatus status, int month, int year);

}
