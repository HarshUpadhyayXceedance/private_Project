package com.medicare.EmployeeCommonService.Service;

import com.medicare.EmployeeCommonService.Client.AuthProfileClient;
import com.medicare.EmployeeCommonService.Dto.Response.EmployeeResponse;
import com.medicare.EmployeeCommonService.Dto.Request.RegisterEmployeeRequest;
import com.medicare.EmployeeCommonService.Dto.Request.UpdateEmployeeRequest;
import com.medicare.EmployeeCommonService.Dto.Response.UserProfileResponse;
import com.medicare.EmployeeCommonService.Entity.Department;
import com.medicare.EmployeeCommonService.Entity.Employee;
import com.medicare.EmployeeCommonService.Enum.EmployeeStatus;
import com.medicare.EmployeeCommonService.Enum.EmployeeType;
import com.medicare.EmployeeCommonService.Exception.EmployeeException;
import com.medicare.EmployeeCommonService.Repository.DepartmentRepository;
import com.medicare.EmployeeCommonService.Repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final DepartmentRepository departmentRepository;
    private final AuthProfileClient authProfileClient;

    @Value("${app.employee.code-prefix:EMP}")
    private String employeeCodePrefix;

    //=================CRUD OPERATION RELATED TO EMPLOYEE ================//

    //REGISTER EMPLOYEE
    @Transactional
    public EmployeeResponse registerEmployee(RegisterEmployeeRequest request, String authHeader) {
        log.info("Registering employee for userId: {}", request.getUserId());

        // Check if employee already exists
        if (employeeRepository.existsByUserId(request.getUserId())) {
            throw new EmployeeException("Employee already registered for this user");
        }

        // Validate user exists in Auth-Profile Service and is EMPLOYEE role
        validateUserIsEmployee(request.getUserId(), authHeader);

        // Validate department exists
        Department department = departmentRepository.findById(request.getDepartmentId())
                .orElseThrow(() -> new EmployeeException("Department not found"));

        // Generate employee code
        String employeeCode = generateEmployeeCode();

        // Create employee
        Employee employee = Employee.builder()
                .userId(request.getUserId())
                .employeeCode(employeeCode)
                .employeeType(request.getEmployeeType())
                .department(department)
                .designation(request.getDesignation())
                .joiningDate(request.getJoiningDate())
                .employmentStatus(EmployeeStatus.ACTIVE)
                .salary(request.getSalary())
                .reportingManagerId(request.getReportingManagerId())
                .build();

        Employee savedEmployee = employeeRepository.save(employee);
        log.info("Employee registered successfully: {}", savedEmployee.getEmployeeCode());

        return mapToEmployeeResponse(savedEmployee, authHeader, "Employee registered successfully");
    }

    //GET EMPLOYEE BY EMPLOYEE_ID
    @Transactional(readOnly = true)
    public EmployeeResponse getEmployeeById(Long employeeId, String authHeader) {
        log.info("Fetching employee by ID: {}", employeeId);

        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new EmployeeException("Employee not found"));

        return mapToEmployeeResponse(employee, authHeader, null);
    }

    //UPDATE EMPLOYEE PROFILE DATA
    @Transactional
    public EmployeeResponse updateEmployee(Long employeeId, UpdateEmployeeRequest request, String authHeader) {
        log.info("Updating employee: {}", employeeId);

        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new EmployeeException("Employee not found"));

        // Update fields if provided
        if (request.getDepartmentId() != null) {
            Department department = departmentRepository.findById(request.getDepartmentId())
                    .orElseThrow(() -> new EmployeeException("Department not found"));
            employee.setDepartment(department);
        }

        if (request.getDesignation() != null) {
            employee.setDesignation(request.getDesignation());
        }

        if (request.getEmploymentStatus() != null) {
            employee.setEmploymentStatus(request.getEmploymentStatus());
        }

        if (request.getSalary() != null) {
            employee.setSalary(request.getSalary());
        }

        if (request.getReportingManagerId() != null) {
            employee.setReportingManagerId(request.getReportingManagerId());
        }

        Employee updatedEmployee = employeeRepository.save(employee);
        log.info("Employee updated successfully: {}", employeeId);

        return mapToEmployeeResponse(updatedEmployee, authHeader, "Employee updated successfully");
    }

    //DELETE EMPLOYEE PROFILE DATA
    @Transactional
    public void deleteEmployee(Long employeeId) {
        log.info("Deleting employee: {}", employeeId);

        if (!employeeRepository.existsById(employeeId)) {
            throw new EmployeeException("Employee not found");
        }

        employeeRepository.deleteById(employeeId);
        log.info("Employee deleted successfully: {}", employeeId);
    }

    //================== ADVANCE GET ENDPOINT RELATED TO EMPLOYEE ===================//

    @Transactional(readOnly = true)
    public EmployeeResponse getEmployeeByUserId(String userId, String authHeader) {
        log.info("Fetching employee by userId: {}", userId);

        Employee employee = employeeRepository.findByUserId(userId)
                .orElseThrow(() -> new EmployeeException("Employee not found"));

        return mapToEmployeeResponse(employee, authHeader, null);
    }

    //GET LIST OF ALL EMPLOYEE
    @Transactional(readOnly = true)
    public List<EmployeeResponse> getAllEmployees(String authHeader) {
        log.info("Fetching all employees");

        return employeeRepository.findAll().stream()
                .map(employee -> mapToEmployeeResponse(employee, authHeader, null))
                .collect(Collectors.toList());
    }

    //GET LIST OF EMPLOYEE BY TYPE{i.e. DOCTOR, ADMIN, NURSE, STAFF}
    @Transactional(readOnly = true)
    public List<EmployeeResponse> getEmployeesByType(EmployeeType employeeType, String authHeader) {
        log.info("Fetching employees by type: {}", employeeType);

        return employeeRepository.findByEmployeeType(employeeType).stream()
                .map(employee -> mapToEmployeeResponse(employee, authHeader, null))
                .collect(Collectors.toList());
    }

    // GET LIST OF EMPLOYEE BY DEPARTMENT
    @Transactional(readOnly = true)
    public List<EmployeeResponse> getEmployeesByDepartment(Long departmentId, String authHeader) {
        log.info("Fetching employees by department: {}", departmentId);

        // Validate department exists
        if (!departmentRepository.existsById(departmentId)) {
            throw new EmployeeException("Department not found");
        }

        return employeeRepository.findByDepartmentId(departmentId).stream()
                .map(employee -> mapToEmployeeResponse(employee, authHeader, null))
                .collect(Collectors.toList());
    }

    //================= Helper Methods ===============//

    private void validateUserIsEmployee(String userId, String authHeader) {
        try {
            ResponseEntity<Map<String, Object>> response = authProfileClient.getUserDetails(userId, authHeader);

            if (response.getBody() == null) {
                throw new EmployeeException("User not found in Auth-Profile service");
            }

            String role = (String) response.getBody().get("role");
            if (!"EMPLOYEE".equals(role)) {
                throw new EmployeeException("User must have EMPLOYEE role to register as employee");
            }

            log.info("User validated as EMPLOYEE: {}", userId);
        } catch (Exception e) {
            log.error("Failed to validate user: {}", e.getMessage());
            throw new EmployeeException("Failed to validate user: " + e.getMessage());
        }
    }

    private String generateEmployeeCode() {
        long count = employeeRepository.count();
        String code;
        do {
            count++;
            code = String.format("%s-%06d", employeeCodePrefix, count);
        } while (employeeRepository.existsByEmployeeCode(code));

        return code;
    }

    private EmployeeResponse mapToEmployeeResponse(Employee employee, String authHeader, String message) {
        DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;

        // Fetch user profile data from Auth-Profile Service
        UserProfileResponse userProfile = null;
        try {
            ResponseEntity<UserProfileResponse> response = authProfileClient.getUserProfile(
                    employee.getUserId(),
                    authHeader
            );
            userProfile = response.getBody();
        } catch (Exception e) {
            log.warn("Failed to fetch user profile for userId: {}", employee.getUserId());
        }

        // Fetch reporting manager name if exists
        String reportingManagerName = null;
        if (employee.getReportingManagerId() != null) {
            try {
                Employee manager = employeeRepository.findById(employee.getReportingManagerId()).orElse(null);
                if (manager != null) {
                    ResponseEntity<UserProfileResponse> managerProfile = authProfileClient.getUserProfile(
                            manager.getUserId(),
                            authHeader
                    );
                    if (managerProfile.getBody() != null) {
                        reportingManagerName = managerProfile.getBody().getName();
                    }
                }
            } catch (Exception e) {
                log.warn("Failed to fetch reporting manager name");
            }
        }

        return EmployeeResponse.builder()
                .id(employee.getId())
                .userId(employee.getUserId())
                .employeeCode(employee.getEmployeeCode())
                .employeeType(employee.getEmployeeType().name())
                .name(userProfile != null ? userProfile.getName() : null)
                .email(userProfile != null ? userProfile.getEmail() : null)
                .phone(userProfile != null ? userProfile.getPhone() : null)
                .profilePicture(userProfile != null ? userProfile.getProfilePicture() : null)
                .departmentName(employee.getDepartment() != null ? employee.getDepartment().getName() : null)
                .departmentId(employee.getDepartment() != null ? employee.getDepartment().getId() : null)
                .designation(employee.getDesignation())
                .joiningDate(employee.getJoiningDate().toString())
                .employmentStatus(employee.getEmploymentStatus().name())
                .salary(employee.getSalary())
                .reportingManagerId(employee.getReportingManagerId())
                .reportingManagerName(reportingManagerName)
                .createdAt(employee.getCreatedAt().format(formatter))
                .updatedAt(employee.getUpdatedAt().format(formatter))
                .message(message)
                .build();
    }

}