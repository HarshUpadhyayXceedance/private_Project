package com.medicare.EmployeeCommonService.Service;

import com.medicare.EmployeeCommonService.Dto.Response.DocumentResponse;
import com.medicare.EmployeeCommonService.Dto.Request.UploadDocumentRequest;
import com.medicare.EmployeeCommonService.Entity.Employee;
import com.medicare.EmployeeCommonService.Entity.EmployeeDocument;
import com.medicare.EmployeeCommonService.Exception.EmployeeException;
import com.medicare.EmployeeCommonService.Repository.EmployeeDocumentRepository;
import com.medicare.EmployeeCommonService.Repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class DocumentService {

    private final EmployeeDocumentRepository documentRepository;
    private final EmployeeRepository employeeRepository;

    @Transactional
    public DocumentResponse uploadDocument(String userId, UploadDocumentRequest request, String uploadedBy) {
        log.info("Uploading document for userId: {}", userId);

        Employee employee = employeeRepository.findByUserId(userId)
                .orElseThrow(() -> new EmployeeException("Employee not found"));

        EmployeeDocument document = EmployeeDocument.builder()
                .employee(employee)
                .documentType(request.getDocumentType())
                .documentName(request.getDocumentName())
                .documentUrl(request.getDocumentUrl())
                .fileSize(request.getFileSize())
                .contentType(request.getContentType())
                .uploadedBy(uploadedBy)
                .notes(request.getNotes())
                .build();

        EmployeeDocument savedDocument = documentRepository.save(document);
        log.info("Document uploaded successfully");

        return mapToDocumentResponse(savedDocument, "Document uploaded successfully");
    }

    @Transactional(readOnly = true)
    public List<DocumentResponse> getDocuments(String userId) {
        log.info("Fetching documents for userId: {}", userId);

        Employee employee = employeeRepository.findByUserId(userId)
                .orElseThrow(() -> new EmployeeException("Employee not found"));

        return documentRepository.findByEmployeeIdOrderByUploadedAtDesc(employee.getId()).stream()
                .map(document -> mapToDocumentResponse(document, null))
                .collect(Collectors.toList());
    }

    @Transactional
    public void deleteDocument(String userId, Long documentId) {
        log.info("Deleting document: {} for userId: {}", documentId, userId);

        Employee employee = employeeRepository.findByUserId(userId)
                .orElseThrow(() -> new EmployeeException("Employee not found"));

        EmployeeDocument document = documentRepository.findById(documentId)
                .orElseThrow(() -> new EmployeeException("Document not found"));

        if (!document.getEmployee().getId().equals(employee.getId())) {
            throw new EmployeeException("Cannot delete document of another employee");
        }

        documentRepository.delete(document);
        log.info("Document deleted successfully");
    }

    private DocumentResponse mapToDocumentResponse(EmployeeDocument document, String message) {
        DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;

        return DocumentResponse.builder()
                .id(document.getId())
                .employeeId(document.getEmployee().getId())
                .documentType(document.getDocumentType().name())
                .documentName(document.getDocumentName())
                .documentUrl(document.getDocumentUrl())
                .fileSize(document.getFileSize())
                .contentType(document.getContentType())
                .uploadedBy(document.getUploadedBy())
                .uploadedAt(document.getUploadedAt().format(formatter))
                .notes(document.getNotes())
                .message(message)
                .build();
    }
}