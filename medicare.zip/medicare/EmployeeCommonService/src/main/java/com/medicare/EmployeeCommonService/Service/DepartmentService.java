package com.medicare.EmployeeCommonService.Service;


import com.medicare.EmployeeCommonService.Client.AuthProfileClient;
import com.medicare.EmployeeCommonService.Dto.Request.CreateDepartmentRequest;
import com.medicare.EmployeeCommonService.Dto.Response.DepartmentResponse;
import com.medicare.EmployeeCommonService.Dto.Response.UserProfileResponse;
import com.medicare.EmployeeCommonService.Entity.Department;
import com.medicare.EmployeeCommonService.Entity.Employee;
import com.medicare.EmployeeCommonService.Exception.EmployeeException;
import com.medicare.EmployeeCommonService.Repository.DepartmentRepository;
import com.medicare.EmployeeCommonService.Repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class DepartmentService {

    private final DepartmentRepository departmentRepository;
    private final EmployeeRepository employeeRepository;
    private final AuthProfileClient authProfileClient;

    @Transactional
    public DepartmentResponse createDepartment(CreateDepartmentRequest request) {
        log.info("Creating department: {}", request.getName());

        if (departmentRepository.existsByName(request.getName())) {
            throw new EmployeeException("Department with this name already exists");
        }

        Department department = Department.builder()
                .name(request.getName())
                .description(request.getDescription())
                .departmentHeadId(request.getDepartmentHeadId())
                .isActive(true)
                .build();

        Department savedDepartment = departmentRepository.save(department);
        log.info("Department created successfully: {}", savedDepartment.getId());

        return mapToDepartmentResponse(savedDepartment, null, "Department created successfully");
    }

    @Transactional(readOnly = true)
    public List<DepartmentResponse> getAllDepartments(String authHeader) {
        log.info("Fetching all departments");

        return departmentRepository.findAll().stream()
                .map(department -> mapToDepartmentResponse(department, authHeader, null))
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public DepartmentResponse getDepartmentById(Long departmentId, String authHeader) {
        log.info("Fetching department: {}", departmentId);

        Department department = departmentRepository.findById(departmentId)
                .orElseThrow(() -> new EmployeeException("Department not found"));

        return mapToDepartmentResponse(department, authHeader, null);
    }

    private DepartmentResponse mapToDepartmentResponse(Department department, String authHeader, String message) {
        DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;

        // Fetch department head name if exists
        String departmentHeadName = null;
        if (department.getDepartmentHeadId() != null && authHeader != null) {
            try {
                Employee head = employeeRepository.findById(department.getDepartmentHeadId()).orElse(null);
                if (head != null) {
                    ResponseEntity<UserProfileResponse> response = authProfileClient.getUserProfile(
                            head.getUserId(),
                            authHeader
                    );
                    if (response.getBody() != null) {
                        departmentHeadName = response.getBody().getName();
                    }
                }
            } catch (Exception e) {
                log.warn("Failed to fetch department head name");
            }
        }

        // Count employees in department
        int employeeCount = employeeRepository.findByDepartmentId(department.getId()).size();

        return DepartmentResponse.builder()
                .id(department.getId())
                .name(department.getName())
                .description(department.getDescription())
                .departmentHeadId(department.getDepartmentHeadId())
                .departmentHeadName(departmentHeadName)
                .isActive(department.getIsActive())
                .employeeCount(employeeCount)
                .createdAt(department.getCreatedAt().format(formatter))
                .message(message)
                .build();
    }
}