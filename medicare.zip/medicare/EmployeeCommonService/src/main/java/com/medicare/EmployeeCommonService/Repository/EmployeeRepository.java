package com.medicare.EmployeeCommonService.Repository;


import com.medicare.EmployeeCommonService.Entity.Employee;
import com.medicare.EmployeeCommonService.Enum.EmployeeStatus;
import com.medicare.EmployeeCommonService.Enum.EmployeeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    Optional<Employee> findByUserId(String userId);
    Optional<Employee> findByEmployeeCode(String employeeCode);
    boolean existsByUserId(String userId);
    boolean existsByEmployeeCode(String employeeCode);
    List<Employee> findByEmployeeType(EmployeeType employeeType);
    List<Employee> findByEmploymentStatus(EmployeeStatus employmentStatus);
    List<Employee> findByDepartmentId(Long departmentId);
    List<Employee> findByEmployeeTypeAndEmploymentStatus(EmployeeType employeeType, EmployeeStatus status);

    @Query("SELECT e FROM Employee e WHERE e.reportingManagerId = :managerId")
    List<Employee> findByReportingManagerId(Long managerId);

    @Query("SELECT COUNT(e) FROM Employee e WHERE e.employeeType = :type")
    Long countByEmployeeType(EmployeeType type);
}




