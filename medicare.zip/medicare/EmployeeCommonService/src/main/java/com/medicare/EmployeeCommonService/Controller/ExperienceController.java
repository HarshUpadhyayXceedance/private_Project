package com.medicare.EmployeeCommonService.Controller;

import com.medicare.EmployeeCommonService.Dto.Request.AddExperienceRequest;
import com.medicare.EmployeeCommonService.Dto.Response.ExperienceResponse;
import com.medicare.EmployeeCommonService.Service.ExperienceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/employees")
@RequiredArgsConstructor
@Slf4j
public class ExperienceController {

    private final ExperienceService experienceService;

    // Add experience record [ POST /api/employee-commons/employees/{userId}/experience ]
    @PostMapping("/{userId}/experience")
    public ResponseEntity<ExperienceResponse> addExperience(
            @PathVariable String userId,
            @Valid @RequestBody AddExperienceRequest request) {
        log.info("POST /employees/{}/experience - Add experience", userId);
        ExperienceResponse response = experienceService.addExperience(userId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    // Get experience records [ GET /api/employee-commons/employees/{userId}/experience ]
    @GetMapping("/{userId}/experience")
    public ResponseEntity<List<ExperienceResponse>> getExperienceRecords(
            @PathVariable String userId
    ) {
        log.info("GET /employees/{}/experience - Get experience records", userId);
        List<ExperienceResponse> experiences = experienceService.getExperienceRecords(userId);
        return ResponseEntity.ok(experiences);
    }

    // Delete experience record [ DELETE /api/employee-commons/employees/{userId}/experience/{experienceId}
    @DeleteMapping("/{userId}/experience/{experienceId}")
    public ResponseEntity<Void> deleteExperience(
            @PathVariable String userId,
            @PathVariable Long experienceId
    ) {
        log.info("DELETE /employees/{}/experience/{} - Delete experience", userId, experienceId);
        experienceService.deleteExperience(userId, experienceId);
        return ResponseEntity.noContent().build();
    }
}
