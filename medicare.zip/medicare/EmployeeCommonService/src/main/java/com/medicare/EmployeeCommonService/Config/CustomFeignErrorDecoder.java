package com.medicare.EmployeeCommonService.Config;

import com.medicare.EmployeeCommonService.Exception.EmployeeException;
import feign.Response;
import feign.codec.ErrorDecoder;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CustomFeignErrorDecoder implements ErrorDecoder {

    private final ErrorDecoder defaultErrorDecoder = new Default();

    @Override
    public Exception decode(String methodKey, Response response) {
        log.error("Feign client error: {} - {}", response.status(), response.reason());

        switch (response.status()) {
            case 400:
                return new EmployeeException("Bad request to Auth-Profile service");
            case 401:
                return new EmployeeException("Unauthorized access to Auth-Profile service");
            case 403:
                return new EmployeeException("Forbidden access to Auth-Profile service");
            case 404:
                return new EmployeeException("User not found in Auth-Profile service");
            case 503:
                return new EmployeeException("Auth-Profile service unavailable");
            default:
                return defaultErrorDecoder.decode(methodKey, response);
        }
    }
}
