package com.medicare.EmployeeCommonService.Dto.Response;

import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AttendanceResponse {
    private Long id;
    private Long employeeId;
    private String employeeName;
    private String attendanceDate;
    private String checkInTime;
    private String checkOutTime;
    private String status;
    private Double totalHours;
    private String remarks;
    private String createdAt;
    private String message;
}