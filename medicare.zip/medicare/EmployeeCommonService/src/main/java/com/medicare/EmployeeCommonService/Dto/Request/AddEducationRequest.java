package com.medicare.EmployeeCommonService.Dto.Request;

import jakarta.validation.constraints.*;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AddEducationRequest {

    @NotBlank(message = "Degree is required")
    private String degree;

    @NotBlank(message = "Institution is required")
    private String institution;

    @NotNull(message = "Year of passing is required")
    @Min(value = 1950, message = "Year must be after 1950")
    @Max(value = 2100, message = "Year must be before 2100")
    private Integer yearOfPassing;

    private String fieldOfStudy;

    private String gradeOrPercentage;
}
