package com.medicare.EmployeeCommonService.Dto.Request;


import com.medicare.EmployeeCommonService.Enum.EmployeeType;
import jakarta.validation.constraints.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;

// ============= REGISTER EMPLOYEE REQUEST =============
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RegisterEmployeeRequest {

    @NotBlank(message = "User ID is required")
    private String userId;

    @NotNull(message = "Employee type is required")
    private EmployeeType employeeType;

    @NotNull(message = "Department ID is required")
    private Long departmentId;

    @NotBlank(message = "Designation is required")
    private String designation;

    @NotNull(message = "Joining date is required")
    @PastOrPresent(message = "Joining date cannot be in future")
    private LocalDate joiningDate;

    @NotNull(message = "Salary is required")
    @DecimalMin(value = "0.0", message = "Salary must be positive")
    private BigDecimal salary;

    private Long reportingManagerId;

}



















