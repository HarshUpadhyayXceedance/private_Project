package com.medicare.EmployeeCommonService.Enum;



public enum EmployeeType {
    DOCTOR,
    NURSE,
    STAFF,
    ADMIN
}














