package com.medicare.EmployeeCommonService.Service;


import com.medicare.EmployeeCommonService.Client.AuthProfileClient;
import com.medicare.EmployeeCommonService.Dto.Request.ApplyLeaveRequest;
import com.medicare.EmployeeCommonService.Dto.Request.LeaveApprovalRequest;
import com.medicare.EmployeeCommonService.Dto.Response.LeaveResponse;
import com.medicare.EmployeeCommonService.Dto.Response.UserProfileResponse;
import com.medicare.EmployeeCommonService.Entity.Employee;
import com.medicare.EmployeeCommonService.Entity.EmployeeLeave;
import com.medicare.EmployeeCommonService.Enum.LeaveStatus;
import com.medicare.EmployeeCommonService.Enum.LeaveType;
import com.medicare.EmployeeCommonService.Exception.EmployeeException;
import com.medicare.EmployeeCommonService.Repository.EmployeeLeaveRepository;
import com.medicare.EmployeeCommonService.Repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class LeaveService {

    private final EmployeeLeaveRepository leaveRepository;
    private final EmployeeRepository employeeRepository;
    private final AuthProfileClient authProfileClient;

    @Value("${app.leave.max-annual-leave:30}")
    private Integer maxAnnualLeave;

    @Value("${app.leave.max-sick-leave:15}")
    private Integer maxSickLeave;

    @Value("${app.leave.max-casual-leave:10}")
    private Integer maxCasualLeave;

    @Transactional
    public LeaveResponse applyLeave(String userId, ApplyLeaveRequest request, String authHeader) {
        log.info("Applying leave for userId: {}", userId);

        // Get employee
        Employee employee = employeeRepository.findByUserId(userId)
                .orElseThrow(() -> new EmployeeException("Employee not found"));

        // Validate dates
        if (request.getEndDate().isBefore(request.getStartDate())) {
            throw new EmployeeException("End date cannot be before start date");
        }

        // Calculate total days
        int totalDays = (int) ChronoUnit.DAYS.between(request.getStartDate(), request.getEndDate()) + 1;

        // Check for overlapping leaves
        List<EmployeeLeave> overlappingLeaves = leaveRepository.findOverlappingLeaves(
                employee.getId(),
                request.getStartDate(),
                request.getEndDate()
        );

        if (!overlappingLeaves.isEmpty()) {
            throw new EmployeeException("Leave application overlaps with existing leave request");
        }

        // Check leave balance
        int currentYear = request.getStartDate().getYear();
        validateLeaveBalance(employee.getId(), request.getLeaveType(), totalDays, currentYear);

        // Create leave application
        EmployeeLeave leave = EmployeeLeave.builder()
                .employee(employee)
                .leaveType(request.getLeaveType())
                .startDate(request.getStartDate())
                .endDate(request.getEndDate())
                .totalDays(totalDays)
                .reason(request.getReason())
                .status(LeaveStatus.PENDING)
                .build();

        EmployeeLeave savedLeave = leaveRepository.save(leave);
        log.info("Leave applied successfully: {}", savedLeave.getId());

        return mapToLeaveResponse(savedLeave, authHeader, "Leave applied successfully. Awaiting approval.");
    }

    @Transactional(readOnly = true)
    public List<LeaveResponse> getEmployeeLeaves(String userId, String authHeader) {
        log.info("Fetching leaves for userId: {}", userId);

        Employee employee = employeeRepository.findByUserId(userId)
                .orElseThrow(() -> new EmployeeException("Employee not found"));

        return leaveRepository.findByEmployeeId(employee.getId()).stream()
                .map(leave -> mapToLeaveResponse(leave, authHeader, null))
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<LeaveResponse> getPendingLeaves(String authHeader) {
        log.info("Fetching all pending leaves");

        return leaveRepository.findByStatus(LeaveStatus.PENDING).stream()
                .map(leave -> mapToLeaveResponse(leave, authHeader, null))
                .collect(Collectors.toList());
    }

    @Transactional
    public LeaveResponse approveOrRejectLeave(Long leaveId, LeaveApprovalRequest request, String approvedBy, String authHeader) {
        log.info("Processing leave approval/rejection for leaveId: {}", leaveId);

        EmployeeLeave leave = leaveRepository.findById(leaveId)
                .orElseThrow(() -> new EmployeeException("Leave not found"));

        if (leave.getStatus() != LeaveStatus.PENDING) {
            throw new EmployeeException("Leave is not in pending status");
        }

        if ("APPROVE".equals(request.getAction())) {
            leave.setStatus(LeaveStatus.APPROVED);
            leave.setApprovedBy(approvedBy);
            leave.setApprovedAt(LocalDateTime.now());
            log.info("Leave approved: {}", leaveId);
        } else if ("REJECT".equals(request.getAction())) {
            leave.setStatus(LeaveStatus.REJECTED);
            leave.setApprovedBy(approvedBy);
            leave.setApprovedAt(LocalDateTime.now());
            leave.setRejectionReason(request.getRejectionReason());
            log.info("Leave rejected: {}", leaveId);
        } else {
            throw new EmployeeException("Invalid action. Must be APPROVE or REJECT");
        }

        EmployeeLeave updatedLeave = leaveRepository.save(leave);

        String message = "APPROVE".equals(request.getAction())
                ? "Leave approved successfully"
                : "Leave rejected";

        return mapToLeaveResponse(updatedLeave, authHeader, message);
    }

    @Transactional
    public void cancelLeave(String userId, Long leaveId) {
        log.info("Cancelling leave: {} for userId: {}", leaveId, userId);

        Employee employee = employeeRepository.findByUserId(userId)
                .orElseThrow(() -> new EmployeeException("Employee not found"));

        EmployeeLeave leave = leaveRepository.findById(leaveId)
                .orElseThrow(() -> new EmployeeException("Leave not found"));

        if (!leave.getEmployee().getId().equals(employee.getId())) {
            throw new EmployeeException("Cannot cancel leave of another employee");
        }

        if (leave.getStatus() == LeaveStatus.APPROVED || leave.getStatus() == LeaveStatus.REJECTED) {
            throw new EmployeeException("Cannot cancel leave that is already " + leave.getStatus());
        }

        leave.setStatus(LeaveStatus.CANCELLED);
        leaveRepository.save(leave);
        log.info("Leave cancelled successfully: {}", leaveId);
    }


    // Helper Methods
    private void validateLeaveBalance(Long employeeId, LeaveType leaveType, int requestedDays, int year) {
        Integer usedDays = leaveRepository.getTotalApprovedLeaveDays(employeeId, leaveType, year);
        if (usedDays == null) {
            usedDays = 0;
        }

        int maxAllowed = getMaxLeaveForType(leaveType);
        int remaining = maxAllowed - usedDays;

        if (requestedDays > remaining) {
            throw new EmployeeException(
                    String.format("Insufficient leave balance. Requested: %d days, Available: %d days",
                            requestedDays, remaining)
            );
        }
    }

    private int getMaxLeaveForType(LeaveType leaveType) {
        switch (leaveType) {
            case ANNUAL_LEAVE:
                return maxAnnualLeave;
            case SICK_LEAVE:
                return maxSickLeave;
            case CASUAL_LEAVE:
                return maxCasualLeave;
            default:
                return 0; // No limit for other types
        }
    }

    private LeaveResponse mapToLeaveResponse(EmployeeLeave leave, String authHeader, String message) {
        DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;

        // Fetch employee name
        String employeeName = null;
        try {
            ResponseEntity<UserProfileResponse> response = authProfileClient.getUserProfile(
                    leave.getEmployee().getUserId(),
                    authHeader
            );
            if (response.getBody() != null) {
                employeeName = response.getBody().getName();
            }
        } catch (Exception e) {
            log.warn("Failed to fetch employee name");
        }

        return LeaveResponse.builder()
                .id(leave.getId())
                .employeeId(leave.getEmployee().getId())
                .employeeName(employeeName)
                .leaveType(leave.getLeaveType().name())
                .startDate(leave.getStartDate().toString())
                .endDate(leave.getEndDate().toString())
                .totalDays(leave.getTotalDays())
                .reason(leave.getReason())
                .status(leave.getStatus().name())
                .approvedBy(leave.getApprovedBy())
                .approvedAt(leave.getApprovedAt() != null ? leave.getApprovedAt().format(formatter) : null)
                .rejectionReason(leave.getRejectionReason())
                .createdAt(leave.getCreatedAt().format(formatter))
                .message(message)
                .build();
    }
}