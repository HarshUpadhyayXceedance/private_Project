package com.medicare.EmployeeCommonService.Repository;

import com.medicare.EmployeeCommonService.Entity.EmployeeLeave;
import com.medicare.EmployeeCommonService.Enum.LeaveStatus;
import com.medicare.EmployeeCommonService.Enum.LeaveType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface EmployeeLeaveRepository extends JpaRepository<EmployeeLeave, Long> {

    List<EmployeeLeave> findByEmployeeId(Long employeeId);
    List<EmployeeLeave> findByEmployeeIdAndStatus(Long employeeId, LeaveStatus status);
    List<EmployeeLeave> findByStatus(LeaveStatus status);

    @Query("SELECT l FROM EmployeeLeave l WHERE l.employee.id = :employeeId " +
            "AND l.startDate <= :endDate AND l.endDate >= :startDate " +
            "AND l.status IN ('PENDING', 'APPROVED')")
    List<EmployeeLeave> findOverlappingLeaves(Long employeeId, LocalDate startDate, LocalDate endDate);


    @Query("SELECT l FROM EmployeeLeave l WHERE l.employee.id = :employeeId " +
            "AND l.leaveType = :leaveType AND YEAR(l.startDate) = :year AND l.status = 'APPROVED'")
    List<EmployeeLeave> findApprovedLeavesByTypeAndYear(Long employeeId, LeaveType leaveType, int year);


    @Query("SELECT SUM(l.totalDays) FROM EmployeeLeave l WHERE l.employee.id = :employeeId " +
            "AND l.leaveType = :leaveType AND YEAR(l.startDate) = :year AND l.status = 'APPROVED'")
    Integer getTotalApprovedLeaveDays(Long employeeId, LeaveType leaveType, int year);
}
