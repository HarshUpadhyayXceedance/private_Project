package com.medicare.EmployeeCommonService.Service;

import com.medicare.EmployeeCommonService.Client.AuthProfileClient;
import com.medicare.EmployeeCommonService.Dto.*;
import com.medicare.EmployeeCommonService.Dto.Request.RecordAttendanceRequest;
import com.medicare.EmployeeCommonService.Dto.Response.AttendanceResponse;
import com.medicare.EmployeeCommonService.Dto.Response.UserProfileResponse;
import com.medicare.EmployeeCommonService.Entity.Employee;
import com.medicare.EmployeeCommonService.Entity.EmployeeAttendance;
import com.medicare.EmployeeCommonService.Exception.EmployeeException;
import com.medicare.EmployeeCommonService.Repository.EmployeeAttendanceRepository;
import com.medicare.EmployeeCommonService.Repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class AttendanceService {

    private final EmployeeAttendanceRepository attendanceRepository;
    private final EmployeeRepository employeeRepository;
    private final AuthProfileClient authProfileClient;

    @Transactional
    public AttendanceResponse recordAttendance(String userId, RecordAttendanceRequest request, String authHeader) {
        log.info("Recording attendance for userId: {}", userId);

        Employee employee = employeeRepository.findByUserId(userId)
                .orElseThrow(() -> new EmployeeException("Employee not found"));

        // Check if attendance already exists for this date
        attendanceRepository.findByEmployeeIdAndAttendanceDate(employee.getId(), request.getAttendanceDate())
                .ifPresent(existing -> {
                    throw new EmployeeException("Attendance already recorded for this date");
                });

        EmployeeAttendance attendance = EmployeeAttendance.builder()
                .employee(employee)
                .attendanceDate(request.getAttendanceDate())
                .checkInTime(request.getCheckInTime())
                .checkOutTime(request.getCheckOutTime())
                .status(request.getStatus())
                .remarks(request.getRemarks())
                .build();

        // Calculate total hours if both check-in and check-out are present
        if (request.getCheckInTime() != null && request.getCheckOutTime() != null) {
            Duration duration = Duration.between(request.getCheckInTime(), request.getCheckOutTime());
            attendance.setTotalHours(duration.toHours() + (duration.toMinutes() % 60) / 60.0);
        }

        EmployeeAttendance savedAttendance = attendanceRepository.save(attendance);
        log.info("Attendance recorded successfully");

        return mapToAttendanceResponse(savedAttendance, authHeader, "Attendance recorded successfully");
    }

    @Transactional(readOnly = true)
    public List<AttendanceResponse> getAttendanceByMonth(String userId, int month, int year, String authHeader) {
        log.info("Fetching attendance for userId: {} for month: {}/{}", userId, month, year);

        Employee employee = employeeRepository.findByUserId(userId)
                .orElseThrow(() -> new EmployeeException("Employee not found"));

        return attendanceRepository.findByEmployeeIdAndMonthAndYear(employee.getId(), month, year).stream()
                .map(attendance -> mapToAttendanceResponse(attendance, authHeader, null))
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<AttendanceResponse> getAttendanceByDateRange(
            String userId,
            LocalDate startDate,
            LocalDate endDate,
            String authHeader) {

        log.info("Fetching attendance for userId: {} from {} to {}", userId, startDate, endDate);

        Employee employee = employeeRepository.findByUserId(userId)
                .orElseThrow(() -> new EmployeeException("Employee not found"));

        return attendanceRepository.findByEmployeeIdAndAttendanceDateBetween(
                        employee.getId(), startDate, endDate).stream()
                .map(attendance -> mapToAttendanceResponse(attendance, authHeader, null))
                .collect(Collectors.toList());
    }

    @Transactional
    public AttendanceResponse updateCheckOut(String userId, Long attendanceId, LocalTime checkOutTime, String authHeader) {
        log.info("Updating check-out time for attendance: {}", attendanceId);

        Employee employee = employeeRepository.findByUserId(userId)
                .orElseThrow(() -> new EmployeeException("Employee not found"));

        EmployeeAttendance attendance = attendanceRepository.findById(attendanceId)
                .orElseThrow(() -> new EmployeeException("Attendance record not found"));

        if (!attendance.getEmployee().getId().equals(employee.getId())) {
            throw new EmployeeException("Cannot update attendance of another employee");
        }

        attendance.setCheckOutTime(checkOutTime);

        // Recalculate total hours
        if (attendance.getCheckInTime() != null && checkOutTime != null) {
            Duration duration = Duration.between(attendance.getCheckInTime(), checkOutTime);
            attendance.setTotalHours(duration.toHours() + (duration.toMinutes() % 60) / 60.0);
        }

        EmployeeAttendance updatedAttendance = attendanceRepository.save(attendance);
        log.info("Check-out time updated successfully");

        return mapToAttendanceResponse(updatedAttendance, authHeader, "Check-out time updated successfully");
    }

    @Transactional(readOnly = true)
    public Map<String, Object> getAttendanceSummary(String userId, int month, int year, String authHeader) {
        log.info("Fetching attendance summary for userId: {} for {}/{}", userId, month, year);

        Employee employee = employeeRepository.findByUserId(userId)
                .orElseThrow(() -> new EmployeeException("Employee not found"));

        Map<String, Object> summary = new HashMap<>();

        Long presentCount = attendanceRepository.countByEmployeeIdAndStatusAndMonthAndYear(
                employee.getId(),
                com.medicare.EmployeeCommonService.Enum.AttendanceStatus.PRESENT,
                month,
                year
        );

        Long absentCount = attendanceRepository.countByEmployeeIdAndStatusAndMonthAndYear(
                employee.getId(),
                com.medicare.EmployeeCommonService.Enum.AttendanceStatus.ABSENT,
                month,
                year
        );

        Long halfDayCount = attendanceRepository.countByEmployeeIdAndStatusAndMonthAndYear(
                employee.getId(),
                com.medicare.EmployeeCommonService.Enum.AttendanceStatus.HALF_DAY,
                month,
                year
        );

        summary.put("month", month);
        summary.put("year", year);
        summary.put("presentDays", presentCount);
        summary.put("absentDays", absentCount);
        summary.put("halfDays", halfDayCount);
        summary.put("totalWorkingDays", presentCount + absentCount + halfDayCount);

        return summary;
    }

    // Helper method
    private AttendanceResponse mapToAttendanceResponse(
            EmployeeAttendance attendance,
            String authHeader,
            String message) {

        DateTimeFormatter dateFormatter = DateTimeFormatter.ISO_DATE;
        DateTimeFormatter timeFormatter = DateTimeFormatter.ISO_TIME;
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ISO_DATE_TIME;

        // Fetch employee name
        String employeeName = null;
        try {
            ResponseEntity<UserProfileResponse> response = authProfileClient.getUserProfile(
                    attendance.getEmployee().getUserId(),
                    authHeader
            );
            if (response.getBody() != null) {
                employeeName = response.getBody().getName();
            }
        } catch (Exception e) {
            log.warn("Failed to fetch employee name");
        }

        return AttendanceResponse.builder()
                .id(attendance.getId())
                .employeeId(attendance.getEmployee().getId())
                .employeeName(employeeName)
                .attendanceDate(attendance.getAttendanceDate().format(dateFormatter))
                .checkInTime(attendance.getCheckInTime() != null ?
                        attendance.getCheckInTime().format(timeFormatter) : null)
                .checkOutTime(attendance.getCheckOutTime() != null ?
                        attendance.getCheckOutTime().format(timeFormatter) : null)
                .status(attendance.getStatus().name())
                .totalHours(attendance.getTotalHours())
                .remarks(attendance.getRemarks())
                .createdAt(attendance.getCreatedAt().format(dateTimeFormatter))
                .message(message)
                .build();
    }
}