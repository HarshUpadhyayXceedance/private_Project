package com.medicare.EmployeeCommonService.Exception;

public class EmployeeException extends RuntimeException {
    public EmployeeException(String message) {
        super(message);
    }
}

