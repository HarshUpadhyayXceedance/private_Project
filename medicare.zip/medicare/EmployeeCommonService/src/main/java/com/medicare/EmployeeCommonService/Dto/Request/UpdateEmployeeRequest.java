package com.medicare.EmployeeCommonService.Dto.Request;

import com.medicare.EmployeeCommonService.Enum.EmployeeStatus;
import lombok.*;
import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateEmployeeRequest {
    private Long departmentId;
    private String designation;
    private EmployeeStatus employmentStatus;
    private BigDecimal salary;
    private Long reportingManagerId;
}
