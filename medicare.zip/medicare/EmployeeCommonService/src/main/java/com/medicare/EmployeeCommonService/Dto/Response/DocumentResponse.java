package com.medicare.EmployeeCommonService.Dto.Response;

import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DocumentResponse {
    private Long id;
    private Long employeeId;
    private String documentType;
    private String documentName;
    private String documentUrl;
    private Long fileSize;
    private String contentType;
    private String uploadedBy;
    private String uploadedAt;
    private String notes;
    private String message;
}
