package com.medicare.EmployeeCommonService.Enum;


public enum LeaveType {
    ANNUAL_LEAVE,
    SICK_LEAVE,
    CASUAL_LEAVE,
    MATERNITY_LEAVE,
    PATERNITY_LEAVE,
    EMERGENCY_LEAVE,
    UNPAID_LEAVE
}