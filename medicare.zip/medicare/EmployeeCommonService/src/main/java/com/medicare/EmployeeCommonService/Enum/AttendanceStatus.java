package com.medicare.EmployeeCommonService.Enum;

public enum AttendanceStatus {
    PRESENT,
    ABSENT,
    HALF_DAY,
    ON_LEAVE,
    HOLIDAY,
    WEEK_OFF
}
