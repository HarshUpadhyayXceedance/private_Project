package com.medicare.EmployeeCommonService.Controller;

import com.medicare.EmployeeCommonService.Dto.Request.AddEducationRequest;
import com.medicare.EmployeeCommonService.Dto.Response.EducationResponse;
import com.medicare.EmployeeCommonService.Service.EducationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/employees")
@RequiredArgsConstructor
@Slf4j
public class EducationController {

    private final EducationService educationService;

    // Add education record [POST /api/employee-commons/employees/{userId}/education ]
    @PostMapping("/{userId}/education")
    public ResponseEntity<EducationResponse> addEducation(
            @PathVariable String userId,
            @Valid @RequestBody AddEducationRequest request
    ) {
        log.info("POST /employees/{}/education - Add education", userId);
        EducationResponse response = educationService.addEducation(userId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    // Get education records [ GET /api/employee-commons/employees/{userId}/education ]
    @GetMapping("/{userId}/education")
    public ResponseEntity<List<EducationResponse>> getEducationRecords(
            @PathVariable String userId
    ) {
        log.info("GET /employees/{}/education - Get education records", userId);
        List<EducationResponse> educations = educationService.getEducationRecords(userId);
        return ResponseEntity.ok(educations);
    }

    // Delete education record [ DELETE /api/employee-commons/employees/{userId}/education/{educationId} ]
    @DeleteMapping("/{userId}/education/{educationId}")
    public ResponseEntity<Void> deleteEducation(
            @PathVariable String userId,
            @PathVariable Long educationId
    ) {
        log.info("DELETE /employees/{}/education/{} - Delete education", userId, educationId);
        educationService.deleteEducation(userId, educationId);
        return ResponseEntity.noContent().build();
    }
}
