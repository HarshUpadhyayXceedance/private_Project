package com.medicare.EmployeeCommonService.Controller;


import com.medicare.EmployeeCommonService.Dto.Request.CreateDepartmentRequest;
import com.medicare.EmployeeCommonService.Dto.Response.DepartmentResponse;
import com.medicare.EmployeeCommonService.Service.DepartmentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/departments")
@RequiredArgsConstructor
@Slf4j
public class DepartmentController {

    private final DepartmentService departmentService;

    // Create department (Admin only) [ POST /api/employee-commons/departments ]
    @PostMapping
    public ResponseEntity<DepartmentResponse> createDepartment(
            @Valid @RequestBody CreateDepartmentRequest request) {
        log.info("POST /departments - Create department");
        DepartmentResponse response = departmentService.createDepartment(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    // Get all departments [ GET /api/employee-commons/departments ]
    @GetMapping
    public ResponseEntity<List<DepartmentResponse>> getAllDepartments(
            @RequestHeader("Authorization") String authHeader) {
        log.info("GET /departments - Get all departments");
        List<DepartmentResponse> departments = departmentService.getAllDepartments(authHeader);
        return ResponseEntity.ok(departments);
    }

    // Get department by ID [ GET /api/employee-commons/departments/{departmentId} ]
    @GetMapping("/{departmentId}")
    public ResponseEntity<DepartmentResponse> getDepartmentById(
            @PathVariable Long departmentId,
            @RequestHeader("Authorization") String authHeader ) {
        log.info("GET /departments/{} - Get department by ID", departmentId);
        DepartmentResponse response = departmentService.getDepartmentById(departmentId, authHeader);
        return ResponseEntity.ok(response);
    }
}