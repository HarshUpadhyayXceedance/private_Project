package com.medicare.EmployeeCommonService.Enum;

public enum LeaveStatus {
    PENDING,
    APPROVED,
    REJECTED,
    CANCELLED
}
