package com.medicare.EmployeeCommonService.Dto.Request;

import com.medicare.EmployeeCommonService.Enum.DocumentType;
import jakarta.validation.constraints.*;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UploadDocumentRequest {

    @NotNull(message = "Document type is required")
    private DocumentType documentType;

    @NotBlank(message = "Document name is required")
    private String documentName;

    @NotBlank(message = "Document URL is required")
    private String documentUrl;

    private Long fileSize;
    private String contentType;
    private String notes;
}
