package com.medicare.EmployeeCommonService.Dto.Request;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AddExperienceRequest {

    @NotBlank(message = "Organization is required")
    private String organization;

    @NotBlank(message = "Position is required")
    private String position;

    @NotNull(message = "Start date is required")
    @Past(message = "Start date must be in past")
    private LocalDate startDate;

    @PastOrPresent(message = "End date must be in past or today")
    private LocalDate endDate;

    private Boolean isCurrent;
    private String description;
    private String location;
}