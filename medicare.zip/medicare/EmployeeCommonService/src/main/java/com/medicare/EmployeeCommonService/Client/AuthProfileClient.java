package com.medicare.EmployeeCommonService.Client;

import com.medicare.EmployeeCommonService.Dto.Response.UserProfileResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import java.util.Map;

// Feign Client to communicate with Auth-Profile Service through API Gateway
// All calls go through: http://localhost:8080/api/auth-profile
@FeignClient(
        name = "auth-profile-client",
        url = "${feign.gateway.base-url:http://localhost:8080}",
        path = "/api/auth-profile"
)
public interface AuthProfileClient {
    // Get user profile by userId Endpoint: GET /api/auth-profile/profiles/{userId}
    @GetMapping("/profiles/{userId}")
    ResponseEntity<UserProfileResponse> getUserProfile(
            @PathVariable("userId") String userId,
            @RequestHeader("Authorization") String token
    );

    // Get user authentication details Endpoint: GET /api/auth-profile/auth/user/{userId}
    @GetMapping("/auth/user/{userId}")
    ResponseEntity<Map<String, Object>> getUserDetails(
            @PathVariable("userId") String userId,
            @RequestHeader("Authorization") String token
    );

    // Check if user is EMPLOYEE role
    default boolean isEmployee(String userId, String token) {
        try {
            ResponseEntity<Map<String, Object>> response = getUserDetails(userId, token);
            if (response.getBody() != null) {
                String role = (String) response.getBody().get("role");
                return "DOCTOR".equals(role);
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }
}



