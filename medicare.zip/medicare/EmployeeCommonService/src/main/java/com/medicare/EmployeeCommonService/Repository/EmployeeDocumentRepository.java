package com.medicare.EmployeeCommonService.Repository;

import com.medicare.EmployeeCommonService.Entity.EmployeeDocument;
import com.medicare.EmployeeCommonService.Enum.DocumentType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeDocumentRepository extends JpaRepository<EmployeeDocument, Long> {
    List<EmployeeDocument> findByEmployeeIdOrderByUploadedAtDesc(Long employeeId);
    List<EmployeeDocument> findByEmployeeIdAndDocumentType(Long employeeId, DocumentType documentType);

}
