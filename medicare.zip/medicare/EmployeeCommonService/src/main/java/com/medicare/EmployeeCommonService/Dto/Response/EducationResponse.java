package com.medicare.EmployeeCommonService.Dto.Response;

import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EducationResponse {
    private Long id;
    private Long employeeId;
    private String degree;
    private String institution;
    private Integer yearOfPassing;
    private String fieldOfStudy;
    private String gradeOrPercentage;
    private String message;
}