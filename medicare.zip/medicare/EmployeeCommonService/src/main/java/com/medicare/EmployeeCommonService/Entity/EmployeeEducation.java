package com.medicare.EmployeeCommonService.Entity;


import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "employee_education", indexes = {
        @Index(name = "idx_employee_id", columnList = "employee_id")
})
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeEducation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id", nullable = false)
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    private Employee employee;

    @Column(nullable = false)
    private String degree;

    @Column(nullable = false)
    private String institution;

    @Column(name = "year_of_passing", nullable = false)
    private Integer yearOfPassing;

    @Column(name = "field_of_study")
    private String fieldOfStudy;

    @Column(name = "grade_or_percentage")
    private String gradeOrPercentage;
}