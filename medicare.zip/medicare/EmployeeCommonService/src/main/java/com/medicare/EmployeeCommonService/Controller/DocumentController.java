package com.medicare.EmployeeCommonService.Controller;

import com.medicare.EmployeeCommonService.Dto.Response.DocumentResponse;
import com.medicare.EmployeeCommonService.Dto.Request.UploadDocumentRequest;
import com.medicare.EmployeeCommonService.Service.DocumentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/employees")
@RequiredArgsConstructor
@Slf4j
public class DocumentController {

    private final DocumentService documentService;

    // Upload document [ POST /api/employee-commons/employees/{userId}/documents ]
    @PostMapping("/{userId}/documents")
    public ResponseEntity<DocumentResponse> uploadDocument(
            @PathVariable String userId,
            @Valid @RequestBody UploadDocumentRequest request,
            @RequestHeader(value = "X-User-Id", required = false) String uploadedBy
    ) {
        log.info("POST /employees/{}/documents - Upload document", userId);

        // Use X-User-Id from gateway if available, otherwise use userId
        if (uploadedBy == null) {
            uploadedBy = userId;
        }

        DocumentResponse response = documentService.uploadDocument(userId, request, uploadedBy);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    // Get documents [ GET /api/employee-commons/employees/{userId}/documents]
    @GetMapping("/{userId}/documents")
    public ResponseEntity<List<DocumentResponse>> getDocuments(
            @PathVariable String userId
    ) {
        log.info("GET /employees/{}/documents - Get documents", userId);
        List<DocumentResponse> documents = documentService.getDocuments(userId);
        return ResponseEntity.ok(documents);
    }

    // Delete document [ DELETE /api/employee-commons/employees/{userId}/documents/{documentId} ]
    @DeleteMapping("/{userId}/documents/{documentId}")
    public ResponseEntity<Void> deleteDocument(
            @PathVariable String userId,
            @PathVariable Long documentId
    ) {
        log.info("DELETE /employees/{}/documents/{} - Delete document", userId, documentId);
        documentService.deleteDocument(userId, documentId);
        return ResponseEntity.noContent().build();
    }
}
