package com.medicare.EmployeeCommonService.Dto.Response;


import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LeaveResponse {
    private Long id;
    private Long employeeId;
    private String employeeName;
    private String leaveType;
    private String startDate;
    private String endDate;
    private Integer totalDays;
    private String reason;
    private String status;
    private String approvedBy;
    private String approvedAt;
    private String rejectionReason;
    private String createdAt;
    private String message;
}