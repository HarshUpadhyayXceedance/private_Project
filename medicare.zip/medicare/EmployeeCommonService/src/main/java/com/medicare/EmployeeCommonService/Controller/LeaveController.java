package com.medicare.EmployeeCommonService.Controller;

import com.medicare.EmployeeCommonService.Dto.Request.ApplyLeaveRequest;
import com.medicare.EmployeeCommonService.Dto.Request.LeaveApprovalRequest;
import com.medicare.EmployeeCommonService.Dto.Response.LeaveResponse;
import com.medicare.EmployeeCommonService.Service.LeaveService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/employees")
@RequiredArgsConstructor
@Slf4j
public class LeaveController {

    private final LeaveService leaveService;

    // Apply for leave [ POST /api/employee-commons/employees/{userId}/leaves ]
    @PostMapping("/{userId}/leaves")
    public ResponseEntity<LeaveResponse> applyLeave(
            @PathVariable String userId,
            @Valid @RequestBody ApplyLeaveRequest request,
            @RequestHeader("Authorization") String authHeader
    ) {
        log.info("POST /employees/{}/leaves - Apply leave", userId);
        LeaveResponse response = leaveService.applyLeave(userId, request, authHeader);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    // Get employee leaves [ GET /api/employee-commons/employees/{userId}/leaves ]
    @GetMapping("/{userId}/leaves")
    public ResponseEntity<List<LeaveResponse>> getEmployeeLeaves(
            @PathVariable String userId,
            @RequestHeader("Authorization") String authHeader
    ) {
        log.info("GET /employees/{}/leaves - Get employee leaves", userId);
        List<LeaveResponse> leaves = leaveService.getEmployeeLeaves(userId, authHeader);
        return ResponseEntity.ok(leaves);
    }

    // Get all pending leaves (Admin only) [ GET /api/employee-commons/employees/leaves/pending ]
    @GetMapping("/leaves/pending")
    public ResponseEntity<List<LeaveResponse>> getPendingLeaves(
            @RequestHeader("Authorization") String authHeader
    ) {
        log.info("GET /employees/leaves/pending - Get pending leaves");
        List<LeaveResponse> leaves = leaveService.getPendingLeaves(authHeader);
        return ResponseEntity.ok(leaves);
    }

    // Approve or reject leave (Admin only [ PUT /api/employee-commons/employees/{userId}/leaves/{leaveId}/approve ]
    @PutMapping("/{userId}/leaves/{leaveId}/approve")
    public ResponseEntity<LeaveResponse> approveOrRejectLeave(
            @PathVariable String userId,
            @PathVariable Long leaveId,
            @Valid @RequestBody LeaveApprovalRequest request,
            @RequestHeader("Authorization") String authHeader,
            @RequestHeader(value = "X-User-Id", required = false) String approvedBy
    ) {
        log.info("PUT /employees/{}/leaves/{}/approve - Approve/Reject leave", userId, leaveId);

        // Use X-User-Id from gateway if available, otherwise extract from token
        if (approvedBy == null) {
            approvedBy = "SYSTEM";
        }

        LeaveResponse response = leaveService.approveOrRejectLeave(leaveId, request, approvedBy, authHeader);
        return ResponseEntity.ok(response);
    }

    // Cancel leave [ DELETE /api/employee-commons/employees/{userId}/leaves/{leaveId} ]
    @DeleteMapping("/{userId}/leaves/{leaveId}")
    public ResponseEntity<Void> cancelLeave(
            @PathVariable String userId,
            @PathVariable Long leaveId
    ) {
        log.info("DELETE /employees/{}/leaves/{} - Cancel leave", userId, leaveId);
        leaveService.cancelLeave(userId, leaveId);
        return ResponseEntity.noContent().build();
    }
}