package com.medicare.EmployeeCommonService.Enum;

public enum EmployeeStatus {
    ACTIVE,
    ON_LEAVE,
    SUSPENDED,
    TERMINATED
}

